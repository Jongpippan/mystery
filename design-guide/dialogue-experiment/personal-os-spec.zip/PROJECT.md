# Personal OS --- Product Specification

## 1. Purpose

Personal OS is a Korean-first personal management system that connects
daily execution, long-term goals, time, reviews, and personal files.

It is not intended to replace Notion, Google Calendar, Finder, iCloud,
or external storage. It acts as a **control and intelligence layer**
across those systems.

The product must remain useful even when AI features are unavailable. AI
should improve planning, organization, retrieval, and recommendations
rather than become a hard dependency for basic CRUD operations.

## 2. Product Language

-   The product UI is **Korean-first**.
-   User-facing labels, messages, confirmations, errors, onboarding,
    chatbot responses, and default templates should be Korean.
-   Internal code, identifiers, schemas, API names, developer
    documentation, and logs may use English.
-   Do not translate established technical terms unnecessarily when
    Korean users commonly recognize the English term.

## 3. Core Product Areas

Personal OS v1 has exactly three primary product areas.

### 3.1 Tasks and Goals

Support:

-   Immediate checklist-style tasks.
-   Tasks with due dates and estimated duration.
-   Short-term goals.
-   Long-term goals.
-   Relationships between tasks and goals.
-   Fast capture from Mac and iPhone.
-   Today and upcoming views.
-   Completion tracking.
-   AI-assisted classification and planning.

The system should minimize capture friction. A user should not need to
navigate through multiple screens to record a thought.

Future capture surfaces may include:

-   Personal OS web/PWA.
-   iPhone home-screen shortcut.
-   Apple Shortcuts.
-   Siri → Shortcut.
-   Chat interface.
-   Mac quick capture.

### 3.2 Calendar and AI Timeblocking

Google Calendar is the source of truth for calendar events and committed
timeblocks.

Personal OS should:

-   Read the user's calendar.
-   Detect usable free-time windows.
-   Convert tasks into proposed timeblocks.
-   Consider deadlines, estimated duration, existing events, priorities,
    and user constraints.
-   Present an editable plan before committing meaningful schedule
    changes.
-   Write accepted timeblocks to Google Calendar.
-   Re-plan when calendar constraints change.

Personal OS must not become a second independent calendar database.

### 3.3 Reviews and Personal Archive

This area contains two related but distinct systems.

#### Reviews / Journals / Long-form Notes

Notion is the full source of truth.

Notion owns:

-   Original page content.
-   Rich text.
-   Images and embeds.
-   Databases when used for review organization.
-   Parent/child page hierarchy.
-   Review/journal structure.
-   Long-form notes.

Personal OS may:

-   Index page metadata.
-   Read page content when needed.
-   Read and reconstruct accessible hierarchy.
-   Search and analyze reviews.
-   Recommend structural changes.
-   Perform safe Notion operations supported by the integration.
-   Reorganize content only when the operation can preserve the source
    safely.

Personal OS must **not** maintain a competing canonical copy of review
bodies.

#### Personal Files

Actual files remain in their existing storage locations:

-   Mac local storage.
-   iCloud Drive.
-   External SSDs or other explicitly configured volumes.

Personal OS stores an index and intelligence metadata rather than
copying every file into its database.

The archive should support:

-   File indexing.
-   Folder/path indexing.
-   Storage-location awareness.
-   Exact duplicate detection.
-   Near-duplicate/version relationship detection.
-   Semantic categorization.
-   Storage-location recommendations.
-   Folder-structure recommendations.
-   Safe rename/move/trash execution through the Mac Local Agent.
-   Action history and undo where technically possible.

## 4. Source of Truth

These boundaries are implementation contracts.

  Domain                           Source of Truth
  -------------------------------- ----------------------------------
  Tasks                            Personal OS database
  Goals                            Personal OS database
  Task ↔ Goal relationships        Personal OS database
  Calendar events                  Google Calendar
  Committed timeblocks             Google Calendar
  Timeblock planning metadata      Personal OS database when needed
  Reviews                          Notion
  Journals                         Notion
  Long-form notes                  Notion
  Notion page hierarchy            Notion
  Notion page index/cache          Personal OS database
  Actual personal files            Mac / iCloud / external storage
  File metadata index              Personal OS database
  Duplicate groups / AI metadata   Personal OS database
  Filesystem action history        Personal OS database

Do not change these boundaries without explicit product approval.

## 5. Primary Interfaces

### 5.1 Personal OS Web / PWA

Primary integrated dashboard.

Initial navigation should remain small:

-   오늘
-   목표
-   아카이브
-   리뷰
-   채팅

Calendar information may initially appear inside Today rather than
requiring a full calendar replacement UI.

### 5.2 Chat

Chat is a first-class command interface, not only a Q&A widget.

Examples:

-   "이번 주까지 해야 할 일 뭐 있어?"
-   "이번 주 AI 공부 5시간 빈 시간에 넣어줘."
-   "작년 10월 리뷰에서 반복적으로 나온 문제 알려줘."
-   "2024년 취업 자료 어디에 흩어져 있어?"
-   "용량 확보할 만한 파일 찾아줘."
-   "방금 파일 정리한 거 취소해줘."

The chatbot should use tools against authoritative systems rather than
hallucinating state.

### 5.3 Mac Local Agent

A background component installed on the user's Mac.

It should:

-   Start automatically after login.
-   Require no permanently open terminal or visible application window.
-   Report online/offline state.
-   Scan configured filesystem roots.
-   Execute approved filesystem operations.
-   Process queued approved actions after reconnecting.
-   Keep execution logs.
-   Never implement permanent deletion.

A small menu-bar status UI may be added for visibility, pause/resume,
permissions, and recent activity.

## 6. Filesystem Safety Policy

### 6.1 Allowed Read Operations

The agent may automatically perform configured read-only operations such
as:

-   List directories.
-   Read metadata.
-   Calculate hashes.
-   Inspect file types.
-   Extract permitted text for indexing.
-   Calculate aggregate storage usage.

Read scope must still be limited to explicitly configured roots.

### 6.2 Mutating Operations

The following operations require a visible action-plan preview and
explicit user approval:

-   Rename.
-   Move.
-   Move to Trash.

Approval may occur from Personal OS on either iPhone or Mac.

Approval is independent from Mac availability:

1.  User reviews action plan.
2.  User approves.
3.  Backend records immutable approved intent.
4.  If Mac Agent is online, execution can begin.
5.  If Mac Agent is offline, the action remains queued.
6.  Agent executes after reconnecting, subject to precondition checks.
7.  Results are logged and surfaced to the user.

The user should not need to approve the same operation again merely
because the Mac was offline at approval time.

### 6.3 Permanent Deletion

**Permanent file deletion MUST NOT be implemented.**

"Delete" in Personal OS means moving an item to macOS Trash.

The system must never use destructive permanent deletion as a
convenience fallback.

### 6.4 Undo

-   Rename and move operations should be undoable when their original
    state is still available.
-   Trash actions may be restorable when the file still exists in Trash
    and can be identified safely.
-   Every mutation must record enough before/after state to determine
    whether undo is safe.
-   If the current filesystem state no longer matches the expected
    state, do not blindly undo; ask the user or mark the action as
    requiring review.

## 7. File Intelligence

### 7.1 Exact Duplicates

Use deterministic content hashing.

Typical flow:

1.  Group candidates by file size.
2.  Hash candidates.
3.  Files with the same strong content hash belong to an exact duplicate
    group.
4.  Never delete duplicates automatically.

### 7.2 Near Duplicates / Versions

Use combinations of:

-   File name similarity.
-   Extension/type.
-   Size.
-   Timestamps.
-   Extracted text similarity.
-   Embeddings.
-   Optional local LLM analysis.

Examples include `resume.pdf`, `resume_final.pdf`, and
`resume_final2.pdf`.

These should be described as likely related versions unless exact
identity is proven by hash.

### 7.3 Storage Recommendations

Recommendations should combine deterministic rules with AI.

Possible signals:

-   File size.
-   Last modified/access information when reliable.
-   Project activity.
-   Need for cross-device access.
-   Whether a file is performance-sensitive.
-   Current storage pressure.
-   Existing folder conventions.
-   External drive availability.

Example policy:

-   Active repositories / current Logic projects → Mac local.
-   Small documents needed across devices → iCloud.
-   Large inactive historical assets → external archive storage.

Recommendations never imply execution until the user approves the
concrete action plan.

## 8. Notion Policy

Notion is the canonical authoring and hierarchy environment for reviews
and long-form personal writing.

Personal OS should index enough information to support fast navigation
and AI retrieval, for example:

-   Notion page ID.
-   Parent reference.
-   Title.
-   Page type/category.
-   Review date.
-   Tags/properties when available.
-   Last edited time.
-   Computed path/depth.
-   Sync state.

Do not duplicate full page bodies into the canonical Personal OS
relational model.

Temporary retrieval caches may exist for performance, but they must be
treated as disposable cache, not authoritative content.

### 8.1 Structural Changes

Personal OS may recommend moving/restructuring Notion pages.

When direct movement is not supported safely by the available Notion
API/tooling, do not fake it. Possible approaches include:

-   Ask the user to perform the move in Notion.
-   Implement a verified copy/recreate/archive workflow only for content
    types that can be reproduced safely.
-   Clearly preview structural changes before execution.

Never destroy the original page before the replacement has been created
and validated.

## 9. AI Strategy

AI must be provider-agnostic.

Potential execution layers:

### Local AI

Suitable for:

-   Classification.
-   Tagging.
-   Summarization.
-   Embeddings.
-   File categorization.
-   Simple planning.
-   Local/private archive analysis.

Target development machine:

-   Apple M4 Pro.
-   48 GB unified memory.
-   Local model runtime is expected to be viable.
-   Storage use must be monitored because model files can be large.

### ChatGPT / Codex

The user intends to maintain ChatGPT Plus and use Codex.

Use them for:

-   Higher-level reasoning.
-   Development.
-   Interactive analysis.
-   Complex planning when exposed through appropriate tools.

Do **not** architect the application under the assumption that ChatGPT
Plus provides arbitrary free OpenAI API usage.

### Paid API Dependency

v1 should avoid requiring a paid model API to function.

AI interfaces must make the model/provider replaceable.

## 10. Offline and Remote Behavior

### Mac Online

-   Filesystem scans and approved mutations can execute.
-   Local AI may execute.
-   Agent can report status/results.

### Mac Offline

From iPhone or another device, the user may still:

-   Create/edit tasks and goals.
-   Read cloud-accessible state.
-   Use Google Calendar integration.
-   Use Notion integration.
-   Submit filesystem action requests.
-   Approve prepared filesystem action plans.

Filesystem actions requiring the Mac remain queued.

When the Mac Agent reconnects, it validates and executes queued approved
actions.

## 11. v1 Scope

Implement the smallest useful system.

### Tasks / Goals

-   Create/edit/complete task.
-   Due date.
-   Estimated duration.
-   Goal relationship.
-   Short-term / long-term goals.
-   Today/upcoming views.
-   Fast capture.

### Calendar

-   Read Google Calendar.
-   Show today's schedule.
-   Find candidate free windows.
-   Propose task timeblocks.
-   Commit approved timeblocks.

### Notion

-   Configure review root(s).
-   Index page metadata and hierarchy.
-   Navigate from Personal OS to canonical Notion pages.
-   Retrieve relevant content for analysis.
-   Search review metadata/content through integration.
-   Recommend organization changes.

### Archive

-   Configure scan roots.
-   Index local/iCloud/external files.
-   Hash-based duplicate detection.
-   Storage summaries.
-   Folder/storage recommendations.
-   Preview → approve → queue → execute rename/move/trash.
-   Action history.
-   Basic undo.

### Chat

-   Answer from connected authoritative sources.
-   Create/update tasks.
-   Query goals.
-   Query calendar.
-   Propose timeblocks.
-   Search Notion reviews.
-   Search indexed files.
-   Propose filesystem changes.
-   Execute only after required approval.

## 12. Explicit Non-Goals for v1

Do not initially build:

-   A Notion-quality rich text editor.
-   A Google Calendar replacement.
-   A Finder replacement.
-   A Photos replacement.
-   Automatic permanent file deletion.
-   Fully autonomous filesystem cleanup.
-   Massive always-on RAG over every binary file.
-   Complex multi-user collaboration.
-   Enterprise permission systems.
-   Mandatory paid AI APIs.
-   Automatic organization changes without review.
-   Full synchronization copies of Notion bodies.
-   Arbitrary remote shell execution.

## 13. Product Principle

Personal OS should connect:

**Task → Time → Review → Archive**

The system should reduce friction and surface intelligent
recommendations while keeping authoritative data in the tools best
suited to own it.
