# AGENTS.md --- Codex Working Contract

## 1. Read Before Changing the Project

Before making architectural or cross-cutting changes, read:

1.  `PROJECT.md`
2.  `ARCHITECTURE.md`
3.  `DATA_MODEL.md`
4.  This file

These documents are the implementation contract.

If code and documentation conflict, do not silently choose one. Identify
the conflict and preserve safety/source-of-truth rules until the user
decides.

## 2. Communication

-   Respond to the user in Korean unless explicitly asked otherwise.
-   The product UI is Korean-first.
-   Code, identifiers, schemas, comments, commit messages, and technical
    documentation may be English unless the repository establishes
    another convention.
-   User-facing strings should default to natural Korean.

## 3. Product Boundaries

Never change these without explicit user approval:

-   Personal OS DB is canonical for tasks and goals.
-   Google Calendar is canonical for calendar events and committed
    timeblocks.
-   Notion is canonical for reviews, journals, long-form notes, and
    their page hierarchy.
-   Personal OS may index Notion metadata but must not become the
    canonical store for review bodies.
-   Actual files remain in Mac/iCloud/external filesystem storage.
-   Personal OS DB stores file indexes, hashes, relations, AI metadata,
    and action history.
-   The Mac Local Agent performs local filesystem execution.

## 4. Filesystem Safety --- Non-Negotiable

### Permanent Deletion

Permanent deletion MUST NOT be implemented.

Do not:

-   Add a `PERMANENT_DELETE` operation.
-   Use `rm`/`unlink` as a product deletion feature.
-   Empty Trash.
-   Add a hidden force-delete option.
-   Fall back to permanent deletion when Trash fails.

Product "delete" means **move to macOS Trash**.

### Mutation Approval

The following require explicit user approval of a visible action plan:

-   Rename.
-   Move.
-   Trash.

Approval may be performed from iPhone or Mac Personal OS.

The Mac does not need to be online at approval time.

Approved actions may queue and execute when the Mac Agent reconnects.

If an approved plan changes, invalidate the approval and require a new
one.

### Execution Validation

Before mutating:

-   Verify source exists.
-   Verify expected identity/hash/metadata where applicable.
-   Verify destination availability.
-   Fail safely on conflicts.
-   Never silently overwrite.
-   Never improvise a different destructive action.

Every mutation must produce an audit log.

## 5. No Arbitrary Remote Shell

Do not implement a backend/chat endpoint that accepts arbitrary shell
commands for execution on the Mac.

Use typed operations such as:

``` text
CREATE_DIRECTORY
RENAME
MOVE
TRASH
```

The AI/chat layer must only call structured tools.

The server must enforce safety independently from model output.

## 6. Undo

For rename/move/trash:

-   Record before/after state.
-   Generate inverse operations only when safe.
-   Revalidate filesystem state before undo.
-   Do not blindly restore over conflicting current data.
-   Undo should itself use the normal action-plan flow.

## 7. Notion Rules

-   Notion owns original review/note content.
-   Store metadata/indexes locally.
-   Fetch content on demand.
-   Treat any body cache as disposable.
-   Preserve Notion hierarchy.
-   Do not claim an unsupported Notion move operation exists.
-   If restructuring requires copy/recreate behavior, validate
    destination content before changing/removing the original.
-   Prefer a manual Notion step over a lossy automated migration.

## 8. Google Calendar Rules

-   Google Calendar owns committed events/timeblocks.
-   Personal OS may store external IDs and proposal metadata.
-   Timeblock proposals are not calendar events until
    accepted/committed.
-   Re-read calendar state when stale state could create conflicts.
-   External Google Calendar edits win over stale Personal OS cache.

## 9. AI Rules

-   Keep AI provider/model replaceable.
-   Do not make a paid model API mandatory for basic product operation.
-   Do not assume ChatGPT Plus includes arbitrary OpenAI API usage.
-   Local LLM support is expected.
-   Prefer deterministic logic for deterministic problems:
    -   Exact duplicate → hash.
    -   Scheduling constraints → deterministic calendar logic first.
    -   Safety/approval → code/policy, never model judgment.
-   Use AI for fuzzy tasks:
    -   Classification.
    -   Summaries.
    -   Tags.
    -   Semantic relations.
    -   Recommendations.
    -   Planning/rationale.

AI recommendations must not bypass mutation approval.

## 10. Mac Local Agent Rules

The agent should:

-   Run as a background macOS component.
-   Start automatically after login.
-   Require no open terminal.
-   Prefer outbound authenticated communication.
-   Operate only inside configured roots.
-   Report online/offline/paused status.
-   Safely queue/retry jobs.
-   Handle external volumes being unavailable.
-   Never expose unrestricted remote filesystem/shell access.

Keep agent permissions as narrow as practical.

## 11. Mobile Behavior

Mobile is a full control surface for cloud-accessible features.

From iPhone, the user may:

-   Capture/manage tasks.
-   Manage goals.
-   View calendar.
-   Request/approve timeblocks.
-   Search reviews.
-   Search indexed file metadata.
-   Ask the chatbot questions.
-   Approve filesystem action plans.

Actual Mac filesystem execution happens on the Mac Agent.

If the Mac is offline:

-   Preserve approved job.
-   Show queued/waiting state.
-   Execute after reconnecting and revalidation.
-   Do not require duplicate approval solely because the Mac was
    offline.

## 12. Implementation Style

-   Prefer small, reviewable diffs.
-   Do not rewrite unrelated code.
-   Avoid premature abstractions.
-   Prefer a modular monolith for v1.
-   Add dependencies only when they solve a clear requirement.
-   Keep external integration code behind adapters/interfaces.
-   Keep domain rules independent from UI and AI providers.
-   Validate all mutation inputs server-side.
-   Make operations idempotent where retries are possible.
-   Use migrations for schema changes.
-   Never commit secrets, tokens, credentials, model files, or personal
    indexed data.

## 13. Suggested Module Boundaries

Names may vary by framework, but preserve conceptual separation:

``` text
tasks/
goals/
calendar/
notion/
archive/
actions/
agent/
chat/
ai/
auth/
```

Potential infrastructure adapters:

``` text
integrations/google-calendar/
integrations/notion/
integrations/local-agent/
ai/local/
ai/external/
```

Do not mix filesystem execution code into frontend components.

## 14. UI Rules

The site is Korean-first.

Prioritize:

-   Fast capture.
-   Low navigation depth.
-   Clear action previews.
-   Clear online/offline agent state.
-   Clear distinction between recommendation and executed action.
-   Clear source links to Notion where useful.
-   Clear Google Calendar ownership.
-   Mobile usability.

Initial top-level product areas:

``` text
오늘
목표
아카이브
리뷰
채팅
```

Do not build a Notion-quality editor or a full calendar clone in v1.

## 15. v1 Priority Order

When choosing what to implement next, prefer:

1.  Project foundation and auth/config.
2.  Task/goal CRUD and Today.
3.  Google Calendar read integration.
4.  Timeblock proposal + commit.
5.  Notion root/index/tree integration.
6.  Mac Agent registration/heartbeat.
7.  File indexing.
8.  Hash duplicate detection.
9.  Action plan + approval + queue.
10. Rename/move/trash execution.
11. Activity history + undo.
12. Chat tool layer.
13. Local AI enrichment.
14. More advanced archive recommendations.

This order is guidance, not permission to violate dependencies or
safety.

## 16. Scope Control

Do not proactively add:

-   Permanent deletion.
-   Fully autonomous cleanup.
-   Arbitrary shell execution.
-   A rich text editor.
-   A full calendar replacement.
-   A Finder replacement.
-   A Photos replacement.
-   Multi-user enterprise features.
-   Paid API dependencies.
-   Large-scale RAG before basic indexing works.
-   Complex agent frameworks before typed tools work.

## 17. Testing Expectations

Filesystem mutation tests must include:

-   Source missing.
-   Destination missing.
-   Destination conflict.
-   External volume disconnected.
-   File changed after approval.
-   Duplicate job delivery.
-   Agent reconnect.
-   Partial cross-volume failure.
-   Undo after subsequent change.
-   Trash failure.

Integration tests should verify source-of-truth behavior.

Safety rules deserve tests, not comments alone.

## 18. When Requirements Are Ambiguous

If ambiguity affects:

-   Data ownership.
-   Destructive behavior.
-   Approval semantics.
-   Privacy.
-   External costs.
-   Sync conflict policy.
-   User-visible workflow.

Do not invent a major product decision. Ask the user or choose the
safest reversible behavior and clearly flag it.

For ordinary implementation details, make a reasonable decision and keep
the diff small.

## 19. Definition of Done for Mutating Features

A mutation feature is not done unless it includes:

-   Preview.
-   Explicit approval where required.
-   Immutable approved intent.
-   Queue/offline behavior.
-   Precondition validation.
-   Safe execution.
-   Result reporting.
-   Audit log.
-   Failure state.
-   Undo/recovery consideration.
-   Tests for destructive edge cases.

## 20. Core Principle

Personal OS should intelligently coordinate existing systems without
taking unnecessary ownership away from them.

Preserve:

**Task → Time → Review → Archive**

and keep every destructive capability explicit, reviewable, reversible
where possible, and narrowly scoped.
