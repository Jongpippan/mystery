# Personal OS --- Data Model

## 1. Modeling Principles

1.  Store canonical data only where Personal OS owns it.
2.  Store external-system identifiers and indexes instead of duplicating
    authoritative content.
3.  Separate user intent, approval, dispatch, and execution for
    filesystem mutations.
4.  Keep AI-derived fields clearly distinguishable from deterministic
    metadata.
5.  Design for one user first, but do not hard-code assumptions that
    make ownership impossible to add later.
6.  Use stable IDs rather than paths as the only identity for indexed
    files.
7.  Treat external data as stale-able and record sync timestamps.

The examples below are conceptual and do not mandate a specific ORM.

## 2. Entity Overview

``` text
Goal
  |
  +---< Task
          |
          +---< TimeblockReference

NotionRoot
  |
  +---< NotionPageIndex

StorageLocation
  |
  +---< IndexedFile
          |
          +---< FileHash
          +---< FileRelation

ActionPlan
  |
  +---< ActionStep
  |
  +--- Approval
  |
  +---< AgentJob
          |
          +--- ExecutionLog

MacAgent
  |
  +---< AgentJob
```

## 3. Goal

Canonical: Personal OS database.

Suggested fields:

``` text
Goal
- id: UUID
- title: string
- description: text?
- horizon: SHORT_TERM | LONG_TERM
- status: ACTIVE | COMPLETED | PAUSED | ARCHIVED
- targetDate: date?
- priority: integer?
- createdAt: timestamp
- updatedAt: timestamp
- completedAt: timestamp?
```

Do not over-model goal progress in v1. Progress may initially be derived
from linked tasks or entered manually later.

## 4. Task

Canonical: Personal OS database.

``` text
Task
- id: UUID
- title: string
- description: text?
- status: INBOX | TODO | IN_PROGRESS | DONE | CANCELLED
- priority: integer?
- dueAt: timestamp?
- estimatedMinutes: integer?
- goalId: UUID?
- source: MANUAL | CHAT | SHORTCUT | IMPORT
- createdAt: timestamp
- updatedAt: timestamp
- completedAt: timestamp?
```

Possible later fields:

``` text
- earliestStartAt
- energyLevel
- context
- recurrenceRule
```

Do not add them until a real planning need exists.

## 5. TimeblockReference

Google Calendar is canonical for committed blocks.

This entity only links Personal OS planning state to Google events.

``` text
TimeblockReference
- id: UUID
- taskId: UUID
- googleCalendarId: string
- googleEventId: string
- plannedStartAt: timestamp?
- plannedEndAt: timestamp?
- createdByPersonalOs: boolean
- lastSyncedAt: timestamp
- createdAt: timestamp
```

If Google Calendar and this record disagree, Google Calendar wins.

## 6. TimeblockProposal

Optional persisted planning object.

``` text
TimeblockProposal
- id: UUID
- taskId: UUID
- startAt: timestamp
- endAt: timestamp
- rationale: text?
- confidence: float?
- proposalBatchId: UUID
- status: PROPOSED | ACCEPTED | REJECTED | SUPERSEDED
- createdAt: timestamp
```

This is not a calendar event.

## 7. NotionRoot

Defines a configured Notion subtree that Personal OS indexes.

``` text
NotionRoot
- id: UUID
- notionPageId: string
- label: string
- purpose: REVIEW | JOURNAL | NOTES | OTHER
- enabled: boolean
- createdAt: timestamp
- lastIndexedAt: timestamp?
```

## 8. NotionPageIndex

Canonical body/hierarchy: Notion.

Personal OS stores only metadata/index/cache references.

``` text
NotionPageIndex
- id: UUID
- notionPageId: string UNIQUE
- rootId: UUID
- parentNotionPageId: string?
- title: string
- kind: string?
- reviewDate: date?
- depth: integer?
- computedPath: string?
- propertiesJson: JSON?
- notionUrl: string?
- lastEditedAt: timestamp?
- lastIndexedAt: timestamp
- syncStatus: CURRENT | STALE | ERROR | MISSING
```

Do not add a canonical `body` column for review content.

If temporary content caching becomes necessary, create a separate
explicitly disposable cache entity.

## 9. NotionContentCache

Optional, non-canonical.

``` text
NotionContentCache
- notionPageId: string
- contentSnapshot: text/JSON
- sourceLastEditedAt: timestamp
- cachedAt: timestamp
- expiresAt: timestamp?
```

The cache may be deleted and rebuilt at any time.

## 10. StorageLocation

Represents a configured storage root/volume.

``` text
StorageLocation
- id: UUID
- kind: MAC_LOCAL | ICLOUD | EXTERNAL
- label: string
- rootPath: string
- volumeIdentifier: string?
- enabled: boolean
- writable: boolean
- createdAt: timestamp
- lastSeenAt: timestamp?
```

Examples:

-   Mac Documents root.
-   iCloud Drive root.
-   External SSD archive root.

Do not scan arbitrary filesystem roots that were not configured.

## 11. IndexedFile

Actual file remains on filesystem.

``` text
IndexedFile
- id: UUID
- storageLocationId: UUID
- currentPath: string
- fileName: string
- extension: string?
- mimeType: string?
- sizeBytes: bigint
- createdAtFs: timestamp?
- modifiedAtFs: timestamp?
- accessedAtFs: timestamp?
- filesystemIdentity: string?
- isDirectory: boolean
- parentPath: string?
- lastIndexedAt: timestamp
- indexStatus: CURRENT | STALE | MISSING | ERROR
```

AI-derived fields should not be mixed indiscriminately into this table.

## 12. FileHash

``` text
FileHash
- id: UUID
- indexedFileId: UUID
- algorithm: SHA256
- hashValue: string
- fileSizeBytes: bigint
- sourceModifiedAt: timestamp?
- computedAt: timestamp
```

A hash is valid only for the file state it was computed from.

## 13. FileAiMetadata

``` text
FileAiMetadata
- indexedFileId: UUID
- summary: text?
- category: string?
- tagsJson: JSON?
- projectHint: string?
- importanceScore: float?
- recommendedStorageLocationId: UUID?
- recommendedFolder: string?
- recommendationReason: text?
- modelProvider: string?
- modelName: string?
- generatedAt: timestamp
- sourceFingerprint: string?
```

AI output is advisory.

## 14. FileRelation

Used for duplicates, likely versions, and semantic relationships.

``` text
FileRelation
- id: UUID
- fileAId: UUID
- fileBId: UUID
- relationType:
    EXACT_DUPLICATE
    LIKELY_VERSION
    NEAR_DUPLICATE
    SEMANTICALLY_RELATED
- score: float?
- evidenceJson: JSON?
- createdAt: timestamp
- updatedAt: timestamp
```

Rules:

-   `EXACT_DUPLICATE` requires deterministic evidence such as matching
    strong content hash.
-   AI alone must not produce `EXACT_DUPLICATE`.

## 15. MacAgent

``` text
MacAgent
- id: UUID
- deviceName: string
- agentVersion: string
- status: ONLINE | OFFLINE | PAUSED
- lastSeenAt: timestamp?
- capabilitiesJson: JSON?
- createdAt: timestamp
```

Do not store reusable raw local shell authority.

## 16. ActionPlan

Represents a user-reviewable proposed mutation.

``` text
ActionPlan
- id: UUID
- title: string
- description: text?
- status:
    DRAFT
    PREVIEW_READY
    APPROVED
    QUEUED
    DISPATCHED
    EXECUTING
    SUCCEEDED
    PARTIALLY_SUCCEEDED
    FAILED
    BLOCKED
    CANCELLED
- immutableVersion: integer
- createdBy: USER | CHAT | AI | SYSTEM
- createdAt: timestamp
- updatedAt: timestamp
- approvedAt: timestamp?
- completedAt: timestamp?
```

After approval, the approved version is immutable.

If the steps change, create a new version and require approval again.

## 17. ActionStep

Never store arbitrary shell commands.

``` text
ActionStep
- id: UUID
- actionPlanId: UUID
- sequence: integer
- operation:
    CREATE_DIRECTORY
    RENAME
    MOVE
    TRASH
- indexedFileId: UUID?
- expectedSourcePath: string?
- expectedSourceHash: string?
- expectedSourceSize: bigint?
- destinationPath: string?
- conflictPolicy: FAIL
- status:
    PENDING
    VALIDATING
    BLOCKED
    EXECUTING
    SUCCEEDED
    FAILED
- resultJson: JSON?
```

`PERMANENT_DELETE` must not exist as an enum value.

Default conflict policy should be `FAIL`, not overwrite.

## 18. Approval

``` text
Approval
- id: UUID
- actionPlanId: UUID
- actionPlanVersion: integer
- approvedByUserId: UUID/string
- approvedAt: timestamp
- expiresAt: timestamp?
- client: WEB | PWA | IPHONE | MAC
```

Approval should bind to the exact immutable action-plan version.

## 19. AgentJob

Execution unit sent to the Mac Agent.

``` text
AgentJob
- id: UUID
- actionPlanId: UUID
- macAgentId: UUID
- status:
    QUEUED
    DISPATCHED
    ACKNOWLEDGED
    VALIDATING
    EXECUTING
    SUCCEEDED
    FAILED
    BLOCKED
    CANCELLED
- queuedAt: timestamp
- dispatchedAt: timestamp?
- startedAt: timestamp?
- finishedAt: timestamp?
- failureCode: string?
- failureMessage: text?
```

A job may remain queued while the Mac is offline.

## 20. ExecutionLog

Audit record for filesystem mutations.

``` text
ExecutionLog
- id: UUID
- agentJobId: UUID
- actionStepId: UUID
- operation: enum
- beforeStateJson: JSON
- afterStateJson: JSON?
- result: SUCCEEDED | FAILED | BLOCKED
- errorCode: string?
- errorMessage: text?
- executedAt: timestamp
```

Do not store unnecessary file content in logs.

## 21. UndoRequest

``` text
UndoRequest
- id: UUID
- sourceActionPlanId: UUID
- generatedInversePlanId: UUID?
- status: REQUESTED | PREVIEW_READY | APPROVED | EXECUTED | BLOCKED | CANCELLED
- createdAt: timestamp
```

Undo should create a normal action plan and pass through validation
rather than directly reversing state.

## 22. ChatConversation

Optional if chat history is persisted.

``` text
ChatConversation
- id: UUID
- title: string?
- createdAt: timestamp
- updatedAt: timestamp
```

## 23. ChatMessage

``` text
ChatMessage
- id: UUID
- conversationId: UUID
- role: USER | ASSISTANT | TOOL
- content: text/JSON
- createdAt: timestamp
```

Be conservative about persisting sensitive tool payloads.

## 24. AI Run Metadata

Useful for debugging automated behavior without binding domain tables to
a vendor.

``` text
AiRun
- id: UUID
- purpose: string
- provider: LOCAL | EXTERNAL | OTHER
- model: string
- startedAt: timestamp
- completedAt: timestamp?
- status: SUCCEEDED | FAILED
- inputReferenceJson: JSON?
- outputReferenceJson: JSON?
```

Avoid storing full private file contents solely for AI observability.

## 25. Recommended Indexes

At minimum consider indexes for:

``` text
Task(status, dueAt)
Task(goalId)

NotionPageIndex(notionPageId)
NotionPageIndex(parentNotionPageId)
NotionPageIndex(reviewDate)
NotionPageIndex(lastEditedAt)

IndexedFile(storageLocationId, currentPath)
IndexedFile(sizeBytes)
IndexedFile(modifiedAtFs)

FileHash(hashValue)
FileRelation(fileAId)
FileRelation(fileBId)

ActionPlan(status, createdAt)
AgentJob(macAgentId, status)
ExecutionLog(actionStepId)

MacAgent(status, lastSeenAt)
```

Use database-specific full-text/vector indexes only after actual search
requirements are measured.

## 26. Retention

-   Tasks/goals: retain unless user archives/deletes them through
    product semantics.
-   Notion indexes: rebuildable.
-   File indexes: rebuildable, but action history must not depend on a
    mutable path alone.
-   AI metadata: rebuildable.
-   Execution/audit logs: retain long enough to support history and
    undo.
-   Temporary AI/cache data: aggressively disposable.

## 27. Data Model Non-Goals

Do not model in v1:

-   Multi-user organizations.
-   Complex RBAC.
-   Full Notion block schema.
-   Full Google Calendar event mirror.
-   Binary file blobs in PostgreSQL.
-   Permanent deletion.
-   Arbitrary shell jobs.
-   Every possible productivity methodology.
