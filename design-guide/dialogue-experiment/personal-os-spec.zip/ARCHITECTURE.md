# Personal OS --- Architecture Specification

## 1. Architectural Goal

Personal OS is a control layer over multiple authoritative systems.

The architecture must support:

-   Korean-first web/PWA UI on Mac and iPhone.
-   Personal task/goal storage.
-   Google Calendar integration.
-   Notion review/hierarchy integration.
-   Local filesystem indexing and mutation through a Mac background
    agent.
-   Local and replaceable AI.
-   Chat-based tool execution.
-   Remote approval with deferred local execution.
-   Safe auditability and undo.

## 2. High-Level Architecture

``` text
                         Personal OS
                    Web / PWA / iPhone
                              |
                    Backend / Control API
                              |
                     Agent Orchestrator
             +----------------+----------------+
             |                |                |
        Personal DB       Notion API      Google Calendar
             |
      Command / Job Queue
             |
        Mac Local Agent
      +------+------+------+
      |             |      |
 Mac Local FS    iCloud   External Volumes
      |
 Local AI Runtime (optional)
```

AI is a cross-cutting service:

``` text
Chat / Planner
      |
   AI Router
   /      \
Local LLM  External/interactive model integration
      |
 Tool Layer
      |
 Tasks / Calendar / Notion / File Index / Action Queue
```

## 3. Recommended Component Boundaries

### 3.1 Web / PWA

Responsibilities:

-   Korean-first UI.
-   Authentication/session.
-   Today dashboard.
-   Task/goal management.
-   Archive browser.
-   Review metadata/navigation.
-   Chat.
-   Action-plan previews.
-   Approval UI.
-   Agent online/offline state.
-   Activity history.
-   Undo requests.

The web client must never receive arbitrary filesystem authority.

### 3.2 Backend / Control API

Responsibilities:

-   Business rules.
-   Task/goal CRUD.
-   Integration orchestration.
-   Action authorization.
-   Approval state.
-   Queue management.
-   Agent registration and communication.
-   Audit logs.
-   Chat tool execution.
-   AI routing.
-   Sync scheduling.
-   Source-of-truth enforcement.

The backend should issue narrow structured commands, never arbitrary
shell strings.

Bad:

``` json
{ "command": "rm -rf ..." }
```

Good:

``` json
{
  "operation": "MOVE",
  "sourceFileId": "...",
  "expectedSourcePath": "...",
  "destinationDirectoryId": "...",
  "expectedHash": "..."
}
```

### 3.3 Personal Database

Stores:

-   Tasks.
-   Goals.
-   Relationships.
-   File index.
-   File hashes.
-   Duplicate/relationship groups.
-   Notion page metadata index.
-   AI-derived metadata.
-   Action plans.
-   Approvals.
-   Jobs.
-   Agent state.
-   Execution/audit logs.
-   Optional timeblock planning metadata.

It does not own:

-   Google Calendar event bodies as canonical events.
-   Notion review bodies.
-   Actual user files.

### 3.4 Google Calendar Integration

Google Calendar owns events and committed timeblocks.

Integration responsibilities:

-   Read relevant calendars.
-   Normalize busy windows.
-   Create/update/delete Personal OS-created timeblocks with user
    intent.
-   Store external IDs only as references where needed.
-   Reconcile externally edited timeblocks.

Personal OS should tag or otherwise identify timeblocks it created when
the integration supports it.

### 3.5 Notion Integration

Notion owns review/journal/note content and hierarchy.

Integration responsibilities:

-   Discover configured roots.
-   Crawl/index accessible hierarchy.
-   Store page metadata and parent relationships.
-   Fetch bodies on demand for search/analysis.
-   Respect Notion rate limits and API constraints.
-   Detect changes using last-edited metadata or supported sync
    mechanisms.
-   Execute only structural/content operations that can be performed
    safely.

Do not silently reconstruct unsupported Notion features.

### 3.6 Mac Local Agent

A trusted, narrowly scoped background process.

Recommended lifecycle:

-   Installed once.
-   Starts automatically at macOS login.
-   No terminal needs to remain open.
-   Optionally exposes a menu-bar status UI.
-   Authenticates to Personal OS backend.
-   Maintains a secure outbound connection or polls securely for jobs.
-   Receives only structured approved jobs.
-   Validates preconditions.
-   Executes filesystem operation.
-   Reports result.

Responsibilities:

-   Scan configured roots.
-   Read file metadata.
-   Calculate hashes.
-   Extract supported local content.
-   Observe configured volumes.
-   Execute approved mkdir/rename/move/trash jobs.
-   Maintain local execution safeguards.
-   Optionally invoke local AI runtimes.
-   Report storage and agent status.

Non-responsibilities:

-   Arbitrary remote shell.
-   Permanent delete.
-   Autonomous destructive cleanup.
-   Access outside configured roots without explicit configuration.

## 4. Mac Agent Transport

Prefer a design where the Mac Agent initiates outbound communication.

Reasons:

-   Avoid exposing a local inbound port directly to the public internet.
-   Easier NAT/firewall behavior.
-   Cleaner remote iPhone workflow.

Possible implementations:

-   Secure WebSocket initiated by agent.
-   HTTPS long polling.
-   Periodic job polling for v1.

For v1, reliability and simplicity are more important than real-time
sophistication.

The backend should maintain:

-   `ONLINE`
-   `OFFLINE`
-   `LAST_SEEN`
-   current agent version
-   configured capabilities

## 5. Filesystem Action Lifecycle

Every mutation follows a state machine.

``` text
DRAFT
  |
  v
PREVIEW_READY
  |
  | user approves
  v
APPROVED
  |
  +---- Mac offline ----> QUEUED
  |                         |
  |                         | reconnect
  +-------------------------+
                            v
                        DISPATCHED
                            |
                        VALIDATING
                         /      \
                        /        \
                  invalid        valid
                    |              |
                  BLOCKED       EXECUTING
                                   |
                              +----+----+
                              |         |
                           SUCCEEDED   FAILED
```

Cancellation should be supported before execution where practical.

## 6. Approval Contract

A filesystem mutation is executable only if an approved plan exists.

An approval record should bind to:

-   User.
-   Action plan ID.
-   Exact operation set or immutable plan version.
-   Timestamp.
-   Optional expiry.
-   Relevant preconditions.

Changing a plan after approval invalidates the approval.

The Mac being offline does not invalidate an approval by itself.

Before execution, the Mac Agent must revalidate assumptions such as:

-   Source still exists.
-   Source identity still matches expected file ID/hash/metadata.
-   Destination is available.
-   External volume is mounted when required.
-   No unsafe overwrite occurs.

If assumptions fail, mark the action `BLOCKED` or `NEEDS_REVIEW`; do not
improvise.

## 7. Filesystem Operation Rules

### Read

May run automatically inside configured roots.

### Create Directory

May be allowed automatically when it is part of an already approved move
plan. Standalone folder creation policy may be configurable.

### Rename

Requires approval.

Must record:

-   Old path/name.
-   New path/name.
-   File identity.
-   Result.

### Move

Requires approval.

Must:

-   Avoid accidental overwrite.
-   Handle cross-volume copy+verify+remove semantics safely.
-   Verify successful destination creation before removing the source
    when crossing filesystems.
-   Record original and resulting locations.

### Trash

Requires approval.

Means moving to macOS Trash or using an equivalent recoverable system
operation.

### Permanent Delete

Forbidden.

Do not expose a permanent-delete endpoint, tool, command type, hidden
flag, or fallback.

## 8. Undo Architecture

Each successful mutation produces an inverse-operation candidate.

Example:

``` text
MOVE A -> B
inverse: MOVE B -> A
```

Undo is not blindly guaranteed.

Before undo:

-   Verify target identity.
-   Verify original destination is available.
-   Check conflicts.
-   Ensure no subsequent action invalidated the inverse.

If safe, execute after appropriate confirmation policy.

If not safe, show a recovery plan.

## 9. File Indexing Pipeline

``` text
Configured Roots
      |
Directory Scan
      |
Basic Metadata
      |
Stable File Identity Strategy
      |
Size-based candidate grouping
      |
Content Hash
      |
Content extraction when supported
      |
AI / Embedding enrichment when useful
      |
Personal DB index
```

Avoid re-hashing unchanged large files unnecessarily.

Track enough metadata to detect likely changes:

-   Path.
-   Size.
-   Modified time.
-   Filesystem identifiers where reliable.
-   Last indexed time.
-   Hash status/version.

## 10. Duplicate Strategy

### Exact

Strong content hash is authoritative.

### Near Duplicate

A scored relation, never presented as exact identity unless hash
confirms it.

Potential features:

-   Normalized filename.
-   Same extension/type.
-   Similar size.
-   Text similarity.
-   Embedding similarity.
-   Image perceptual hashes in a later phase.
-   Local LLM judgment for ambiguous groups.

## 11. Notion Sync Architecture

Index metadata recursively from configured review roots.

Suggested local representation:

``` text
NotionPageIndex
- notionPageId
- parentNotionPageId
- rootNotionPageId
- title
- kind
- reviewDate
- depth
- computedPath
- propertiesJson
- lastEditedAt
- lastIndexedAt
- syncStatus
```

Full body retrieval should be on demand or cached temporarily.

Do not treat cached body content as canonical.

### Reorganization

Before any automated Notion restructuring:

1.  Build proposed tree change.
2.  Show preview.
3.  Determine whether the integration can perform the operation
    losslessly.
4.  If not, provide a manual instruction instead.
5.  If using copy/recreate workflow, create destination first.
6.  Validate copied content.
7.  Only then archive/remove the original if explicitly approved.

## 12. Calendar / Timeblock Architecture

### Inputs

-   Tasks.
-   Deadlines.
-   Estimated durations.
-   Priority.
-   Goal context.
-   Existing Google Calendar events.
-   User planning preferences.

### Planner Output

A proposal, not immediately committed state.

``` text
TimeblockProposal
- taskId
- startAt
- endAt
- rationale
- confidence
```

The user may edit or accept the proposal.

Accepted blocks are written to Google Calendar.

Store Google event IDs as references.

If the user later edits the event directly in Google Calendar, Google
Calendar wins.

## 13. Chat and Tool Architecture

Chat must use explicit tools.

Example tool groups:

``` text
tasks.*
goals.*
calendar.*
notion.*
files.*
actions.*
agent.*
```

Possible tools:

``` text
tasks.search
tasks.create
tasks.update
tasks.complete

goals.search
goals.create
goals.update

calendar.list_events
calendar.find_free_time
calendar.propose_timeblocks
calendar.commit_timeblocks

notion.search_pages
notion.get_page
notion.get_tree
notion.propose_reorganization

files.search
files.get_storage_summary
files.find_duplicates
files.propose_move
files.propose_rename
files.propose_trash

actions.get_plan
actions.approve
actions.cancel
actions.undo

agent.get_status
```

Mutation tools must enforce server-side policy regardless of what the
LLM requests.

The model must never be able to bypass approval by selecting a different
tool.

## 14. AI Router

Define an internal interface such as:

``` text
generateText()
generateStructured()
embed()
rerank()
```

Providers may include:

-   Local model runtime.
-   Local embedding model.
-   Future external API.
-   Interactive ChatGPT/Codex workflows outside the automated backend.

No domain service should depend directly on one model vendor.

Basic product functions must remain available without AI.

## 15. Local AI

The target Mac has an M4 Pro and 48 GB unified memory.

Design implications:

-   Local inference is viable.
-   Prefer model/runtime abstraction.
-   Do not require one specific model in the core architecture.
-   Keep models outside the Personal OS source repository.
-   Track model storage separately.
-   Allow AI jobs to be skipped or deferred when the Mac is offline.

Potential local tasks:

-   File classification.
-   Summaries.
-   Tag suggestions.
-   Embeddings.
-   Review analysis.
-   Near-duplicate analysis.
-   Simple timeblock reasoning.

## 16. Security Principles

-   Least privilege.
-   Explicit configured filesystem roots.
-   Structured commands only.
-   No arbitrary shell execution from chat/backend.
-   No permanent deletion.
-   Server-side approval enforcement.
-   Immutable action-plan version after approval.
-   Preconditions before execution.
-   Audit every mutation.
-   Secrets never committed to Git.
-   OAuth tokens stored securely.
-   Local agent credentials stored using appropriate macOS secure
    storage where practical.
-   Sensitive file contents should prefer local processing when
    possible.

## 17. Suggested v1 Deployment Shape

Keep operations simple.

Possible starting shape:

``` text
Frontend/PWA
    |
Backend API
    |
Managed PostgreSQL
    |
Google / Notion integrations

Mac:
Local Agent
Local AI runtime (optional)
```

Do not introduce microservices unless a real boundary requires them.

A modular monolith backend is preferable for v1.

## 18. Reliability Requirements

-   Integrations may fail independently.
-   File action jobs must be idempotent or safely retryable.
-   Never assume an external drive remains mounted.
-   Never assume a path remains unchanged between approval and
    execution.
-   Never assume Notion hierarchy is unchanged since last sync.
-   Never assume Calendar state is unchanged since planning.
-   Surface stale-plan conflicts rather than silently overriding current
    state.

## 19. Observability

At minimum capture:

-   Integration sync errors.
-   Agent heartbeat.
-   Job lifecycle.
-   Filesystem mutation result.
-   Approval history.
-   Calendar write result.
-   Notion sync result.
-   AI provider/runtime used for automated operations.
-   User-visible error reason.

Avoid logging unnecessary private document contents.
