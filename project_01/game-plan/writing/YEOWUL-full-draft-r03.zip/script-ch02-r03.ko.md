# CH02 — 남아 있던 목소리

- Packet: `YEOWUL-FULL-v3`
- Revision: `r03`
- Status: `draft`
- Fixed preceding continuity: accepted `C_PR_01..05` + working-base/r03 `C_PR_06..16` + `C_SYS_04` + focused r03 CH01
- Coverage: focused r03 revision of complete CH02 assignment: `C_CH02_01..08`, `C_CH02_O1..O3`, `C_D06..D10`, `C_Q02`, `C_H_D06..D10`, `C_H_Q02`, `C_H_V02`.

## C_CH02_01 — 남은 소리를 보러 가는 약속

### Context
- Place: L02 departure → L07 sound booth.
- Cast: P00, P01, P05.
- Entry: K05 and the V02 appointment made in revised C_CH01_08. P00/P01 arrive together; no CH02 evidence or K is pre-granted.
- Exit: E12 is acquired from P05's actual work sheet. P05 demonstrates live microphone input, local-file playback and external output with harmless consented material; E11/E14 are not yet compared.
- E/S/K/B: creates E12 only. No Q02 statement is defined here and no B changes.
- Effects: fulfills the appointment; P01's own chair sample remains private and is not copied into the case.
- Repeat/resume: once the path demo and E12 rows are seen, revisit starts from the last unchecked row rather than replaying the entire demonstration.

### Script

*점심 전, 여백과 모눈은 휴게실에서 연회장으로 걸어간다. 전날 처음 왔던 동쪽 음향 부스 문에는 `점검 중 — 들어오기 전에 노크`라는 종이가 새로 붙어 있다. 모눈이 두 번 노크하려다 한 번만 한다.*

**P01 | 나모눈 [S_CH02_01_0001]**

어제는 마이크가 죽어서 묵념했는데, 오늘은 누가 죽었는지 써 붙였네.

**P00 | 나여백 [S_CH02_01_0002]**

장비 얘기만 그렇게 말하자.

*문이 열리고 소해금이 나온다. 해금은 모눈의 말을 들은 듯 입을 다물었다가, 문에 붙인 종이를 떼어 뒤집는다. 뒷면에는 `마이크 2번 잡음`이라고 적혀 있다.*

**P05 | 소해금 [S_CH02_01_0003]**

맞아요. 오늘은 장비만 죽었다고 합시다. 저도 어제처럼 말할 기분은 아니네요.

**P05 | 소해금 [S_CH02_01_0004]**

들어오세요. 어제 약속한 건 `늦게 들린 안내가 어떻게 나갔는지 확인할 수 있는 범위`까지였죠. 제가 먼저 기능을 다시 보여 드릴게요. 사람 얘기는 그 다음에.

*부스 안은 전날보다 정리되어 있다. 믹서 오른쪽에는 작은 로컬 플레이어 화면, 왼쪽에는 마이크 입력 채널, 아래에는 종이 진행표가 놓여 있다. 해금은 모눈 쪽으로 작은 탁상 스피커를 돌린다.*

**P05 | 소해금 [S_CH02_01_0005]**

세 길이 있습니다. 지금 말하는 마이크를 밖으로 보내는 길. 이미 있는 파일을 이 부스에서 재생하는 길. 그리고 파일을 만들기만 하고 밖으로 안 보내는 길.

**P01 | 나모눈 [S_CH02_01_0006]**

어제도 그랬어요. 켜져 있어도 밖으로 안 나갈 수 있다고.

**P05 | 소해금 [S_CH02_01_0007]**

기억했네요. 오늘은 그걸 더 정확히 볼 겁니다. 대신 네 목소리를 시험에 쓰지는 않을게요.

**P00 | 나여백 [S_CH02_01_0008]**

제 목소리는 괜찮습니다. 지금 이 기능 확인용으로 짧게 쓰는 데 동의합니다. 사건 기록과 별개로요.

**P05 | 소해금 [S_CH02_01_0009]**

좋습니다. 용도는 `지금 이 자리에서 입력과 출력 경로 확인`, 저장 안 함.

*해금이 마이크 채널을 올리고 연회장 출력은 닫아 둔다.*

**P00 | 나여백 [S_CH02_01_0010]**

하나, 둘. 입력 확인.

*입력 표시등만 움직인다. 연회장에서는 소리가 나지 않는다.*

**P05 | 소해금 [S_CH02_01_0011]**

지금은 `마이크 입력 있음 / 외부 출력 없음`. 다음은 제가 준비한 무음 뒤 딸깍 소리 파일입니다. 사람 목소리 없습니다.

*해금이 로컬 플레이어에서 `click_test.wav`를 누른다. 탁상 스피커에서 짧은 딸깍 소리가 난다. 마이크 입력 표시등은 움직이지 않는다.*

**P01 | 나모눈 [S_CH02_01_0012]**

말하는 사람 없어도 스피커는 소리 낼 수 있네.

**P05 | 소해금 [S_CH02_01_0013]**

맞아요. 다만 `스피커에서 소리가 났다`만 보고 어떤 길을 썼는지는 따로 확인해야 해요.

*해금이 종이 진행표를 여백 앞으로 민다. 오른쪽 가장자리에는 접힌 색인 탭이 세로 칸 하나를 가리고 있다.*

#### E12 — 음향 진행표

> `18:10 정산 안내 연습`  
> `20:18 조명 확인 신호`  
> `20:20 전원 복귀 확인`  
> `20:30 정산 안내`  
>  
> 작성·사용: 소해금의 현장 작업표.  
> 오른쪽 `예정 경로` 칸은 접힌 색인 탭 아래에 있으며 요청하면 펼쳐 볼 수 있다.  
> 일정표는 예정과 작업 순서를 적은 것이며, 적혀 있다는 사실만으로 실제 실행을 증명하지 않는다.

**P00 | 나여백 [S_CH02_01_0014]**

이 오른쪽 접힌 칸도 봐도 됩니까?

**P05 | 소해금 [S_CH02_01_0015]**

네. 숨긴 게 아니라 어제 케이블 번호 붙이다 접힌 겁니다. 다만 여기 적힌 건 `예정 경로`예요. 실제로 그 경로를 썼다는 완료 확인표는 아닙니다.

*해금이 탭을 펼친다. `18:10 녹음 연습 / 20:18 콘솔 신호 / 20:20 콘솔 확인 / 20:30 마이크 안내 예정`이라고 적혀 있다. 20:30 칸에는 완료 서명이나 체크 표시가 없다.*

**P00 | 나여백 [S_CH02_01_0016]**

20시 30분은 마이크 안내 `예정`이었군요. 실행 여부는 이 표만으로 정하지 않겠습니다.

**P05 | 소해금 [S_CH02_01_0017]**

그렇게 봐 주세요. 진행표는 제가 하려던 일을 적은 종이지, 시간이 지나면 저절로 사실이 되는 종이는 아니니까.

**P01 | 나모눈 [S_CH02_01_0018]**

그럼 어제 이모가 들은 건, 이 표 말고 소리 자체도 봐야 돼?

**P00 | 나여백 [S_CH02_01_0019]**

응. 내가 현장에서 기록한 출력하고, 여기에 남아 있는 원래 작업 자료가 있으면 서로 비교해야 해.

**P05 | 소해금 [S_CH02_01_0020]**

18시 10분 `정산 안내 연습`은 파일이 남아 있습니다. 표 선생님이 연습용 녹음을 남기는 것까지는 알고 있었고요. 그 파일은 무슨 확인을 위해 보는지 먼저 정하고 열겠습니다. 연습용 파일을 다른 용도로 쓰는 일은 더 만들고 싶지 않아요.

**P00 | 나여백 [S_CH02_01_0021]**

20시 30분에 들린 안내가 그 시각의 직접 발화였는지 확인하려는 겁니다. 파일의 존재 자체를 사람의 위치 증명으로 쓰지는 않겠습니다.

*해금은 잠깐 대답하지 않고 음향 진행표를 다시 자기 쪽으로 당겨 18:10 행에 손가락을 올려 둔다.*

**P05 | 소해금 [S_CH02_01_0022]**

그 범위라면 다음으로 들려드릴 수 있습니다. 먼저 이 표를 기록해 두세요.

### Interrupted acquisition / resume

*음향 진행표를 기록하는 도중 장면이 중단되면, 재방문 시 이미 확인한 행과 펼친 `예정 경로` 칸은 그대로 유지한다. 처음부터 기능 시연을 반복하지 않는다.*

**P05 | 소해금 [S_CH02_01_0081]**

진행표는 여기 있습니다. 어디까지 적으셨는지만 확인하고 그 다음 줄부터 보죠. 예정표를 두 번 본다고 실행 기록이 두 개가 되지는 않으니까요.

### Current revisit

**P05 | 소해금 [S_CH02_01_0091]**

음향 진행표는 제 진행표입니다. 20시 30분 `마이크 안내 예정`까지는 적혀 있지만, 실제 출력 방식은 이 종이만으로 결론 내리지 마세요.

**P00 | 나여백 [S_CH02_01_0092]**

예정과 실행을 분리해 두겠습니다. 다음은 18시 10분 연습 파일과 현장 출력 기록 비교입니다.

---

## C_CH02_02 — 같은 문장보다 작은 소리

### Context
- Place: L07 sound booth.
- Cast: P00, P01, P05.
- Entry: E12 held from C_CH02_01; P00 retains the consented public-output capture from C_PR_14; P01 retains only her private chair-squeak sample.
- Exit: E11 is opened because the already-seen 18:10 rehearsal row is under inspection; E14 is created by comparing E11 with P00's public capture. The sole live `S_Q02_v1` is first spoken here.
- E/S/K/B: acquire E11/E14; define S_Q02_v1 exactly once; no K/B.
- Effects: the comparison establishes only observable audio identity candidates; it does not reveal who pressed playback or whether permission covered public reuse.
- Repeat/resume: opened originals stay opened; an interrupted alignment resumes at the last comparison position. Before Q02 success, P05 continues to defend S_Q02_v1; after success, this scene is historical only.

### Script

*해금은 로컬 플레이어에서 날짜 폴더를 연다. 파일 목록에는 작업용 짧은 테스트와 `1810_정산안내_연습`이 보인다. 그녀는 재생 버튼을 누르기 전에 손을 뗀다.*

**P05 | 소해금 [S_CH02_02_0001]**

이 파일은 18시 10분 리허설에서 제가 만든 작업 녹음입니다. 연습 내용을 확인하려고 남긴 파일이고, 지금 수사 확인을 위해 진새벽 경위가 열람 가능 범위를 정해 둔 상태예요.

**P00 | 나여백 [S_CH02_02_0002]**

원본 파일을 제 장비로 복사하지 않고 여기서 재생하고, 필요한 구간은 기록된 사본과 대조하겠습니다.

**P05 | 소해금 [S_CH02_02_0003]**

좋습니다. 그리고 모눈이 파일은 비교 자료로 쓰지 않을게요. 그건 모눈이 개인 과제용으로 허락받은 의자 소리였죠.

**P01 | 나모눈 [S_CH02_02_0004]**

내 건 내가 갖고 있어요. 필요하면 내가 들어보고 `비슷한 종류`인지 말할 수는 있는데, 사건 파일로 넘기지는 않을래요.

**P00 | 나여백 [S_CH02_02_0005]**

그걸로 충분해. 네 파일 없이도 원본 둘을 비교할 수 있어야 해.

*해금이 재생한다. 먼저 자신의 짧은 셋업 카운트가 들린다.*

**리허설 파일 — 소해금의 셋업 음성 [S_CH02_02_0006]**

리허설 하나, 둘. 표 선생님, 시작하시면 됩니다.

*잠깐의 숨소리 뒤 표문식의 목소리가 이어진다.*

**리허설 녹음 — 표문식 [S_CH02_02_0007]**

잠시 뒤, 정산 자료를… 아, 이 의자부터 좀… 다시 하겠습니다.

*`의자`의 마지막 `자`와 겹치듯 짧은 `끼익` 소리가 난다. `좀…` 뒤의 끊김 길이도 분명하다. 해금이 재생을 멈춘다.*

#### E11 — 리허설 녹음

> 18:10 소해금·표문식 리허설 원본.  
> 셋업 카운트 뒤 실제 문구: `잠시 뒤, 정산 자료를… 아, 이 의자부터 좀… 다시 하겠습니다.`  
> `의자`의 끝 음절과 짧은 의자 삐걱임이 겹치고, 같은 위치에서 발화가 끊긴다.  
> 파일이 존재한다는 사실만으로 20:30 공개 재생이나 표문식의 당시 위치를 증명하지 않는다.

**P01 | 나모눈 [S_CH02_02_0008]**

끼익은 내 의자 녹음에도 있었어. 근데 내 거랑 똑같은 소리인지는 모르겠어. 의자는 원래 끌면 끼익하잖아.

**P05 | 소해금 [S_CH02_02_0009]**

그 판단이 맞아요. `의자 소리가 났다`만으로 같은 파일이라고 하면 안 됩니다.

**P00 | 나여백 [S_CH02_02_0010]**

이제 제가 어제 허락받아 기록한 공개 출력 구간을 여기서 같이 보겠습니다. 제 파일은 `20:30 공개 안내 / 현장 출력`으로 저장했고, 당시 연회장에서 실제 스피커 출력을 기록한 겁니다.

*여백이 자기 작업용 녹음기의 해당 구간을 재생한다. 셋업 카운트는 없다. 대신 연회장의 낮은 잔향 뒤 같은 문장이 나온다.*

**공개 출력 기록 — 표문식의 목소리 [S_CH02_02_0011]**

잠시 뒤, 정산 자료를… 아, 이 의자부터 좀… 다시 하겠습니다.

*이번에도 `의자`의 `자`에 짧은 삐걱임이 같은 식으로 겹치고, `좀…` 뒤가 같은 길이로 끊긴다. 여백은 두 파형을 나란히 확대한다. 접근성 자막에는 말과 비언어음의 위치가 시간축에 함께 표시된다.*

**P00 | 나여백 [S_CH02_02_0012]**

문장이 같다는 것 말고, 겹치는 위치를 보겠습니다.

*화면에 두 줄이 맞춰진다.*

> **리허설:** `의[자+끼익]부터 좀… | 다시 하겠습니다.`  
> **공개 출력:** `의[자+끼익]부터 좀… | 다시 하겠습니다.`

**P01 | 나모눈 [S_CH02_02_0013]**

말을 똑같이 다시 한 거면 의자까지 똑같은 글자에서 울 수도 있어?

**P00 | 나여백 [S_CH02_02_0014]**

우연히 비슷한 의자 소리가 날 수는 있어. 그런데 같은 비언어음이 같은 음절에 겹치고, 말이 끊기는 위치까지 같이 맞는지는 따로 판단해야 해.

**P05 | 소해금 [S_CH02_02_0015]**

파형으로 봐도 되고, 소리를 못 듣거나 듣기 어려우면 자막의 겹침 위치로 봐도 됩니다. 같은 판단에 도달할 수 있어야 하니까.

#### E14 — 안내 음성 비교

> 여백의 20:30 현장 출력 기록과 18:10 리허설 원본을 나란히 둔 비교.  
> 동일한 문장뿐 아니라, 동일한 의자 삐걱임이 동일한 끊긴 음절 위치에 겹치고 중단 지점이 맞는다.  
> 20:30 현장 기록은 스피커 출력이 실제로 있었음을 독립적으로 남기지만, 그 안의 음성 내용은 18:10 리허설 원본과 같은 발화 기원을 가질 수 있다.  
> 한 발화 기원을 두 개의 독립된 생존 목격처럼 세지 않는다.

*해금은 파형을 보다가 화면 아래쪽 케이블을 괜히 한 번 눌러 본다.*

**P00 | 나여백 [S_CH02_02_0016]**

어제 봉만실 선생님이 `문식 씨가 부스에 들어왔느냐`고 물었을 때, 소해금 씨는 안내가 예정대로 나갔다고 답했습니다. 지금은 더 직접적으로 묻겠습니다. 그 안내는 어떤 방식이었습니까?

*해금이 바로 대답하지 않는다. 손가락으로 음향 진행표의 20:30 행을 두 번 두드린다.*

**P05 | 소해금 [S_Q02_v1]**

그 안내는 문식 씨가 그때 마이크로 직접 말한 거예요.

*모눈이 해금을 보다가 자기 녹음기 대신 파형 화면을 본다.*

**P01 | 나모눈 [S_CH02_02_0017]**

직접 말한 거면, 아까 리허설이랑 이렇게 똑같을 수 있는지 보는 거지?

**P00 | 나여백 [S_CH02_02_0018]**

응. `목소리가 들렸다`와 `그 사람이 그때 그 자리에 있었다`를 같은 문장으로 두지 말자.

> **CH02 objective:** `안내 음성이 그 시각의 대면을 대신할 수 있는지 살피자.`

### Interrupted acquisition / resume

*리허설 녹음 재생 또는 안내 음성 비교 정렬 도중 장면이 중단되면, 이미 열람한 리허설 녹음은 다시 새 증거로 획득하지 않는다. 재방문 시 마지막 확인 지점에서 두 파일 정렬만 이어 간다. 해금의 최초 설명은 비교가 끝난 뒤 처음 듣는다.*

**P05 | 소해금 [S_CH02_02_0081]**

연습 파일은 이미 열었습니다. 다시 처음부터 제 설명을 들을 필요는 없어요. 두 구간이 어디까지 맞는지부터 이어서 보죠.

### Current revisit — before Q02 correction

**P00 | 나여백 [S_CH02_02_0091]**

현재 가진 건 18시 10분 리허설 원본, 20시 30분 현장 출력과의 비교, 그리고 작업 진행표입니다. 같은 문장이라는 이유만이 아니라 같은 비언어음과 끊김이 같은 위치에 겹치는지 봐야 합니다.

**P05 | 소해금 [S_CH02_02_0092]**

제 설명은 아직 `20시 30분 직접 마이크 발화`입니다. 틀렸다고 보려면 제 말이 아니라 자료하고 맞지 않는 지점을 제시해 주세요.

### Historical revisit — after Q02 correction

**P00 | 나여백 [S_CH02_02_0093]**

이 장면에서 처음 들은 `그때 직접 마이크로 말했다`는 설명은 원진술로 남깁니다. 이후 정정은 별도 기록으로 보존합니다. 원진술을 지워서 처음부터 솔직했던 것처럼 만들지는 않습니다.

---

## C_H_V02 — 음향 약속 재방문 힌트

### Context
- Place/cast: P00's notebook; actual booth actions occur only when P00/P01/P05 are legitimately in L07.
- Entry: V02 not started, E12-only, E11-without-E14, E11/E14-held, interrupted comparison, K06-complete or Q02-complete.
- Exit/effects: hints do not create E/K, press playback, change consent or correct S_Q02_v1.
- E/S/K/B: may name held E12/E11/E14 in metadata; visible Korean describes the actual work sheet/file/comparison rather than IDs.
- Repeat/resume: state-specific text distinguishes pre-visit, partial comparison, completed D06 and completed Q02.

#### Deterministic selector (normative)
- Return exactly one Korean S line per hint request. Completion/advanced-state guards beat level selection; a missing acquisition beats a recent-error or higher-level request. Interruption preserves the current held-source state and never concatenates another line.
- Q02 already corrected, any H0–H4 → `S_H_V02_0044`.
- K06 complete but Q02 unresolved, any H0–H4 → `S_H_V02_0043`.
- Appointment not started or E12 missing, any H0–H4 → `S_H_V02_0012`.
- E12 held but E11 missing, any H0–H4 → `S_H_V02_0021`.
- E11 held but E14 missing: interrupted comparison → `S_H_V02_0032`; otherwise any H0–H4 → `S_H_V02_0022`.
- E11/E14 held but K06 unresolved: H0 `S_H_V02_0003`, H1 `S_H_V02_0011`, H2 `S_H_V02_0023`, H3/H4 `S_H_V02_0031`.

### H_V02_0

**Before returning to L07**

**P00 | 나여백 [S_H_V02_0001]**

방과 동선 확인 뒤에 남은 건 `늦게 들린 목소리`입니다. 소해금 씨와 잡아 둔 음향 부스 약속으로 돌아가세요. 먼저 콘솔에서 마이크 입력, 저장 파일 재생, 외부 출력이 어떻게 나뉘는지 보고 현장 작업표를 확인하면 됩니다.

**After C_CH02_01 but before E11/E14**

**P00 | 나여백 [S_H_V02_0002]**

음향 진행표의 18:10 `정산 안내 연습` 행을 이미 확인했습니다. 그 행을 근거로 소해금 씨에게 해당 리허설 원본을 현장에서 재생해 달라고 요청하세요. 20:30 공개 출력은 여백의 허가된 현장 기록과 비교할 수 있습니다.

**If E11/E14 already held**

**P00 | 나여백 [S_H_V02_0003]**

필요한 리허설 원본과 공개 출력 비교는 이미 갖고 있습니다. 같은 파일을 다시 요구하지 말고, 두 출력이 같은 녹음 구간인지 근거를 정리하세요.

### H_V02_1

**If the appointment has not started or E12 is missing**

**P00 | 나여백 [S_H_V02_0012]**

아직 부스의 기본 경로나 작업표를 보지 않았다면 소리의 정체부터 단정하지 마세요. 해금 씨와 약속한 자리에서 마이크 입력과 파일 재생을 구분하고, 어제 쓴 작업표부터 펼쳐 보면 됩니다.

**If the booth paths/E12 are already known**

**P00 | 나여백 [S_H_V02_0011]**

`콘솔이 켜져 있었다`와 `사람이 마이크 앞에 있었다`는 다른 사실입니다. 이 부스는 파일 재생, 마이크 입력, 외부 출력이 따로 움직입니다. 어떤 소스가 같은 출력으로 나갔는지 확인하세요.

### H_V02_2

**If only E12 held**

**P00 | 나여백 [S_H_V02_0021]**

지금 가진 작업표는 예정표입니다. 18시 10분 연습 행은 해당 리허설 원본을 보여 달라고 요청할 이유가 되지만, 20시 30분 실제 실행을 증명하지는 않습니다. 음향 부스에서 그 연습 원본을 듣거나 자막으로 확인하세요.

**If E11 held but E14 not complete**

**P00 | 나여백 [S_H_V02_0022]**

리허설 원본에서 `의자` 끝 음절에 겹친 삐걱임과 말이 끊기는 위치를 표시하세요. 그다음 여백의 허가된 20시 30분 현장 출력 기록을 나란히 놓고 같은 위치가 맞는지 확인하세요.

**If E11/E14 held**

**P00 | 나여백 [S_H_V02_0023]**

필요한 원본과 비교 기록은 이미 있습니다. 모눈의 개인 의자 파일을 사건 자료로 넘기거나, 같은 자료를 다시 열어 새 증거처럼 만들 필요는 없습니다.

### H_V02_3

**If comparison is interrupted before E14 is complete**

**P00 | 나여백 [S_H_V02_0032]**

비교가 중간에 멈췄다면 이미 맞춘 구간은 그대로 두세요. 리허설과 현장 출력에서 삐걱임과 말 끊김이 어느 음절에 놓이는지 남은 구간만 맞추면 됩니다.

**If E11/E14 are held**

**P00 | 나여백 [S_H_V02_0031]**

먼저 `같은 목소리`가 아니라 `같은 녹음 구간`인지 판단하세요. 결정적인 건 사람 음색이 아니라 같은 비언어음과 같은 끊김이 같은 위치에 겹치는가입니다. 그 뒤에야 해금 씨의 `20시 30분 직접 마이크 발화` 주장을 따질 수 있습니다.

### H_V02_4

**If appointment not started**

**P00 | 나여백 [S_H_V02_0041]**

음향 부스로 가서 약속을 이어가세요. 먼저 마이크 입력과 파일 재생 경로를 확인하고, 작업표의 18시 10분 연습 행을 본 뒤 그 원본을 현장에서 들어 보세요. 여백의 20시 30분 현장 출력 기록과 나란히 비교해 같은 구간인지 확인한 다음에야 해금 씨의 `그때 직접 마이크로 말했다`는 설명을 따질 수 있습니다.

**If interrupted during comparison**

**P00 | 나여백 [S_H_V02_0042]**

중단 전에 리허설 원본을 이미 열었다면 처음부터 다시 틀지 않아도 됩니다. 멈췄을 때 맞춰 둔 지점부터 이어서 두 출력이 같은 구간인지 확인하세요.

**If D06/K06 already solved**

**P00 | 나여백 [S_H_V02_0043]**

두 출력이 같은 녹음 구간이라는 근거까지 확인했습니다. 이제 `20시 30분에 직접 마이크로 말했다`는 해금 씨의 현재 설명이 그 자료와 맞는지 바로 물으세요. 아직 본인이 정정하지 않은 내용을 답으로 미리 채우지는 않습니다.

**If Q02 already solved**

**P00 | 나여백 [S_H_V02_0044]**

해금 씨의 설명은 이미 정정됐습니다. 같은 고백을 다시 요구하지 말고, 이제 `녹음이 만들어진 때 / 나중에 출력된 때 / 사람의 실제 위치`를 서로 다른 칸으로 나누세요.

---

## C_CH02_03 — 시간표를 지키라는 말

### Context
- Place: L03 ballroom entrance handoff → L07 sound booth.
- Cast: handoff P00/P01/P02; booth P00/P05/P03.
- Entry: E11/E12/E14 held and S_Q02_v1 current. Before the adult authorization dispute, P02 physically meets P00/P01 and explicitly accepts same-place supervision of P01 in L02. D06 is not yet solved.
- Exit: P03/P05 establish schedule authority versus voice-use authority. Neither reveals the 20:30 operator action or permission correction. D06 opens.
- E/S/K/B: reads E11/E12/E14 and current S_Q02_v1; no new E/K/B and no corrected S.
- Effects: P01 stays in L02 with P02 while the adult booth dispute/D06/Q02 proceed.
- Repeat/resume: before Q02 success P05 continues to defend S_Q02_v1; after success this scene remains only an authority dispute and does not retroactively make P03 the playback director.

### Script

*비교를 마치고 세 사람이 연회장 입구로 나오자 봉만실이 휴게실 쪽에서 걸어온다.*

**P00 | 나여백 [S_CH02_03_0014]**

봉 선생님, 해금 씨하고 운영표 책임 얘기를 조금 더 확인해야 합니다. 그동안 모눈이와 휴게실에 같이 있어 주시겠습니까?

**P02 | 봉만실 [S_CH02_03_0015]**

그래요. 나도 휴게실에서 우산표 정리할 거예요. 모눈이는 내 눈앞에서 접수대 일만 시킬게요.

**P01 | 나모눈 [S_CH02_03_0016]**

알겠어. 나는 먼저 가서 접수표 정리할게. 이모 끝나면 와.

*여백은 모눈과 만실이 함께 휴게실로 들어가는 것을 확인한 뒤 부스로 돌아간다. 잠시 후 차무록이 연회장 쪽에서 서류철을 들고 온다.*

**P03 | 차무록 [S_CH02_03_0001]**

소해금 씨. 경찰 쪽에 어제 음향 진행표 제출하신다고 해서 확인하러 왔습니다. 정산 안내가 20시 30분으로 잡힌 건 제가 운영표에 넣은 거니까요.

**P05 | 소해금 [S_CH02_03_0002]**

시간을 넣은 사람이 목소리 사용 허락까지 한 사람은 아니죠.

**P03 | 차무록 [S_CH02_03_0003]**

저도 그렇게 말한 적 없습니다. 저는 `20시 30분 정산 안내 순서를 비우지 말라`고 했습니다.

**P05 | 소해금 [S_CH02_03_0004]**

그 말을 얼마나 세게 했는지는 빼시네요. 문식 선생님이 자리에 없으면 다음 순서가 다 밀린다고 계속 재촉했잖아요.

**P03 | 차무록 [S_CH02_03_0005]**

재촉한 건 맞습니다. 그렇다고 제가 누구 목소리를 어떤 방식으로 쓰라고 허락한 건 아닙니다. 운영 시간과 음원 권한은 제 담당 범위가 달라요.

*무록은 음향 진행표에 손을 대려다 여백이 먼저 종이 끝을 눌러 둔다.*

**P00 | 나여백 [S_CH02_03_0006]**

원본은 소해금 씨가 그대로 두고 설명해 주세요. 무록 씨는 운영표에서 20시 30분 슬롯을 정했다. 소해금 씨는 음향 방식과 실제 조작을 맡았다. 여기까지 맞습니까?

**P03 | 차무록 [S_CH02_03_0007]**

네. 그리고 그 슬롯이 실제로 어떤 소스로 나갔는지는 제가 부스 안에서 보지 않았습니다.

**P05 | 소해금 [S_CH02_03_0008]**

저는 부스 안에 있었습니다. 하지만 지금 묻는 게 `누가 시간표를 짰느냐`면 무록 씨 말이 맞고, `누구 목소리를 써도 된다고 허락했느냐`면 그 답은 무록 씨가 아닙니다.

**P03 | 차무록 [S_CH02_03_0009]**

그 부분까지 제 서명 칸으로 만들지 마세요. 없는 권한을 제가 가졌던 것처럼 보입니다.

**P05 | 소해금 [S_CH02_03_0010]**

없는 권한을 있는 것처럼 쓰지 말자는 말은 동의합니다.

*둘 사이가 잠깐 조용해진다. 여백은 음향 진행표 옆 빈 메모 칸에 `일정 권한 / 음성 사용 권한 분리`라고 적는다.*

**P00 | 나여백 [S_CH02_03_0011]**

시간표를 정한 책임과 다른 사람 목소리를 사용할 권한은 분리하겠습니다. 그리고 20시 30분에 실제로 무엇이 나갔는지는 두 분의 책임 공방보다, 아까 맞춰 본 리허설 원본과 현장 출력부터 보겠습니다.

**P03 | 차무록 [S_CH02_03_0012]**

그게 맞습니다. 같은 문장을 말했다는 이유로 같은 파일이라고 하셔도 안 되고요.

**P05 | 소해금 [S_CH02_03_0013]**

네. 그건 기술적으로도 그렇게 보면 안 됩니다.

> **Player task opens: D06 — `같은 목소리가 아니라 같은 녹음이라고 할 근거는?`**

### Current revisit — before D06

**P05 | 소해금 [S_CH02_03_0091]**

무록 씨가 20시 30분 순서를 잡았다는 것과, 실제로 어떤 음성이 나갔는지는 별개입니다. 사람 책임을 먼저 정하지 말고 두 출력의 소리 자체를 비교하세요.

**P03 | 차무록 [S_CH02_03_0092]**

제 역할은 일정 유지 요구까지입니다. 부스에서 보지 못한 조작을 제가 봤다고 기록하지 마세요.

### Historical revisit — after Q02

**P00 | 나여백 [S_CH02_03_0093]**

이 대화는 차무록의 일정 요구와 소해금의 음성 사용 책임을 구분한 기록으로 남습니다. 이후 재생 조작 정정이 생겨도, 차무록이 재생을 지시했다고 소급해서 바꾸지 않습니다.

---

## C_D06 — 같은 목소리가 아니라 같은 녹음이라고 할 근거는?

### Context
- Place: L07 sound booth after C_CH02_03; P01 remains in L02 with P02.
- Cast: P00, P05; P03 may remain present for the start but does not answer the technical task.
- Entry: E11 + E12 + E14 and current S_Q02_v1.
- Exit: success → K06 and makes Q02 immediately challengeable; it does not itself reveal the operator or permission facts.
- E/S/K/B: uses E11/E12/E14; branches incomplete, `voice_similarity_only`, `schedule_only`, `same_origin_as_independent`, success, retry.
- Effects: no corrected S, no E15, no guilt or live-presence finding.
- Repeat/resume: selected audio markers/draft survive wrong or incomplete attempts; revisit after K06 states only the shared recorded origin.

### Task setup

**P00 | 나여백 [S_D06_0001]**

같은 사람이 같은 문장을 두 번 말한 것과, 같은 녹음 구간이 두 번 쓰인 것은 다릅니다. 두 파일에서 사람이 일부러 맞추기 어려운 부분을 찾겠습니다.

> **D06:** `같은 목소리가 아니라 같은 녹음이라고 할 근거는?`

### Free clarification

**P05 | 소해금 [S_D06_0002]**

같은 사람이 같은 문장을 다시 읽으면 목소리는 당연히 비슷합니다. 그걸로 파일 재사용이라고 하실 건 아니죠?

**P00 | 나여백 [S_D06_0003]**

그래서 말 밖의 소리와 끊김 위치까지 보겠습니다. 듣기 대신 자막과 파형으로도 같은 지점을 확인할 수 있고요.

### B_D06_incomplete

*리허설 녹음/안내 음성 비교/음향 진행표 중 하나가 없거나, `같은 사람 목소리`만 제출하면 정답 판정 전에 무료 보류한다.*

**P00 | 나여백 [S_D06_0011]**

아직 `같은 화자`와 `같은 녹음 구간`을 구분할 자료가 부족합니다. 18시 10분 리허설 원본, 20시 30분 현장 출력 비교, 두 작업이 적힌 진행표를 먼저 갖추겠습니다.

> 여유 변화 없음. 선택한 자료와 작성 중 문장은 유지된다.

### B_D06_err_voice_similarity_only

**P00 | 나여백 [S_D06_0021]**

표문식 씨 목소리의 음색이 같으니 20시 30분 안내는 리허설 파일 재생이었다고 보겠습니다.

**P00 | 나여백 [S_D06_0022]**

그건 화자 동일성만 말합니다. 같은 사람이 직접 두 번 말해도 목소리는 비슷할 수 있어요. 파일 재사용을 말하려면 우연히 같은 목소리보다 더 구체적인 반복이 필요합니다.

**P05 | 소해금 [S_D06_0023]**

음색만으로 재생이라고 하면 음향실에서는 매일 같은 사람이 자기 녹음이 됩니다. 끊김과 비언어음 위치를 보세요.

> 완결된 잘못된 전제로 제출했으므로 여유 `-2`. 초안은 유지된다.

### B_D06_err_schedule_only

**P00 | 나여백 [S_D06_0031]**

음향 진행표에 18시 10분 연습과 20시 30분 안내가 둘 다 적혀 있으니, 같은 녹음을 쓴 것으로 보겠습니다.

**P00 | 나여백 [S_D06_0032]**

시간표는 두 항목이 예정됐다는 것만 보여 줍니다. `연습 파일이 있었다`와 `그 파일을 나중에 썼다` 사이를 일정표가 자동으로 연결하지는 않습니다.

**P05 | 소해금 [S_D06_0033]**

진행표를 재생 기록으로 읽으면 제가 적어 놓기만 한 모든 계획이 실행된 셈이 돼요. 이건 작업표이지 자동 로그가 아닙니다.

> 여유 `-2`. 이미 확보한 음향 진행표는 그대로 유지된다.

### B_D06_err_same_origin_as_independent

**P00 | 나여백 [S_D06_0041]**

리허설 녹음과 공개 출력 기록이 둘 다 표문식 씨 목소리를 담고 있으니, 두 자료가 독립적으로 20시 30분 생존을 뒷받침한다고 보겠습니다.

**P00 | 나여백 [S_D06_0042]**

안내 음성 비교의 공개 쪽은 `20시 30분 스피커 출력이 실제 있었다`는 독립된 현장 기록입니다. 하지만 그 안의 음성 내용이 리허설 녹음과 같은 녹음이라면, 발화 기원은 하나입니다. 같은 말의 복제본을 두 명의 목격처럼 셀 수 없습니다.

**P05 | 소해금 [S_D06_0043]**

같은 파일을 두 출력에서 들었다고 발화가 두 번 생기는 건 아닙니다. 공개 녹음은 출력이 있었다는 쪽에서만 별도 근거가 되죠.

> 여유 `-2`. 출처 독립성 설명이 다음 재시도에 강조된다.

### B_D06_success

**P00 | 나여백 [S_D06_0051]**

리허설 녹음과 안내 음성 비교는 같은 문장이라는 데서 끝나지 않습니다. `의자`의 마지막 음절에 같은 짧은 삐걱임이 겹치고, 그 뒤 같은 위치에서 문장이 끊겼다가 `다시 하겠습니다`로 이어집니다. 파형과 시간 맞춤 자막에서도 그 비언어음과 끊김이 같은 자리에 있습니다.

**P00 | 나여백 [S_D06_0052]**

따라서 20시 30분 공개 출력의 음성 구간은 18시 10분 리허설에서 만들어진 구간을 재사용한 것으로 판단할 수 있습니다. 음향 진행표는 두 작업이 존재한 순서를 보조하지만, 이 결론의 핵심은 소리 구간 자체의 동일성입니다.

**P05 | 소해금 [S_D06_0053]**

그 비교라면 반박 못 합니다. 같은 사람이 비슷하게 말한 수준이 아니라, 같은 구간이 맞습니다.

- Author state: **K06 획득:** E11과 20:30 공개 출력은 동일한 녹음 구간을 공유한다. 목소리 유사성이 아니라 동일 비언어음·중단 정렬이 근거다. 공개 현장 기록은 출력 발생은 독립적으로 증명하지만, 음성 내용은 독립된 두 번째 발화가 아니다.
- Author state: **Q02 사용 가능:** S_Q02_v1의 `그때 마이크로 직접 말함` 주장과 E12/E14/K06을 대조할 수 있다.

### B_D06_retry

**P00 | 나여백 [S_D06_0061]**

방금 선택한 자료는 남겨 두겠습니다. 다시 쓸 때는 `누가 말했는가` 대신 `같은 녹음이라고만 설명되는 반복이 무엇인가`에 답하겠습니다.

**P00 | 나여백 [S_D06_0062]**

필요하면 안내 음성 비교의 두 줄 자막에서 `자+끼익`과 끊김 막대를 먼저 맞춘 뒤 문장을 작성하죠.

### Current revisit

**P00 | 나여백 [S_D06_0091]**

두 음향이 같은 녹음 원본이라는 결론은 `20:30에 표문식이 어디 있었는가`가 아닙니다. `20:30 공개 출력에 18:10 리허설 녹음 구간이 재사용됐다`까지만 확정합니다.

---

## C_H_D06 — D06 힌트

### Context
- Place/cast: P00's notebook during the L07 technical comparison; no absent witness is summoned.
- Entry: D06 unresolved/revisited. Selector checks E11/E12/E14, recent named error and K06-complete state.
- Exit/effects: hints do not create K06/E15 or change S_Q02_v1; no 여유 change.
- E/S/K/B: missing-state text points to the actual booth action; held-state text may describe only already-opened audio features.
- Repeat/resume: alignment markers and recent failed premise survive interruption.

#### Deterministic selector (normative)
- Return exactly one Korean S line. Priority: `K06 complete` → `missing prerequisite` → eligible recent named error at H3/H4 → requested all-held level. Missing knowledge always wins over recent-error help.
- K06 complete, any H0–H4 → `S_H_D06_0042`.
- E12 missing → `S_H_D06_0001`; else E11 missing → `S_H_D06_0002`; else E14 missing → `S_H_D06_0003`, regardless of requested level.
- All held: H0 `S_H_D06_0004`, H1 `S_H_D06_0011`, H2 `S_H_D06_0021`, H3 `S_H_D06_0011`, H4 `S_H_D06_0041`.
- With all prerequisites held, recent `voice_similarity_only` at H3/H4 → `S_H_D06_0031`; recent `schedule_only` → `S_H_D06_0032`; recent `same_origin_as_independent` → `S_H_D06_0033`.
- Interrupted alignment uses the same selector from the held-source state; it does not replay acquisition or append another hint.

### H_D06_0

**If E12 missing**

**P00 | 나여백 [S_H_D06_0001]**

음향 부스에서 소해금 씨가 실제로 쓰던 진행표를 먼저 보세요. 18시 10분 연습과 20시 30분 안내가 별도 항목이라는 작업 맥락이 필요합니다.

**If E11 missing**

**P00 | 나여백 [S_H_D06_0002]**

진행표의 18시 10분 `정산 안내 연습` 행을 근거로 해금 씨에게 그 리허설 원본을 현장에서 재생해 달라고 요청하세요. 아직 해금 씨의 20시 30분 설명을 정정하지 않았어도, 이미 본 연습 행을 확인하기 위한 원본 열람은 가능합니다.

**If E14 missing**

**P00 | 나여백 [S_H_D06_0003]**

리허설 원본을 확인했다면 여백의 허가된 20시 30분 현장 출력 기록과 나란히 맞추세요. 모눈의 개인 의자 파일은 필요하지 않습니다.

**If all held**

**P00 | 나여백 [S_H_D06_0004]**

필수 자료는 있습니다. 두 음성에서 `같은 사람이면 원래 비슷한 부분` 말고, 매번 새로 생겨야 할 비언어음과 끊김 위치를 찾으세요.

### H_D06_1

**If a required source is missing**

**P00 | 나여백 [S_H_D06_0012]**

아직 원본 둘을 나란히 놓지 못했다면 목소리 인상으로 결론을 쓰지 마세요. 진행표에서 연습 행을 확인하고, 그 원본과 여백의 현장 출력 기록을 같은 화면에 놓는 것부터 끝내면 됩니다.

**If all required sources are held**

**P00 | 나여백 [S_H_D06_0011]**

`의자`의 마지막 음절을 보세요. 두 파일 모두 같은 음절에 짧은 삐걱임이 겹치고, 그 뒤 같은 위치에서 말이 끊깁니다. 목소리 음색보다 그 정렬이 중요합니다.

### H_D06_2

**P00 | 나여백 [S_H_D06_0021]**

리허설 녹음은 18:10 리허설 원본입니다. 안내 음성 비교는 그 원본과 여백의 실제 20:30 현장 출력을 비교합니다. 음향 진행표는 작업 순서를 보여 주는 예정표입니다. 안내 음성 비교의 공개 기록은 `그때 출력이 있었다`는 별도 관찰이지만, 동일 음성 내용 자체를 두 번째 독립 발화로 세면 안 됩니다.

**If source missing**

**P00 | 나여백 [S_H_D06_0022]**

빠진 자료를 나중 장에서 찾을 필요는 없습니다. 리허설 원본은 음향 부스의 18시 10분 연습 행에서 요청할 수 있고, 공개 출력 비교는 그 원본과 여백이 이미 가진 20시 30분 현장 기록을 맞추면 됩니다.

### H_D06_3

**If recent error = voice_similarity_only**

**P00 | 나여백 [S_H_D06_0031]**

방금은 `같은 사람 목소리`를 `같은 녹음`으로 바꿨습니다. 같은 화자가 두 번 직접 말하는 경우에도 음색은 비슷합니다. 우연히 같은 위치에 반복되기 어려운 삐걱임과 끊김을 쓰세요.

**If recent error = schedule_only**

**P00 | 나여백 [S_H_D06_0032]**

방금은 음향 진행표를 실행 로그로 취급했습니다. 일정표는 예정이고, 동일 녹음 판정은 리허설 녹음/안내 음성 비교의 실제 음향 특징에서 나와야 합니다.

**If recent error = same_origin_as_independent**

**P00 | 나여백 [S_H_D06_0033]**

방금은 같은 발화 기원을 두 증언으로 셌습니다. 공개 현장 기록은 `출력 발생`에는 독립적이지만, 그 안의 음성이 리허설 녹음 재사용이면 `20:30에 표문식이 새로 말했다`는 두 번째 근거가 아닙니다.

### H_D06_4

**If a required source is missing**

**P00 | 나여백 [S_H_D06_0043]**

필수 자료가 비어 있으면 결론을 미리 만들지 마세요. 작업표의 연습 행, 실제 리허설 원본, 여백의 20시 30분 현장 출력 비교를 현재 부스에서 채운 뒤 같은 음절의 삐걱임과 같은 끊김 위치를 근거로 쓰면 됩니다.

**If all held**

**P00 | 나여백 [S_H_D06_0041]**

이 정도로 정리하면 됩니다. `20시 30분 공개 음성은 문장만 같은 것이 아니라 마지막 음절에 겹치는 삐걱임과 끊기는 위치까지 18시 10분 리허설 녹음과 일치한다. 그래서 같은 녹음 구간을 다시 썼다고 볼 수 있다. 진행표는 두 작업의 순서를 보조할 뿐, 재생 사실 자체의 근거는 아니다.`

**If K06 already acquired**

**P00 | 나여백 [S_H_D06_0042]**

두 출력이 같은 녹음 구간이라는 판단은 끝났습니다. 같은 비교를 반복하지 말고, 이제 그 근거를 들고 해금 씨의 `20시 30분 직접 마이크 발화` 설명이 맞는지 물으세요.

---

## C_Q02 — 직접 말한 안내였다는 설명과 맞을까?

### Context
- Place: L07 sound booth; P01 remains in L02 with P02 until the correction is complete.
- Cast: P00, P05.
- Entry: K06 + current S_Q02_v1 + E12 + E14. E15 does not exist and the operator/permission correction is unknown before success.
- Exit: success creates the sole S_Q02_v2, E15 and KQ02. P00 then returns to L02 before C_CH02_04.
- E/S/K/B: targets current S_Q02_v1; branches incomplete, both named errors, success, retry, current revisit.
- Effects: establishes P05's audio operator action and permission overreach only; no fall actor/death-time conclusion.
- Repeat/resume: a failed draft stays; after success the v1 is historical and never becomes current again.

### Task setup

*해금은 콘솔 앞에 서 있고, 음향 진행표와 안내 음성 비교는 같은 책상 위에 놓여 있다. 여백은 원진술을 그대로 읽어 준다.*

**P00 | 나여백 [S_Q02_0001]**

소해금 씨의 현재 설명은 `20시 30분에 표문식 씨가 마이크로 직접 말했다`입니다. 그런데 두 음향이 같은 녹음 원본이라는 결론에서는 공개 출력이 18시 10분 리허설 구간을 재사용했다고 확인했습니다. 둘이 함께 성립하는지 따져 보겠습니다.

- Author state: **Q02:** `마이크로 직접 말한 안내였다는 설명과 맞을까?`

### Free clarification

**P05 | 소해금 [S_Q02_0002]**

제가 콘솔 앞에 있었다는 것만으로 누가 현장에서 무슨 일을 했는지까지 정하시면 안 됩니다.

**P00 | 나여백 [S_Q02_0003]**

동의합니다. 사람을 새로 지목하는 문제가 아니라, `직접 마이크 발화`라는 설명이 동일 녹음 재사용과 양립하는지만 먼저 보겠습니다.

### B_Q02_incomplete

**P00 | 나여백 [S_Q02_0011]**

아직 직접 발화 주장을 뒤집을 비교가 완성되지 않았습니다. 두 음향이 같은 녹음 원본이라는 결론이 없으면 먼저 동일 녹음 구간을 입증하고, 음향 진행표/안내 음성 비교와 원진술을 다시 놓겠습니다.

> 여유 변화 없음. Q02 초안은 유지된다.

### B_Q02_err_console_proves_murder

**P00 | 나여백 [S_Q02_0021]**

20시 30분에 소해금 씨가 콘솔을 조작했고 표문식 씨 목소리가 재생됐으니, 소해금 씨가 표문식 씨를 해친 사람이라고 보겠습니다.

**P00 | 나여백 [S_Q02_0022]**

그 결론은 이 자료가 말하지 않습니다. 콘솔 조작 여부는 음향 책임을 설명할 수 있지만, 추락 현장의 행동이나 신원을 증명하지 않습니다.

**P05 | 소해금 [S_Q02_0023]**

제가 잘못한 음향 일이 있다고 해서 보지 못한 장소의 일을 제 행동으로 채우지는 마세요.

> 여유 `-2`. 음향 책임과 범행 책임을 분리한다.

### B_Q02_err_technician_mimicked_voice

**P00 | 나여백 [S_Q02_0031]**

표문식 씨가 없었다면 소해금 씨가 비슷하게 흉내 내 마이크로 말했을 가능성이 큽니다.

**P00 | 나여백 [S_Q02_0032]**

두 음향이 같은 녹음 원본이라는 결론은 이미 `같은 녹음 구간`을 확인했습니다. 누군가 목소리를 흉내 냈다는 새 능력을 만들 필요가 없습니다. 기존 파일과 실제 출력 경로를 설명하면 됩니다.

**P05 | 소해금 [S_Q02_0033]**

저 성대모사 못 합니다. 그리고 못 한다는 제 말보다, 이미 같은 파일 구간이라는 비교가 더 좋은 근거예요.

> 여유 `-2`. 초안은 유지된다.

### B_Q02_success

**P00 | 나여백 [S_Q02_0041]**

직접 마이크 발화였다는 설명은 맞지 않습니다. 안내 음성 비교의 20시 30분 출력은 리허설 녹음과 같은 녹음 구간이고, 음향 진행표의 `20:30 마이크 안내`는 예정표일 뿐 실제 실행을 증명하지 않습니다. 표문식 씨가 그 시각 새로 말한 것이 아니라면, 부스에서 어떤 조작으로 그 파일이 나갔는지 정정해 주세요.

*해금은 한동안 콘솔의 재생 버튼을 보다가, 손을 책상 아래로 내린다.*

**P05 | 소해금 [S_Q02_v2]**

제가 틀었습니다. 20시 30분에 문식 선생님이 안 왔고, 저는 18시 10분 리허설 파일을 골라서 여기서 재생 버튼을 눌렀어요. 연습용으로 녹음하는 건 허락받았지만, 본인이 없는 자리에서 그 목소리를 행사 안내로 틀어도 된다는 허락은 받지 않았습니다.

**P00 | 나여백 [S_Q02_0042]**

그럼 어제 `직접 말했다`고 설명한 것도 사실과 달랐습니다.

**P05 | 소해금 [S_Q02_0043]**

네. 사람이 죽었다는 말을 들은 뒤에 제가 먼저 생각한 게, `내가 그 목소리를 틀었다고 말하면 그 시간에 살아 있었다는 말도 무너진다`는 거였어요. 그래서 직접 말했다고 했습니다.

**P00 | 나여백 [S_Q02_0044]**

그 생각이 누구의 죽음과 연결되는지는 아직 이 음향 자료로 판단하지 않습니다. 지금 기록하는 건 조작과 허락 범위입니다.

**P05 | 소해금 [S_Q02_0045]**

알겠습니다. 제가 20시 30분에 로컬 파일 재생을 눌렀고, 그 사용 허락은 없었습니다. 그 두 가지는 제 행동입니다.

#### E15 — 재생 조작 정정

> 원래 설명: `그 안내는 문식 씨가 그때 마이크로 직접 말한 거예요.`  
> 정정: 소해금은 20시 30분 음향 부스에서 18시 10분 리허설 녹음을 직접 골라 재생했다고 인정했다.  
> 표문식이 허락한 것은 리허설을 위해 녹음하는 범위였고, 본인이 없는 자리에서 그 목소리를 공개 안내로 재생하는 허락은 받지 않았다고 정정했다.  
> **제한:** 음향 조작자와 허락 범위를 바로잡는 기록이다. 추락 행위자나 표문식의 정확한 사망 시각을 증명하지 않는다.

- Author state: acquire E15 and KQ02; the 20:30 announcement was P05 manually replaying the E11 rehearsal file beyond the granted permission scope.

### B_Q02_retry

**P00 | 나여백 [S_Q02_0051]**

방금은 음향 조작에서 곧바로 범인을 고르거나 필요 없는 성대모사 가정을 붙였습니다. 두 출력이 같은 녹음 구간이라는 근거와 `그때 직접 마이크로 말했다`는 현재 설명의 모순만 다시 제시하겠습니다.

**P00 | 나여백 [S_Q02_0052]**

`같은 녹음 구간이 재사용됐는데 직접 마이크 발화라는 설명이 어떻게 가능한가`라고 물으면 충분합니다.

### Current revisit

**P00 | 나여백 [S_Q02_0091]**

초기 설명과 정정된 설명을 둘 다 보존합니다. 정정 내용은 `소해금이 허락 없이 리허설 파일을 재생했다`는 사실이지, `소해금이 추락을 일으켰다`는 증거가 아닙니다.

**P05 | 소해금 [S_Q02_0092]**

다시 물으셔도 조작 사실은 같습니다. 20시 30분에는 제가 리허설 파일을 선택해 재생했습니다.

---

## C_H_Q02 — Q02 힌트

### Context
- Place/cast: P00's notebook while P05 is physically present in L07 for Q02.
- Entry: Q02 unresolved/revisited. Selector checks K06/E12/E14, current-vs-historical S_Q02_v1, recent named error and post-success E15/KQ02.
- Exit/effects: hints cannot create S_Q02_v2/E15/KQ02, press playback or alter consent; no 여유 change.
- E/S/K/B: pre-success hints may teach the contradiction but never quote or name the unseen operator/permission confession. Post-success hints may use E15.
- Repeat/resume: a saved challenge retains its draft/recent error; after success hints point forward rather than re-extracting the confession.

#### Deterministic selector (normative)
- Return exactly one Korean S line. Priority: `Q02 complete` → `missing prerequisite` → eligible recent named error at H3/H4 → requested pre-success level. Missing evidence outranks a recent error.
- E15/KQ02 complete, any H0–H4 → `S_H_Q02_0042`.
- Before success: if E12 or E14 is missing → `S_H_Q02_0002`; else if K06 is missing → `S_H_Q02_0001`, regardless of requested H level.
- All pre-success prerequisites held: H0 `S_H_Q02_0003`, H1 `S_H_Q02_0011`, H2 `S_H_Q02_0021`, H3 `S_H_Q02_0003`, H4 `S_H_Q02_0041`.
- With all prerequisites held, recent `console_proves_murder` at H3/H4 → `S_H_Q02_0031`; recent `technician_mimicked_voice` → `S_H_Q02_0032`.
- Interrupted challenge drafting preserves the same current claim and selector state. Pre-success selection never uses `S_H_Q02_0022`, which is post-success E15 summary only.

### H_Q02_0

**If K06 missing**

**P00 | 나여백 [S_H_Q02_0001]**

먼저 리허설 원본과 20시 30분 현장 출력이 같은 녹음 구간을 공유한다는 근거를 완성하세요. 목소리 유사성만으로는 해금 씨의 `그때 직접 마이크로 말했다`는 설명을 반박할 수 없습니다.

**If E12/E14 missing**

**P00 | 나여백 [S_H_Q02_0002]**

음향 부스에서 작업 진행표와 두 출력의 비교를 채우세요. 진행표에는 `마이크 안내 예정`이 적혀 있고, 현장 기록은 20시 30분에 실제로 어떤 음성 구간이 출력됐는지 보여 줍니다.

**If all pre-success sources held**

**P00 | 나여백 [S_H_Q02_0003]**

비교 준비는 됐습니다. `같은 녹음 구간이 20:30에 나갔는데, 그때 직접 마이크로 새로 말했다는 설명과 어떻게 양립하는가`만 물으세요.

### H_Q02_1

**If K06/E12/E14 is still missing**

**P00 | 나여백 [S_H_Q02_0012]**

직접 발화 설명을 바로 압박하기 전에, 두 출력이 같은 녹음 구간이라는 근거와 20시 30분 항목이 예정표라는 점부터 확인하세요. 아직 없는 정정 내용을 대신 추측할 필요는 없습니다.

**If all pre-success prerequisites are held**

**P00 | 나여백 [S_H_Q02_0011]**

콘솔이 동작했다는 사실은 사람의 직접 발화를 뜻하지 않습니다. 이 부스는 파일 재생과 마이크 입력이 별도 경로입니다. 두 음향이 같은 녹음 원본이라는 결론은 실제 공개 음성이 리허설 구간과 같다고 이미 좁혔습니다.

### H_Q02_2

**Before success**

**P00 | 나여백 [S_H_Q02_0021]**

현재 가진 건 진행표, 두 출력의 비교, 그리고 해금 씨의 `20시 30분 직접 발화` 설명입니다. 아직 본인이 정정하지 않았으니 정답 내용을 미리 상상하지 말고, 지금 가진 모순을 제시해 답변을 받아야 합니다.

**After success / E15 held**

**P00 | 나여백 [S_H_Q02_0022]**

재생 조작 정정은 소해금이 20:30에 리허설 파일을 수동 재생했고, 리허설 녹음 허락이 당사자가 없는 자리에서의 공개 재생 허락은 아니었다고 정정한 기록입니다. 음향 진행표/안내 음성 비교와 함께 시간 순서를 정리하는 데 쓰되 추락 신원 증거로 늘리지 않습니다.

### H_Q02_3

**If a prerequisite is still missing**

**P00 | 나여백 [S_H_Q02_0033]**

근거가 아직 덜 모였다면 사람의 행동을 새로 만들지 마세요. 같은 녹음 구간이라는 판단과 현재 직접 발화 설명이 함께 놓일 때 생기는 모순까지만 준비하면 됩니다.

**If recent error = console_proves_murder**

**P00 | 나여백 [S_H_Q02_0031]**

방금은 부스 조작을 추락 범행으로 연결했습니다. 지금 질문은 `직접 마이크 발화 설명이 맞는가`뿐입니다. 추락 현장의 행위자 판단은 다른 자료가 필요합니다.

**If recent error = technician_mimicked_voice**

**P00 | 나여백 [S_H_Q02_0032]**

방금은 필요 없는 성대모사 가정을 만들었습니다. 두 출력이 같은 녹음 구간이라는 사실은 이미 입증됐으니, `누가 흉내 냈나`가 아니라 현재의 직접 마이크 설명이 그 사실과 맞는지를 물으세요.

### H_Q02_4

**If unsolved but all prerequisites held**

**P00 | 나여백 [S_H_Q02_0041]**

이렇게 물을 수 있습니다. `20시 30분 현장 출력은 18시 10분 리허설 원본과 같은 삐걱임·끊김을 같은 위치에 공유해서 같은 녹음 구간으로 보입니다. 진행표의 20시 30분 마이크 표시는 예정일 뿐 실제 직접 발화를 증명하지 않습니다. 그렇다면 “그때 문식 씨가 마이크로 직접 말했다”는 현재 설명은 이 자료와 어떻게 맞습니까? 실제로 어떤 방식으로 그 음성이 나갔는지 본인이 설명해 주세요.` 답은 해금 씨가 직접 말하기 전까지 미리 적지 않습니다.

**If Q02 already solved**

**P00 | 나여백 [S_H_Q02_0042]**

해금 씨의 설명은 이미 정정됐습니다. 같은 고백을 다시 캐내지 말고 `18시 10분에 만들어진 녹음 / 20시 30분에 나온 출력 / 그 시각 표문식의 실제 위치`를 서로 다른 사실로 나누세요.

---

## C_CH02_04 — 사과는 허락증이 아니다

### Context
- Place: L02 handback/choice → L07 sound booth.
- Cast: handback P00/P01/P02; booth P00/P01/P05.
- Entry: Q02 success with E15/KQ02. P00 physically returns to L02, receives P01 back from P02, explains only the correction needed to decide whether to hear P05's apology, and P01 chooses to return to L07 with P00.
- Exit: set exactly one B_PLAYBACK_RESPONSE branch. Both preserve E15/KQ02/access and neither grants recording, reuse or publication consent.
- E/S/K/B: reads E15/KQ02 and B_PR_02 callback; sets B_PLAYBACK_RESPONSE only.
- Effects: P01 keeps ownership of her existing chair sample; apology response is not a permission token or automatic forgiveness.
- Repeat/resume: if interrupted after correction but before choice, correction persists and only the still-unset apology response resumes; a set branch is not offered twice.

### Script

*해금의 정정이 끝난 뒤 여백은 먼저 휴게실로 돌아간다. 봉만실과 모눈은 같은 탁자에서 우산 번호표와 분실물 접수표를 정리하고 있다.*

**P02 | 봉만실 [S_CH02_04_0035]**

왔어요? 모눈이는 여기 있었어요. 접수대 밖으로 나간 건 물 마시러 두 걸음 간 게 전부예요.

**P00 | 나여백 [S_CH02_04_0036]**

고맙습니다. 모눈아, 해금 씨가 어제 안내에 대해 중요한 정정을 했고, 네 녹음 허락 얘기하고도 이어지는 부분이 있어. 해금 씨가 직접 사과하고 싶다고 하는데, 들으러 갈래? 안 가도 돼.

**P01 | 나모눈 [S_CH02_04_0037]**

갈래. 사과 듣는다고 파일 주는 건 아니지?

**P00 | 나여백 [S_CH02_04_0038]**

응. 그건 완전히 별개야.

*모눈은 여백과 함께 음향 부스로 돌아간다. 봉만실은 휴게실에 남는다. 해금은 모눈의 녹음기를 보지 않고 의자를 한 걸음 뒤로 민다. 전날 모눈이 녹음한 바로 그 의자다. 모눈이 의자를 잠깐 보다가 해금을 본다.*

**P05 | 소해금 [S_CH02_04_0006]**

모눈아. 내가 어제 너한테 `허락한 소리만 쓰자`고 말해 놓고, 정작 문식 선생님 연습 녹음은 그 범위를 넘겨 썼어. 그건 미안해.

### Conditional callback — prior B_PR_02

#### If B_PR_02 = environment_first

**P01 | 나모눈 [S_CH02_04_0007]**

나는 사람 목소리 안 넣으려고 장소 소리부터 했는데. 선생님이 그 규칙 잘 안 지킨 거네.

**P05 | 소해금 [S_CH02_04_0008]**

맞아. 네가 더 조심했고, 내가 덜 조심했어.

#### If B_PR_02 = ask_voice_later

**P01 | 나모눈 [S_CH02_04_0009]**

나는 목소리는 나중에 다시 물어보려고 했는데. 연습할 때 한 번 물어본 걸 나중 허락까지로 쓰면 안 되는 거였네.

**P05 | 소해금 [S_CH02_04_0010]**

맞아. 한 번 받은 허락을 다른 용도로 늘려 쓴 건 내 잘못이야.

### Common continuation

**P01 | 나모눈 [S_CH02_04_0001]**

내 의자 파일은 선생님이 `한 번 녹음해도 된다`고 했잖아요.

**P05 | 소해금 [S_CH02_04_0002]**

응. 그건 그대로 네 파일이야. 내가 오늘 사건 설명한다고 가져다 쓰거나, 행사 영상에 붙이거나, 다른 사람한테 넘길 권한은 없어.

**P01 | 나모눈 [S_CH02_04_0003]**

그럼 지금도 안 줄래요. 내가 과제에 쓸지 말지는 나중에 정할래.

**P05 | 소해금 [S_CH02_04_0004]**

그렇게 해. 그리고 내가 미안하다고 말했다고 네가 지금 괜찮다고 해 줄 필요도 없어.

**P00 | 나여백 [S_CH02_04_0005]**

정정한 사실은 그대로 기록하고, 사과를 지금 받아들일지는 우리가 따로 결정하면 돼.

### Choice B_PLAYBACK_RESPONSE

- Type: relationship
- Rule: Both branches retain E15/KQ02 and full investigation access. Neither grants voice/sample recording, reuse or publication consent.

#### Option `accept_apology`

- Label: `사과는 받되, 허락과는 별개라고 말한다.`

**P00 | 나여백 [S_CH02_04_0011]**

사과는 받겠습니다. 사실을 바로잡은 것도 기록하겠습니다. 하지만 그게 사용 허락을 새로 주거나, 어제 일을 없던 것으로 만드는 건 아닙니다.

**P05 | 소해금 [S_CH02_04_0012]**

네. 그 구분까지 받아들이겠습니다.

**P01 | 나모눈 [S_CH02_04_0013]**

나도 미안하다고 한 건 들었어요. 근데 내 녹음은 아직 내 거예요.

**P05 | 소해금 [S_CH02_04_0014]**

알겠어. 네가 먼저 말하기 전에는 내가 다시 묻지도 않을게.

- Author state: Set `B_PLAYBACK_RESPONSE=accept_apology`.

#### Option `need_time`

- Label: `지금은 답하지 않고 시간이 필요하다고 말한다.`

**P00 | 나여백 [S_CH02_04_0021]**

정정은 받았습니다. 사과에 대해서는 지금 답하지 않겠습니다. 사실 확인과 괜찮아지는 건 같은 속도로 진행되지 않으니까요.

**P05 | 소해금 [S_CH02_04_0022]**

네. 기다려 달라는 말도 하지 않겠습니다.

**P01 | 나모눈 [S_CH02_04_0023]**

나도 아직 모르겠어요. 내 녹음은 그냥 내가 갖고 있을래.

**P05 | 소해금 [S_CH02_04_0024]**

알겠어. 그 파일 얘기는 네가 먼저 꺼낼 때까지 하지 않을게.

- Author state: Set `B_PLAYBACK_RESPONSE=need_time`. Later text must not state that P00/P01 forgave P05 unless a later explicit scene supports it.

### Merge

*해금은 콘솔의 20:30 항목 옆에 작은 메모를 붙인다. `원진술 정정 — 재생 조작 정정 참조 / 사용 허락 별도`라고만 쓰고, 모눈의 녹음 파일 이름은 적지 않는다.*

**P00 | 나여백 [S_CH02_04_0031]**

이제 음향에서 확인해야 할 다음 문제는 시간입니다. 18시 10분에 만들어진 말이 20시 30분에 나갔다는 건 알았습니다. 그 사이 표문식 씨가 실제로 어디 있었는지는 음향만으로 채우지 않겠습니다.

**P05 | 소해금 [S_CH02_04_0032]**

그건 저도 동의합니다. 제가 파일을 틀었다는 사실이 그 사람 위치까지 알려 주진 않아요.

**P01 | 나모눈 [S_CH02_04_0033]**

목소리 시간하고 사람 시간 따로.

**P00 | 나여백 [S_CH02_04_0034]**

응. 다음 기록은 그 셋을 분리해서 쓰자.

### Interrupted branch / resume

*해금 씨의 20시 30분 안내 진술이 정정된 뒤 선택 전에 장면이 중단되면 재생 조작 정정/20시 30분 무단 재생 정정 결론은 이미 유지된다. 재방문 시 소해금이 사실을 다시 고백하게 하지 않고, 아직 정하지 않은 사과 응답 선택 대화만 이어 간다.*

**P05 | 소해금 [S_CH02_04_0081]**

정정한 내용은 그대로입니다. 아까 사과에 답을 요구하지 않겠다고 했죠. 아직 답을 안 정했다면 그 부분만 이어가면 됩니다.

### Current revisit — accept_apology

**P00 | 나여백 [S_CH02_04_0091]**

사과를 받은 것과 사용 허락은 별개입니다. 모눈의 파일은 여전히 모눈이 정합니다.

### Current revisit — need_time

**P00 | 나여백 [S_CH02_04_0092]**

정정은 받아 두었고, 사과에 대한 답은 아직 보류한 상태입니다. 우리가 답하지 않은 일을 나중에 화해한 것으로 말하지 않겠습니다.

---

## C_D07 — 녹음한 때·틀어 둔 때·사람이 있던 때를 나누자

### Context
- Place: L07 after C_CH02_04 while P00/P01/P05 are together.
- Cast: P00, P01, P05.
- Entry: E11 + E12 + E15/KQ02; Q02 is already corrected.
- Exit: success → K07 and motivates a request to P07 for independent contact/time records.
- E/S/K/B: uses E11/E12/E15; branches incomplete, `file_time_is_death_time`, success, retry.
- Effects: separates recording creation from later playback; does not establish death time or P08's 20:30 location.
- Repeat/resume: the three-column draft survives interruption/wrong answer; revisit after K07 does not restage Q02.

### Task setup

**P00 | 나여백 [S_D07_0001]**

같은 음성이 두 시각에 등장했으니, 파일의 시간과 사람의 시간을 섞지 않겠습니다. `녹음이 만들어진 때`, `그 녹음을 틀어 둔 때`, `표문식 씨가 실제로 확인된 때`를 따로 놓죠.

> **D07:** `녹음한 때·틀어 둔 때·사람이 있던 때를 나누자.`

### Free clarification

**P01 | 나모눈 [S_D07_0002]**

18시 10분 파일이면 그 사람이 18시 10분에는 거기 있었던 거야?

**P00 | 나여백 [S_D07_0003]**

리허설 녹음이 실제 리허설 원본이고 그 자리에서 녹음된 건 맞아. 하지만 그 파일이 20시 30분에 재생됐다고 해서 그 사람도 20시 30분에 같은 곳에 있었다고 따라오는 건 아니야.

### B_D07_incomplete

**P00 | 나여백 [S_D07_0011]**

아직 `만든 때`와 `나중에 튼 때`를 실제 자료로 나누기 어렵습니다. 리허설 원본의 시각, 현장 작업표, 해금 씨의 정정 내용을 먼저 놓겠습니다.

> 여유 변화 없음. 초안 유지.

### Valid chronology construction

**P00 | 나여백 [S_D07_0021]**

첫째, 리허설 녹음은 18시 10분 리허설에서 만들어진 녹음입니다. 둘째, 재생 조작 정정에 따라 소해금은 20시 30분에 그 파일을 수동 재생했습니다. 셋째, 그 재생은 20시 30분에 `표문식 씨가 마이크 앞에 있었다`는 정보를 담지 않습니다.

**P00 | 나여백 [S_D07_0022]**

음향 진행표의 시각은 작업 순서를 보조하지만 예정표 자체가 사람 위치를 증명하지 않습니다. 여기서는 정확한 초 단위가 아니라 `연습 때 생성 → 나중 공개 재생`이라는 분리를 남기겠습니다.

### B_D07_err_file_time_is_death_time

**P00 | 나여백 [S_D07_0031]**

리허설 파일이 18시 10분에 만들어졌고 같은 파일이 나중에 재생됐으니, 표문식 씨의 사망 시각도 그 두 시각 사이였다고 확정하겠습니다.

**P00 | 나여백 [S_D07_0032]**

파일은 그 사람이 그때 말한 기록일 뿐, 그 뒤 언제 죽었는지 기록하지 않습니다. 20시 30분 재생은 오히려 그 시각의 생존 확인이 아니라는 것만 말합니다. 사망 시각 범위를 여기서 새로 만들 수는 없습니다.

**P05 | 소해금 [S_D07_0033]**

제 파일 시간으로 사람의 죽은 시간을 정하지 마세요. 제가 가진 건 소리 작업 시간입니다.

> 여유 `-2`. 사망 시각 주장은 삭제하고 자료는 유지한다.

### B_D07_success

**P00 | 나여백 [S_D07_0041]**

정리하겠습니다. 18시 10분은 리허설 녹음이 만들어진 리허설 시각이고, 20시 30분은 재생 조작 정정에서 소해금이 그 파일을 공개 출력한 시각입니다. 두 시각 사이와 20시 30분 당시 표문식 씨의 실제 위치는 이 음향 기록만으로 확인되지 않습니다.

**P00 | 나여백 [S_D07_0042]**

그러므로 늦게 들린 목소리는 늦은 대면 증거가 아닙니다. 다음에는 음향이 아니라, 표문식 씨를 실제로 직접 만난 기록을 찾아야 합니다.

**P05 | 소해금 [S_D07_0043]**

네. 제가 늦은 목소리를 만들어 놓고 그걸 늦은 사람처럼 설명했던 겁니다. 그 부분은 분리해서 보세요.

- Author state: **K07 획득:** E11은 18:10 earlier speech recording; E15는 20:30 later playback. 20:30 audio does not prove P08 live presence or location. No death-time bound is created here.
- Author state: **Next access:** P07에게 서로 독립된 시계·대면 기록을 요청할 수 있다. C_CH02_05의 V22 request가 의미를 갖는다.

### B_D07_retry

**P00 | 나여백 [S_D07_0051]**

방금은 파일 시각을 사람의 생애 시각으로 늘렸습니다. 지금 가진 세 자료는 그대로 두고 `만든 때 / 나중에 튼 때 / 그때 사람 위치는 모름` 세 칸으로 다시 배열하겠습니다.

### Current revisit

**P00 | 나여백 [S_D07_0091]**

18시 10분의 녹음과 20시 30분의 출력은 분리됐지만, 아직 `마지막 생존 대면`도 `사망 시각`도 아닙니다. 이제 사람을 실제로 만난 기록을 따로 요청해야 합니다.

---

## C_H_D07 — D07 힌트

### Context
- Place/cast: P00's notebook with P01/P05 present in L07; no future chronology witness is summoned.
- Entry: D07 unresolved/revisited. Selector checks E11/E12/E15, recent `file_time_is_death_time`, and K07-complete state.
- Exit/effects: hint only; no K07, no new contact record/death bound, no 여유 change.
- E/S/K/B: pre-success wording may use E15 because Q02 is already solved; it must not disclose later E13/E16/E17 contents.
- Repeat/resume: three-column draft/recent error survives interruption.

#### Deterministic selector (normative)
- Return exactly one Korean S line. Priority: `K07 complete` → `missing prerequisite` → recent named error at H3/H4 → requested all-held level.
- K07 complete, any H0–H4 → `S_H_D07_0042`.
- E11 missing → `S_H_D07_0001`; else E15 missing/Q02 unresolved → `S_H_D07_0002`; else E12 missing → `S_H_D07_0003`, regardless of requested level.
- All held: H0 `S_H_D07_0004`, H1 `S_H_D07_0011`, H2 `S_H_D07_0021`, H3 `S_H_D07_0032`, H4 `S_H_D07_0041`.
- With all prerequisites held, recent `file_time_is_death_time` at H3/H4 → `S_H_D07_0031`.
- Interrupted three-column drafting resumes from the same held-source state and does not add an extra line.

### H_D07_0

**If E11 missing**

**P00 | 나여백 [S_H_D07_0001]**

음향 부스에서 18시 10분 리허설 원본을 먼저 확인하세요. 만들어진 시각을 확인하지 못했다면 `언제 녹음했는가` 칸을 채울 수 없습니다.

**If E15 missing / Q02 unsolved**

**P00 | 나여백 [S_H_D07_0002]**

해금 씨가 아직 `20시 30분에 직접 마이크로 말했다`고 주장하고 있다면 그 설명부터 자료와 대조하세요. 실제 출력 방식은 본인이 정정하기 전까지 추측으로 미리 적지 않습니다.

**If E12 missing**

**P00 | 나여백 [S_H_D07_0003]**

소해금 씨의 작업 진행표를 확인해 연습과 공개 안내가 서로 다른 작업 시점이었다는 맥락을 확보하세요. 일정표만으로 사망 시각은 만들지 않습니다.

**If all held**

**P00 | 나여백 [S_H_D07_0004]**

자료는 충분합니다. `18:10 파일 생성`, `20:30 소해금 수동 재생`, `20:30 표문식 위치는 음향으로 미확정` 세 칸을 분리하세요.

### H_D07_1

**If E11/E12/E15 is missing**

**P00 | 나여백 [S_H_D07_0012]**

세 칸 가운데 하나가 비었다면 먼저 그 자료를 현재 음향 부스에서 확인하세요. 아직 정정되지 않은 출력 방식이나 아직 요청하지 않은 사람의 대면 시각을 대신 상상하지 않습니다.

**If all required sources are held**

**P00 | 나여백 [S_H_D07_0011]**

같은 녹음은 시간이 지나도 같은 목소리를 냅니다. 파일이 20시 30분에 들렸다는 건 파일이 그때 재생됐다는 뜻이지, 녹음 속 사람이 그때 다시 말하고 있었다는 뜻이 아닙니다.

### H_D07_2

**P00 | 나여백 [S_H_D07_0021]**

리허설 원본은 18시 10분에 만들어진 앞선 발화 녹음입니다. 해금 씨의 정정은 20시 30분에 그 파일을 다시 출력한 조작을 설명하고, 작업 진행표는 두 항목의 순서를 보여 줍니다. 이 셋 어디에도 `표문식이 20시 30분 어디에 있었다`는 직접 관찰은 없습니다.

### H_D07_3

**If recent error = file_time_is_death_time**

**P00 | 나여백 [S_H_D07_0031]**

방금은 파일이 만들어진 때와 사람이 죽은 때를 연결했습니다. 녹음 파일에는 그 뒤 사람의 상태가 기록되지 않습니다. 여기서는 사망 시각 범위를 만들지 말고, 20시 30분 목소리가 실시간 발화 증거가 아니라는 점까지만 확인하세요.

**If all held**

**P00 | 나여백 [S_H_D07_0032]**

`18:10에는 실제 리허설 발화가 녹음됨`과 `20:30에는 그 과거 발화가 재생됨`을 먼저 쓰고, 세 번째 문장에 `따라서 20:30 사람 위치는 미확정`을 붙이면 됩니다.

### H_D07_4

**If a required source is missing**

**P00 | 나여백 [S_H_D07_0043]**

리허설 원본, 작업 진행표, 해금 씨의 정정 가운데 빠진 것을 먼저 확인하세요. 셋이 갖춰지면 `18시 10분에 만들어진 녹음 / 20시 30분에 나온 출력 / 그 시각 사람 위치는 음향으로 모름`만 정리하면 됩니다.

**If all held**

**P00 | 나여백 [S_H_D07_0041]**

이렇게 정리하면 됩니다. `18시 10분에 만들어진 리허설 녹음이 20시 30분에 다시 출력됐고, 진행표는 그 작업 순서를 보조할 뿐 사람의 위치를 증명하지 않는다. 따라서 20시 30분 목소리만으로 표문식 씨가 그 자리에 있었다고 볼 수 없고, 마지막 대면과 그 뒤 시간은 별도 기록으로 확인해야 한다.`

**If K07 already acquired**

**P00 | 나여백 [S_H_D07_0042]**

녹음과 나중 출력의 시각은 이미 분리했습니다. 이제 진새벽에게 서로 독립된 시계 기록과 실제 대면 기록을 요청하세요. 지금 단계에서 정확한 사망 분을 만들 필요는 없습니다.

---


---

## C_CH02_05 — 종이 시각과 직접 만난 시각

### Context
- Place: L02 handoff → L01 investigation table.
- Cast: P00, P07, P09 in L01; P03 briefly appears only for the same-place P01 supervision handoff in L02.
- Entry: K07. P00 and P01 return together from L07. Before P00 leaves for L01, P03 receives P01 in L02 and remains there. P00 then asks for independent direct-contact/time/power records.
- Exit: E13, E16, E17 are acquired in an acknowledgement queue. D08 becomes immediately eligible. D09 becomes eligible after C_CH02_06 reindexes E18; either D08 or D09 may ultimately be solved first.
- E/S/K/B: creates E13/E16/E17 only; no death-minute K and no change to B_PLAYBACK_RESPONSE.
- Effects: V22 completes after all three source families are acknowledged. P01 supervision remains with P03 until C_CH02_07 handback.
- Repeat/resume: already-read envelopes stay checked; revisit resumes from the first unread source rather than replaying all three.

### Script

*음향 부스에서 나온 여백과 모눈은 먼저 휴게실로 돌아온다. 접수 서류를 들고 들어온 차무록이 빈 의자를 당겨 모눈 맞은편에 앉는다.*

**P00 | 나여백 [S_CH02_05_0012]**

무록 씨, 현관 기록을 확인하고 올 동안 모눈이와 여기 있어 주실 수 있을까요?

**P03 | 차무록 [S_CH02_05_0013]**

네. 접수표 정리도 여기서 할게요. 돌아오시면 제가 직접 넘기겠습니다.

**P01 | 나모눈 [S_CH02_05_0014]**

나는 아까 얘기한 파일 이름 다시 적고 있을게. 다녀와.

*여백은 두 사람이 같은 테이블에 앉은 것을 확인하고 혼자 현관 조사 탁자로 간다. 진새벽이 새 카드 세 장을 나란히 놓아 둔다. 첫 카드에는 `사람`, 둘째에는 `시계`, 셋째에는 `전원`이라고 적혀 있다. 목백로는 모래시계를 뒤집어 놓고는, 모래가 떨어지기 전에 자기 영수증부터 찾는다.*

**P07 | 진새벽 [S_CH02_05_0001]**

요청하신 건 세 종류입니다. 마지막으로 직접 만난 기록, 서로 다른 시계가 얼마나 어긋나는지 본 기록, 전원이 실제로 끊겼다가 돌아온 기록. 서로 같은 출처처럼 취급하지 마세요.

**P00 | 나여백 [S_CH02_05_0002]**

네. 음향 진행표의 예정 시각을 이 기록들 위에 덮어쓰지 않겠습니다.

**P09 | 목백로 [S_CH02_05_0003]**

그리고 제가 적힌 종이를 봤다는 거하고, 그 시각을 제 눈으로 시계에서 봤다는 것도 달라요. 그 말부터 해 두겠습니다.

*새벽이 첫 봉투를 연다.*

#### E16 — 마지막 대면 인계표

> `표문식 → 배한술 / 원본 목록 1장 / 20:10–20:12 사이 직접 수령`  
> 표문식의 서명과 배한술의 당시 수령 표시가 함께 있다.  
> 배한술은 그 시각 표문식에게서 문서를 직접 받았다고 확인했다. 이 기록은 그 뒤의 위치나 사망 시각을 증명하지 않는다.

**P07 | 진새벽 [S_CH02_05_0004]**

배한술 씨에게도 직접 확인했습니다. 서류를 받은 건 맞고, 그때 표문식 씨와 대면했습니다. 이건 `대면이 있었다`는 기록입니다.

**P00 | 나여백 [S_CH02_05_0005]**

20시 10분에서 12분 사이. 18시 10분 리허설보다는 늦고, 20시 30분 재생보다는 이릅니다. 여기까지 적겠습니다.

*둘째 봉투에는 세 시계 화면 사진과 비교 메모가 있다.*

#### E13 — 시계 대조 기록

> `현관 통화 화면·주방 인계 시계·음향 시계 대조: 차이 1분 이내. 시각을 초 단위로 단정하지 말 것.`  
> 진새벽이 10월 22일 다시 대조한 기록과, 목백로가 보관한 10월 21일 사전 점검 카드가 함께 있다.

**P09 | 목백로 [S_CH02_05_0006]**

어제 행사 전에도 셋이 크게 어긋나진 않는 건 봤습니다. 그렇다고 제가 초까지 맞았다고 보증하는 건 아닙니다.

**P00 | 나여백 [S_CH02_05_0007]**

한 분 단위 기록끼리 순서를 비교할 수는 있지만, 경계에서는 1분 오차를 남긴다. 알겠습니다.

*셋째는 장비 제어기의 짧은 출력지다.*

#### E17 — 전원 복귀 기록

> `20:19 부하 차단 / 20:20 복귀`  
> 여백·봉만실이 들은 복귀 확인과 연결되는 장비 기록이다.

**P07 | 진새벽 [S_CH02_05_0008]**

이건 원인을 말해 주지 않습니다. 장비가 차단과 복귀를 기록했을 뿐입니다.

**P00 | 나여백 [S_CH02_05_0009]**

정전이 무슨 행동을 일으켰다고도, 그때 누가 어디 있었다고도 자동으로 쓰지 않겠습니다.

**P09 | 목백로 [S_CH02_05_0010]**

그렇게 하나씩 떼어 보셔야 해요. 기록은 같이 놓는다고 한 기록이 되진 않습니다.

### Player order

*이 시점부터 마지막 직접 대면 추론과 공개 신호 순서 추론은 어느 쪽부터 먼저 열어도 된다. 한 작업의 성공은 다른 작업의 답을 자동으로 채우지 않는다.*

**P07 | 진새벽 [S_CH02_05_0011]**

마지막으로 직접 만난 기록부터 정리하셔도 됩니다. 아니면 공개 자리에서 신호와 정전, 안내가 어떤 순서로 이어졌는지 먼저 확인하셔도 되고요. 두 쪽이 다 정리되면 그 사이에 남는 시간을 같이 보죠.

### Interrupted acquisition / resume

**P07 | 진새벽 [S_CH02_05_0081]**

아까 읽은 봉투는 다시 처음부터 펼치지 않겠습니다. 아직 안 본 것이 있으면 그 봉투부터 이어서 보죠.

### Current revisit

**P00 | 나여백 [S_CH02_05_0091]**

마지막 대면 인계표는 직접 대면, 시계 대조 기록은 시계 오차 한계, 전원 복귀 기록은 전원 사건입니다. 셋을 서로의 증인으로 바꾸지 않고 씁니다.

---

## C_D08 — 마지막으로 직접 확인된 대면은 무엇일까?

### Context
- Place: L01 investigation table.
- Cast: P00, P07, P09. P01 remains supervised by P03 in L02 while this challenge is active.
- Entry: E16 + E13 + K07 are required for a scored submission; if E16/E13 is missing, the same draft opens as free-incomplete. D08 may be attempted before or after C_CH02_06/D09.
- Exit: success creates K08 only. It does not establish continued kitchen stay, death time, culprit, or any K09 effect.
- E/S/K/B: reads E16/E13/K07; branches incomplete, two named errors, success, retry, current revisit.
- Repeat/resume: failed or suspended drafts reopen at the same selected premise and evidence; no new evidence is auto-added.

### Entry states
- Required: E16 + E13 + K07.
- If E16 or E13 is missing, submission is free-incomplete.
- The task does not establish a death time.

### Setup

**P00 | 나여백 [S_D08_0001]**

20시 30분 목소리는 과거 녹음이었습니다. 그러면 지금 가진 자료 중, 표문식 씨를 살아 있는 상태로 **직접** 확인한 가장 늦은 대면은 무엇인지 고르겠습니다.

> **D08:** `마지막으로 직접 확인된 대면은 무엇일까?`

### B_D08_incomplete

**P00 | 나여백 [S_D08_0011]**

아직 마지막 대면 인계표와 시계 대조 기록을 함께 보지 못했습니다. 예정표나 녹음 시각으로 빈칸을 대신하지 않고 자료를 먼저 확인하겠습니다.

> 여유 변화 없음. 초안 유지.

### B_D08_success

**P00 | 나여백 [S_D08_0021]**

마지막 대면 인계표에서 표문식 씨는 20시 10분부터 12분 사이 배한술 씨에게 원본 목록을 직접 건넸습니다. 시계 대조 기록을 적용하면 초 단위까지 좁히지 않고 그 범위 그대로 쓰는 게 맞습니다.

**P00 | 나여백 [S_D08_0022]**

이 대면은 18시 10분 리허설보다 늦고, 20시 30분 재생보다 이릅니다. 다만 `20시 12분 이후에도 주방에 있었다`거나 `20시 12분에 곧바로 사망했다`는 뜻은 아닙니다.

**P07 | 진새벽 [S_D08_0023]**

좋습니다. 마지막 직접 확인과 그 뒤의 미확인 시간을 분리해 적겠습니다.

- Author state: **K08 획득.**

### B_D08_err_receipt_proves_continued_kitchen_stay

**P00 | 나여백 [S_D08_0031]**

인계표가 주방 쪽에서 작성됐으니, 표문식 씨는 그 뒤에도 계속 그곳에 있었다고 보겠습니다.

**P07 | 진새벽 [S_D08_0032]**

영수증은 인계가 있었던 순간을 붙잡습니다. 사람이 그 뒤 떠나지 않았다는 연속 관찰 기록은 아닙니다. `대면 이후 계속 체류` 부분을 지우세요.

> 여유 `-2`. 자료와 나머지 초안 유지.

### B_D08_err_receipt_is_death_time

**P00 | 나여백 [S_D08_0041]**

가장 늦은 직접 대면이 20시 10분에서 12분이니, 사망도 그 시각으로 정하겠습니다.

**P09 | 목백로 [S_D08_0042]**

받은 시각이 끝난 시각은 아니잖아요. 그 뒤 일이 종이에 안 적혔다고 바로 끝난 게 아닙니다.

**P07 | 진새벽 [S_D08_0043]**

대면의 끝과 생명의 끝을 같은 칸으로 두지 마세요.

> 여유 `-2`. 초안 유지.

### B_D08_retry

**P00 | 나여백 [S_D08_0081]**

방금은 `직접 확인된 순간`보다 넓게 말했습니다. 마지막 대면 인계표가 실제로 말하는 한 순간만 남기고 다시 정리하겠습니다.

### Current revisit

**P00 | 나여백 [S_D08_0091]**

마지막 직접 대면 시각 결론은 `20:10–20:12 직접 대면`입니다. 그 뒤의 위치나 사망 시각은 아직 열린 채입니다.

---

## C_H_D08 — D08 힌트

### Context
- Place/cast: P00's active D08 notebook at L01; P07/P09 remain available only for already-heard source clarification, not new evidence. P01 supervision stays with P03 in L02.
- Entry: D08 unresolved, interrupted, recently failed, or completed/revisited. Selector checks E16/E13/K07, recent named error, and K08-complete state.
- Exit/effects: hint only; no E/K/B/여유 change and no death-time claim.
- Repeat/resume: the most specific current state wins: missing source → held comparison → recent error/interruption → completed revisit.

#### Deterministic selector (normative)
- Return exactly one Korean S line. Priority: `K08 complete` → `missing prerequisite` → recent named error at H3/H4 → interruption at H3/H4 → requested all-held level.
- K08 complete, any H0–H4 → `S_H_D08_0042`.
- K07 missing → `S_H_D08_0002`; else E16 missing → `S_H_D08_0001`; else E13 missing → `S_H_D08_0012`, regardless of requested level.
- All held: H0 `S_H_D08_0013`, H1 `S_H_D08_0011`, H2 `S_H_D08_0021`, H3 `S_H_D08_0011`, H4 `S_H_D08_0041`.
- With all prerequisites held, recent `receipt_proves_continued_kitchen_stay` at H3/H4 → `S_H_D08_0031`; recent `receipt_is_death_time` → `S_H_D08_0032`; interrupted draft at H3/H4 → `S_H_D08_0033`.

### H_D08_0
**If K07 missing**

**P00 | 나여백 [S_H_D08_0002]**

20시 30분 목소리가 사람의 실시간 위치를 증명하지 않는다는 정리부터 끝내세요. 마지막 대면 시각은 그 뒤에 사람 기록과 시계 대조 기록으로 따로 좁혀야 합니다.

**If E16 missing**

**P00 | 나여백 [S_H_D08_0001]**

지금은 `마지막으로 직접 만난 기록` 자체가 없습니다. 진새벽 경위가 따로 둔 사람 기록 봉투부터 확인해야 합니다.

**If E16 held but E13 missing**

**P00 | 나여백 [S_H_D08_0012]**

직접 수령 기록은 있지만 시계들이 어느 정도 맞았는지 확인하지 않았습니다. 현관·주방·음향 시계를 대조한 기록까지 본 뒤 범위를 적겠습니다.

**If E16+E13 held**

**P00 | 나여백 [S_H_D08_0013]**

필요한 두 자료는 있습니다. 이제 `직접 만난 가장 늦은 순간`만 찾고, 그 뒤의 체류나 사망 시각은 덧붙이지 않으면 됩니다.

### H_D08_1
**P00 | 나여백 [S_H_D08_0011]**

핵심은 서명이 아니라 `직접 수령 표시와 실제 수령자 확인`입니다. 음성 파일은 뒤에 들렸어도 직접 대면이 아닙니다.

### H_D08_2
**P00 | 나여백 [S_H_D08_0021]**

마지막 대면 인계표는 `20:10–20:12 사이 직접 수령`, 시계 대조 기록은 `시계 차이 1분 이내, 초 단위 단정 금지`입니다. 두 자료는 마지막 직접 접촉의 범위를 안전하게 적는 데만 씁니다.

### H_D08_3
**If recent error = receipt_proves_continued_kitchen_stay**

**P00 | 나여백 [S_H_D08_0031]**

방금은 `직접 건넸다`를 `그 뒤에도 계속 주방에 있었다`로 늘렸습니다. 종이가 잡는 건 한 번의 대면이지, 그 뒤를 계속 지켜본 기록이 아닙니다.

**If recent error = receipt_is_death_time**

**P00 | 나여백 [S_H_D08_0032]**

마지막으로 살아 있는 모습을 직접 본 시각과 사망 시각은 같은 질문이 아닙니다. 인계표는 앞쪽만 답합니다.

**If returning after interruption with both records held**

**P00 | 나여백 [S_H_D08_0033]**

중간에 멈춘 곳은 `20:10–20:12 직접 대면`까지였습니다. 여기서 더 넓히지 않고 그 범위 그대로 정리하면 됩니다.

### H_D08_4
**If unresolved**

**P00 | 나여백 [S_H_D08_0041]**

이렇게 말하면 됩니다. `20시 10분에서 12분 사이, 표문식 씨가 배한술 씨에게 원본 목록을 직접 건넨 것이 지금 확인되는 가장 늦은 대면이다. 그 뒤의 위치나 사망 시각은 이 기록으로 알 수 없다.`

**If already completed / revisit**

**P00 | 나여백 [S_H_D08_0042]**

이 결론은 이미 닫혔습니다. 다시 볼 때는 `20:10–20:12 직접 대면`과 `그 뒤는 미확인` 두 줄만 유지하면 됩니다.

---

## C_CH02_06 — 다시 본 공개 순서

### Context
- Place: L03.
- Cast: P00, P02; P01 remains supervised by P03 in L02 from C_CH02_05.
- Entry: E13/E16/E17 acquired. K08 may already be held if D08 was solved first; otherwise D08 remains open. P00 leaves P01 with the already-present P03 and meets P02 at the public table.
- Exit: E18 is reindexed as the player's consolidated public-observation record. D09 becomes eligible; D08 stays independently available if unresolved.
- E/S/K/B: no new case fact beyond reindexing existing E18; K08 is not granted here.
- Effects: preserves the D08↔D09 order permutation without inventing unseen movement. P01 supervision remains in L02.
- Repeat/resume: revisit skips the re-enactment and starts from the currently unresolved D08/D09 comparison.

### Script

*여백은 휴게실에서 모눈과 차무록이 그대로 같은 테이블에 있는 것을 확인한 뒤 연회장으로 간다. 전날 숫자 카드를 놓았던 자리에 다시 앉자, 봉만실이 테이블 끝을 닦다가 `어제 여기부터 셌다`며 카드 한 장을 다른 자리에 놓는다. 여백이 즉시 자기 기록과 맞춰 원래 위치로 돌린다.*

**If K08 held**

**P00 | 나여백 [S_CH02_06_0010]**

마지막으로 직접 만난 건 20시 10분에서 12분 사이까지 정리했습니다. 이제 그 뒤 공개 자리에서 제가 실제로 본 순서를 다시 맞추겠습니다.

**If K08 not held**

**P00 | 나여백 [S_CH02_06_0011]**

마지막 대면 기록은 아직 결론을 내리지 않았습니다. 그건 그대로 열어 두고, 지금은 공개 자리에서 제가 직접 본 순서만 따로 정리하겠습니다.

**P02 | 봉만실 [S_CH02_06_0001]**

그런 것까지 자리를 기억해요?

**P00 | 나여백 [S_CH02_06_0002]**

제가 직접 본 순서를 다시 확인하는 중이라서요. 어제 본 것과 오늘 추측한 걸 섞고 싶지 않습니다.

**P02 | 봉만실 [S_CH02_06_0003]**

그럼 내가 본 것도 그렇게 잘라서 적어요. 조명 신호 전에 무록 씨가 저쪽을 지나간 건 봤지만, 나간 뒤 어디로 갔는지는 못 봤어요.

**P00 | 나여백 [S_CH02_06_0004]**

그 부분은 이미 행사 사진과 당시 관찰 한계로 남겨 뒀습니다. 오늘은 공개 테이블에서 실제로 일어난 순서만 보죠.

#### Revisit — 공개 점검 기록

- Author evidence reference: E18 was already acquired in C_PR_13; this is a read-only reindex/revisit, not a second acquisition.

> 여백이 실제로 겪은 20:15–20:22 공개 카운트.  
> 20:18 조명 확인 신호 → 주조명 중단 → 20:20 복귀 확인.  
> 낮은 안전 조명 아래 봉만실은 공개 테이블에서, 소해금은 공개 창이 보이는 부스에서 계속 관찰됐다.  
> 그 자리에서 직접 본 일과 나중에 들은 말을 분리해 적는다.

**P02 | 봉만실 [S_CH02_06_0005]**

그 뒤 20시 30분에는 안내가 들렸죠. 그런데 이제 그건 문식 씨가 그때 서서 말한 게 아니었다는 거고.

**P00 | 나여백 [S_CH02_06_0006]**

네. 그래서 공개 순서의 마지막 칸은 `20:30 녹음 재생`으로 고칠 수 있지만, 20시 20분과 30분 사이 표문식 씨의 위치를 새로 채우진 않습니다.

**P02 | 봉만실 [S_CH02_06_0007]**

내가 못 본 길을, 내가 나중에 기억해 냈다고 만들지도 말고요.

**P00 | 나여백 [S_CH02_06_0008]**

그렇게 하겠습니다.

### Current revisit

**P02 | 봉만실 [S_CH02_06_0091]**

제가 확실히 말할 수 있는 건 공개 테이블에서 본 일입니다. 무록 씨가 그 뒤 어디로 갔는지는 제 눈으로 이어서 본 게 아니에요.

---

## C_D09 — 점검 신호와 정전, 안내 방송은 어떤 순서였을까?

### Context
- Place: L01 investigation table after P00 returns from L03.
- Cast: P00, P07, P05; P09 may remain at the adjacent records seat. P01 continues under P03's same-place supervision in L02.
- Entry: C_CH02_06 has reindexed E18. E12 + E17 + E18 are required for scored submission. P07 is already at L01; P05 comes from L07 carrying the live work sheet when the comparison opens. D08 may already be complete or may remain open.
- Exit: success creates K09 only. D08 remains independently available if K08 is missing. No exact fall/death time is created.
- E/S/K/B: reads E12/E17/E18 and the already-earned Q02 correction only as context; branches incomplete, two named errors, success, retry, current revisit.
- Repeat/resume: failed/suspended ordering preserves the player's placed sequence and recent error; P05 does not repeat Q02's confession.

### Entry states
- Required: E12, E17, E18.
- Can be completed before or after D08.
- No exact fall/death time is created.

### Setup

*공개 테이블 기록을 다시 본 여백은 현관 조사 탁자로 돌아온다. 진새벽이 전원 출력지를 펼치고, 연락을 받은 소해금도 음향 진행표를 들고 부스에서 와 옆자리에 선다.*

**P00 | 나여백 [S_D09_0001]**

진행표에 적힌 예정과, 실제로 일어난 공개 사건을 나눠 놓겠습니다.

> **D09:** `점검 신호와 정전, 안내 방송은 어떤 순서였을까?`

### B_D09_incomplete

**P00 | 나여백 [S_D09_0011]**

아직 음향 진행표의 예정, 전원 복귀 기록의 실제 전원 기록, 공개 점검 기록의 직접 관찰을 함께 보지 못했습니다. 세 출처를 확인하기 전에는 순서를 정하지 않겠습니다.

> 여유 변화 없음.

### B_D09_success

**P00 | 나여백 [S_D09_0021]**

공개 점검 기록에서 20시 18분 무렵 실제 조명 확인 신호가 있었고, 전원 복귀 기록은 20시 19분 부하 차단과 20시 20분 복귀를 기록합니다. 공개 자리에서도 복귀 확인을 들었습니다.

**P00 | 나여백 [S_D09_0022]**

그 뒤 20시 30분에는 해금 씨가 인정한 대로 리허설 녹음 안내가 재생됐습니다. 음향 진행표는 예정 맥락일 뿐이고, 실제로 일어난 일은 전원 기록과 제가 현장에서 본 순서, 그리고 해금 씨의 정정으로 확인해야 합니다.

**P07 | 진새벽 [S_D09_0023]**

`신호 → 중단/복귀 → 녹음 안내`. 여기까지는 좋습니다. 그 사이 사건이 정확히 몇 분 몇 초였는지는 아직 쓰지 마세요.

- Author state: **K09 획득.**

### B_D09_err_schedule_is_performance

**P00 | 나여백 [S_D09_0031]**

음향 진행표에 20시 18분 신호, 20시 20분 복귀, 20시 30분 안내가 적혀 있으니 그대로 실제 사건 순서라고 보겠습니다.

**P05 | 소해금 [S_D09_0032]**

그 종이는 제가 하려고 적은 겁니다. 어제 20시 30분 칸처럼, 적힌 방식과 실제 방식이 다를 수 있잖아요.

**P00 | 나여백 [S_D09_0033]**

맞습니다. 예정표 단독으로 실행을 확정한 부분을 지우겠습니다.

> 여유 `-2`.

### B_D09_err_perfect_clock_claim

**P00 | 나여백 [S_D09_0041]**

세 시계가 맞았으니 20시 19분 00초에 중단됐고 20시 20분 00초에 복귀했다고 확정하겠습니다.

**P07 | 진새벽 [S_D09_0042]**

시계 대조 기록은 `1분 이내`라고 했습니다. 초 단위 정확성을 새로 만들지 마세요. 순서와 분 단위 범위만 남기면 됩니다.

> 여유 `-2`.

### B_D09_retry

**P00 | 나여백 [S_D09_0081]**

예정과 실제, 분 단위와 초 단위를 섞었습니다. 전원 복귀 기록/공개 점검 기록으로 실제 순서를 세우고 음향 진행표는 보조 맥락으로만 다시 넣겠습니다.

### Current revisit

**P00 | 나여백 [S_D09_0091]**

공개 신호·정전·재생 순서 결론은 `실제 현장 신호 → 전원 중단/복귀 → 20:30 녹음 안내 재생`입니다. 정확한 추락 시각은 아직 아닙니다.

---

## C_H_D09 — D09 힌트

### Context
- Place/cast: P00's active D09 comparison at L01; P07/P05 are present but hints cannot make them supply new facts beyond E12/E17/E18/Q02 already held. P01 remains with P03 in L02.
- Entry: D09 unresolved, interrupted, recently failed, or completed/revisited. Selector checks E12/E17/E18, named recent error, and K09 state.
- Exit/effects: hint only; no E/K/B/여유 change and no exact fall/death time.
- Repeat/resume: missing-source guidance precedes reasoning guidance; completed state gives a short limit reminder instead of re-solving.

#### Deterministic selector (normative)
- Return exactly one Korean S line. Priority: `K09 complete` → `missing prerequisite` → recent named error at H3/H4 → interruption at H3/H4 → requested all-held level.
- K09 complete, any H0–H4 → `S_H_D09_0042`.
- E12 missing → `S_H_D09_0001`; else E17 missing → `S_H_D09_0012`; else E18 missing/not yet reindexed → `S_H_D09_0013`, regardless of requested level.
- All held: H0 `S_H_D09_0014`, H1 `S_H_D09_0011`, H2 `S_H_D09_0021`, H3 `S_H_D09_0011`, H4 `S_H_D09_0041`.
- With all prerequisites held, recent `schedule_is_performance` at H3/H4 → `S_H_D09_0031`; recent `perfect_clock_claim` → `S_H_D09_0032`; interrupted draft at H3/H4 → `S_H_D09_0033`.

### H_D09_0
**If E12 missing**

**P00 | 나여백 [S_H_D09_0001]**

부스가 원래 어떤 순서를 계획했는지 적힌 진행표가 없습니다. 먼저 해금 씨의 진행표를 확인해야 `예정`과 실제 일을 비교할 수 있습니다.

**If E17 missing**

**P00 | 나여백 [S_H_D09_0012]**

제가 어두워진 걸 기억하는 것만으로 전원 차단과 복귀 시각을 쓰면 안 됩니다. 장비가 남긴 전원 기록부터 확인하세요.

**If E18 missing / public observation not reindexed**

**P00 | 나여백 [S_H_D09_0013]**

계획표와 장비 기록만 있으면 공개 자리에서 실제로 어떤 순서로 겪었는지가 빠집니다. 전날 공개 카운트 기록을 다시 펼쳐야 합니다.

**If E12+E17+E18 held**

**P00 | 나여백 [S_H_D09_0014]**

세 출처가 다 있습니다. 이제 계획표에 적힌 순서와 실제 현장·전원 기록을 같은 것으로 취급하지 않으면 됩니다.

### H_D09_1
**P00 | 나여백 [S_H_D09_0011]**

음향 진행표의 행은 계획이고, 전원 복귀 기록의 차단/복귀는 장비가 실제로 남긴 사건이며, 공개 점검 기록은 공개 자리에서 실제로 겪은 신호와 리셋입니다.

### H_D09_2
**P00 | 나여백 [S_H_D09_0021]**

비교할 자료는 `음향 진행표`, `전원 복귀 기록`, `공개 점검 기록`입니다. 한 장의 예정표를 세 번 읽어 독립 확인으로 만들면 안 됩니다.

### H_D09_3
**If recent error = schedule_is_performance**

**P00 | 나여백 [S_H_D09_0031]**

방금은 진행표에 적힌 일을 실제로 수행된 일처럼 읽었습니다. 계획은 계획대로 두고, 실제 순서는 전원 기록과 현장 관찰로 다시 세워야 합니다.

**If recent error = perfect_clock_claim**

**P00 | 나여백 [S_H_D09_0032]**

세 시계가 1분 안에서 맞았다는 기록은 `초까지 정확하다`는 뜻이 아닙니다. 여기서는 분 단위 순서까지만 남기면 충분합니다.

**If returning after interruption with all three sources held**

**P00 | 나여백 [S_H_D09_0033]**

중간에 멈춘 자리는 현장 신호 뒤에 전원이 끊겼다가 돌아온 것까지였습니다. 마지막에 20시 30분 녹음 안내를 놓으면 됩니다.

### H_D09_4
**If unresolved**

**P00 | 나여백 [S_H_D09_0041]**

정리할 문장은 이 정도면 됩니다. `현장 조명 확인 신호 뒤 전원이 끊겼다가 돌아왔고, 그 뒤 20시 30분에는 녹음 안내가 재생됐다. 진행표는 예정일 뿐 실제 수행 증거가 아니다.`

**If already completed / revisit**

**P00 | 나여백 [S_H_D09_0042]**

이 순서는 이미 닫혔습니다. 다시 볼 때는 `신호 → 전원 중단/복귀 → 20:30 녹음 안내`만 유지하고 정확한 추락 시각은 붙이지 않습니다.

---

## C_CH02_07 — 조용한 마이크 의식

### Context
- Place: L02.
- Cast: P00, P01, P05; P03 appears only for the opening same-place supervision handback.
- Entry: K08 and K09 are both held, in either completion order. After the second of D08/D09 closes, P00 returns from L01 to L02. P03 has kept P01 in the same lounge since C_CH02_05 and explicitly hands supervision back. P05 returns after equipment work.
- Exit: ordinary emotional beat before D10; no new E/K. P00 and P01 remain together at scene end.
- E/S/K/B: no evidence/K changes. Dialogue respects the selected B_PLAYBACK_RESPONSE without converting `need_time` into forgiveness.
- Repeat/resume: selected branch is replayed only as a short callback; no unselected apology branch is surfaced.

### Script

*여백이 휴게실로 돌아오자 차무록은 모눈이 적어 둔 파일 이름 쪽지를 접어 그대로 모눈 앞에 놓는다.*

**P03 | 차무록 [S_CH02_07_0040]**

모눈이는 여기서 계속 저와 있었습니다. 이제 다시 {playerName} 씨에게 맡길게요.

**P00 | 나여백 [S_CH02_07_0041]**

고맙습니다. 모눈아, 기다리게 해서 미안해.

**P01 | 나모눈 [S_CH02_07_0042]**

괜찮아. 세 글자짜리 파일 이름만 네 개 만들었어.

*차무록이 접수표를 들고 맞은편 테이블로 옮겨간 뒤, 소해금이 휴게실 한쪽에 고장 난 마이크 스탠드를 세워 놓고 종이컵을 앞에 둔다.*

**P01 | 나모눈 [S_CH02_07_0001]**

또 묵념해?

**P05 | 소해금 [S_CH02_07_0002]**

이번엔 `고장 난 척해서 사람을 헷갈리게 한 정상 마이크`에 대한 반성입니다.

*해금이 마이크 스위치를 확인하고 고개를 숙인다. 스피커에서 그녀의 숨소리가 크게 난다. 해금이 눈을 감은 채 손을 뻗어 스위치를 끈다.*

**P00 | 나여백 [S_CH02_07_0003]**

의식보다 체크리스트가 빠를 것 같습니다.

**P05 | 소해금 [S_CH02_07_0004]**

저도 지금 그렇게 배우는 중입니다.

**If B_PLAYBACK_RESPONSE=accept_apology**

**P01 | 나모눈 [S_CH02_07_0011]**

사과 받은 건 받은 거고, 내 파일은 아직 내 거야.

**P05 | 소해금 [S_CH02_07_0012]**

응. 그 두 문장을 같은 말로 만들지 않을게.

**If B_PLAYBACK_RESPONSE=need_time**

**P01 | 나모눈 [S_CH02_07_0021]**

난 아직 사과 대답 안 했어.

**P05 | 소해금 [S_CH02_07_0022]**

알아. 기다린다고 허락이 생기는 것도 아니고, 네가 나중에 꼭 괜찮아져야 하는 것도 아니야.

*여백은 음향 진행표/전원 복귀 기록/공개 점검 기록 순서를 세 칸으로 적는다. 모눈이 종이컵을 `고장 안 난 마이크` 앞에서 치운다.*

**P00 | 나여백 [S_CH02_07_0031]**

순서는 정리됐습니다. 이제 남는 건, 직접 대면 뒤부터 발견까지 무엇이 비어 있는지입니다.

---

## C_D10 — 방송으로 설명할 수 없는 빈틈은 어디일까?

### Context
- Place: L02 supervision handoff → L01 investigation table.
- Cast: P00, P07, P09 in L01; P03 and P01 appear only for the opening/closing same-place handoff in L02.
- Entry: K05 + K07 + K08 + K09. C_CH02_07 has just returned P01 to P00; P03 is still working at the other L02 table. Before P00 goes back to L01 for the convergence deduction, P03 explicitly receives P01 again.
- Exit: success creates K10 and motivates the covered-cart inquiry. P00 returns to L02 and P03 explicitly hands P01 back before C_CH02_08. No exact death minute or culprit is established.
- E/S/K/B: reads K05/K07/K08/K09; branches incomplete, two named errors, success, retry, current revisit.
- Repeat/resume: on error/interruption P00 remains in the same L01 target with P01 still supervised in L02; only success triggers the return handback.

### Entry states
- Required: K05, K07, K08, K09.
- D08/D09 order does not matter; both must be complete.
- Does not establish exact death minute or culprit.

### Setup

*휴게실의 마이크 장난이 끝나자 여백은 맞은편 테이블의 차무록에게 다시 다가간다.*

**P00 | 나여백 [S_D10_0002]**

무록 씨, 마지막으로 현관 표 하나만 맞추고 오겠습니다. 모눈이와 여기서 한 번만 더 있어 주실 수 있을까요?

**P03 | 차무록 [S_D10_0003]**

네. 아까처럼 이 자리에서 기다리겠습니다. 돌아오시면 바로 넘길게요.

**P01 | 나모눈 [S_D10_0004]**

이번엔 진짜 표 하나지?

**P00 | 나여백 [S_D10_0005]**

응. 지금까지 맞춘 시간표 하나.

*여백은 모눈과 차무록이 같은 휴게실 테이블에 남은 것을 확인하고 현관 조사 탁자로 돌아간다. 진새벽과 목백로가 앞서 펼친 세 기록을 그대로 보존하고 있다.*

**P00 | 나여백 [S_D10_0001]**

방 하나의 알리바이는 약해졌고, 20시 30분 목소리도 사람의 현재 위치를 증명하지 못했습니다. 마지막 대면과 공개 사건 순서를 합쳐, 아직 직접 증거가 없는 구간을 표시하겠습니다.

> **D10:** `방송으로 설명할 수 없는 빈틈은 어디일까?`

### B_D10_incomplete

**P00 | 나여백 [S_D10_0011]**

마지막으로 직접 만난 시각과, 공개 자리에서 신호·정전·안내가 실제로 이어진 순서를 둘 다 정리해야 합니다. 어느 한쪽이 비어 있으면 그 사이 시간을 성급히 채우지 않겠습니다.

> 여유 변화 없음.

### B_D10_success

**P00 | 나여백 [S_D10_0021]**

직접 대면은 20시 10–12분 사이까지 확인됩니다. 그 뒤 공개 신호·중단·복귀가 있었고 20시 30분에는 과거 녹음이 재생됐습니다. 방 목격도 연속 재실을 증명하지 못합니다.

**P00 | 나여백 [S_D10_0022]**

따라서 **20시 12분 이후부터 21시 05분 발견 통화 전까지**는 표문식 씨의 실제 위치와 상태를 직접 채워 줄 자료가 아직 없습니다. 그 안의 신호 순서는 알지만, 지금은 `사망 20:19` 같은 정확한 분을 쓰지 않습니다.

**P07 | 진새벽 [S_D10_0023]**

좋습니다. `열린 조사 구간`이지 `정답 사망 시각`이 아닙니다.

**P09 | 목백로 [S_D10_0024]**

그럼 그 사이 제가 찍은 수레 사진도 보셔야겠네요. 사람처럼 보여서 저도 자꾸 마음에 걸렸던 겁니다.

- Author state: **K10 획득.** V03/CH03 inquiry becomes motivated.

*여백은 결론을 적은 뒤 곧바로 휴게실로 돌아온다. 차무록은 모눈과 같은 테이블에서 접수표를 정리하고 있었다.*

**P03 | 차무록 [S_D10_0025]**

끝났습니다. 모눈이는 계속 여기 있었어요. 다시 {playerName} 씨에게 맡길게요.

**P00 | 나여백 [S_D10_0026]**

고맙습니다. 이제 다음 조사 약속을 잡기 전까지는 같이 있겠습니다.

### B_D10_err_automatic_culprit

**P00 | 나여백 [S_D10_0031]**

무록 씨 방 알리바이가 약해졌고 문식 씨 목소리도 녹음이니, 빈 시간대의 범인은 무록 씨라고 결론 내리겠습니다.

**P07 | 진새벽 [S_D10_0032]**

알리바이가 사라지는 건 범행 증거가 생기는 것과 다릅니다. 그 시간에 무엇이 일어났는지 직접 뒷받침할 자료가 아직 없습니다.

> 여유 `-2`.

### B_D10_err_exact_death_minute

**P00 | 나여백 [S_D10_0041]**

전원이 20시 19분에 끊겼으니 표문식 씨는 20시 19분에 사망했다고 적겠습니다.

**P07 | 진새벽 [S_D10_0042]**

전원 기록은 전원 사건을 기록합니다. 추락을 본 기록이 아직 없고, 생리적 사망 시각은 더더욱 여기서 정할 수 없습니다.

> 여유 `-2`.

### B_D10_retry

**P00 | 나여백 [S_D10_0081]**

빈칸을 범인이나 사망 분으로 채웠습니다. 이번에는 `확인된 마지막 대면`과 `발견` 사이의 미확인 범위만 표시하겠습니다.

### Current revisit

**P00 | 나여백 [S_D10_0091]**

20시 12분 이후 발견 전까지는 아직 직접 확인이 끊긴 구간으로 남아 있습니다. 다음에는 그 사이에 실제로 움직인 화물과 사람의 길을 따로 확인해야 합니다.

---

## C_H_D10 — D10 힌트

### Context
- Place/cast: P00's active convergence draft at L01; P07/P09 are present for already-established record limits. P01 remains supervised by P03 in L02 until D10 success and the explicit return handback.
- Entry: D10 unresolved, interrupted, recently failed, or completed/revisited. Selector checks K05/K07/K08/K09, recent named error and K10 state.
- Exit/effects: hint only; no E/K/B/여유 change and no culprit/death-minute creation.
- Repeat/resume: missing prerequisite wins over answer guidance; recent-error guidance targets only the selected bad premise; completed revisit gives the boundary only.

#### Deterministic selector (normative)
- Return exactly one Korean S line. Priority: `K10 complete` → `missing prerequisite` → recent named error at H3/H4 → interruption at H3/H4 → requested all-held level.
- K10 complete, any H0–H4 → `S_H_D10_0042`.
- K05 or K07 missing → `S_H_D10_0013`; else K08 missing → `S_H_D10_0001`; else K09 missing → `S_H_D10_0012`, regardless of requested level.
- All held: H0 `S_H_D10_0014`, H1 `S_H_D10_0011`, H2 `S_H_D10_0021`, H3 `S_H_D10_0011`, H4 `S_H_D10_0041`.
- With all prerequisites held, recent `automatic_culprit` at H3/H4 → `S_H_D10_0031`; recent `exact_death_minute` → `S_H_D10_0032`; interrupted draft at H3/H4 → `S_H_D10_0033`.

### H_D10_0
**If K08 missing**

**P00 | 나여백 [S_H_D10_0001]**

아직 마지막으로 표문식 씨를 직접 만난 시각이 정리되지 않았습니다. 사람 기록 봉투부터 끝내야 빈 시간대의 시작점을 잡을 수 있습니다.

**If K09 missing**

**P00 | 나여백 [S_H_D10_0012]**

직접 대면 시각은 있어도, 그 뒤 공개 자리에서 신호와 정전, 안내가 어떤 순서였는지 아직 정리되지 않았습니다. 그 순서를 먼저 닫으세요.

**If K05 or K07 missing**

**P00 | 나여백 [S_H_D10_0013]**

방 목격이나 20시 30분 목소리를 아직 `현재 위치 증명`으로 남겨 둔 부분이 있습니다. 그 두 알리바이처럼 보이는 단서부터 다시 검토해야 합니다.

**If K05+K07+K08+K09 held**

**P00 | 나여백 [S_H_D10_0014]**

필요한 앞 단계는 다 끝났습니다. 이제 `마지막 직접 대면`과 `21시 05분 발견` 사이에서 실제로 확인된 것과 비어 있는 것을 한 줄에 놓으면 됩니다.

### H_D10_1
**P00 | 나여백 [S_H_D10_0011]**

방의 목격은 연속 재실이 아니고, 20:30 음성은 과거 녹음입니다. 두 개의 늦은 알리바이처럼 보이던 것이 사라지면, 직접 확인이 끊기는 지점이 보입니다.

### H_D10_2
**P00 | 나여백 [S_H_D10_0021]**

마지막 직접 대면은 20시 10분에서 12분 사이입니다. 20시 30분 목소리는 녹음이고, 방에서 본 사람도 계속 그 자리에 있었다고 보장하지 않습니다. 발견 통화는 21시 05분입니다. 그 사이 공개 신호의 순서는 알지만 추락을 직접 본 자료는 아직 없습니다.

### H_D10_3
**If recent error = automatic_culprit**

**P00 | 나여백 [S_H_D10_0031]**

방금은 `비어 있는 시간`을 곧바로 `무록 씨가 범인인 시간`으로 바꿨습니다. 알리바이가 약해졌다는 것과 범행 증거가 생겼다는 것은 다릅니다.

**If recent error = exact_death_minute**

**P00 | 나여백 [S_H_D10_0032]**

전원이 20시 19분에 끊겼다는 사실은 사망 시각이 아닙니다. 전원 사건과 사람의 추락을 같은 시각표에 자동으로 겹치지 마세요.

**If returning after interruption with all prerequisites held**

**P00 | 나여백 [S_H_D10_0033]**

중간에 멈춘 결론은 `20시 12분 이후부터 발견 전까지 직접 확인이 끊긴다`였습니다. 범인이나 정확한 사망 분을 덧붙이지 않고 그 범위만 남기면 됩니다.

### H_D10_4
**If unresolved**

**P00 | 나여백 [S_H_D10_0041]**

정리할 문장은 이렇습니다. `표문식 씨는 20시 10–12분 사이까지 직접 대면이 확인되지만, 20시 30분 목소리는 녹음이고 방 목격도 연속 재실을 증명하지 않는다. 그래서 20시 12분 이후 21시 05분 발견 전까지 실제 위치와 상태는 아직 비어 있다.`

**If already completed / revisit**

**P00 | 나여백 [S_H_D10_0042]**

이 결론은 이미 닫혔습니다. 다시 볼 때는 `열린 조사 구간`만 유지하고 범인이나 사망 분을 새로 붙이지 않습니다.

---

## C_CH02_08 — 덮인 수레를 다시 묻다

### Context
- Place: L02 handoff → L01.
- Cast: P00, P07, P09 in L01; P02 appears only for the opening P01 supervision handoff in L02.
- Entry: K10. After C_CH02_07, P00 and P01 are together in L02. Before P00 returns to the investigation table, P02 explicitly receives P01 in the same lounge.
- Exit: P09 offers the CH03 cargo inquiry; no E20 is acquired yet. P00 immediately returns to L02, P02 hands P01 back, and P00 resumes direct supervision until CH03_01 explicitly asks P02 again.
- E/S/K/B: no new evidence/K/B. CH03 inquiry appointment becomes available only.
- Repeat/resume: revisit repeats the appointment/limits, not an unseen photo inspection.

### Script

*봉만실이 물병을 들고 휴게실로 들어오자 여백이 자리에서 일어난다.*

**P00 | 나여백 [S_CH02_08_0010]**

만실 씨, 현관에서 다음 조사 약속만 잡고 올 동안 모눈이와 같이 있어 주실 수 있을까요?

**P02 | 봉만실 [S_CH02_08_0011]**

그래요. 오늘은 이 방 밖으로 안 나가고 여기 있을게요. 다녀와요.

**P01 | 나모눈 [S_CH02_08_0012]**

사진은 나 몰래 먼저 결론 내리지 마.

**P00 | 나여백 [S_CH02_08_0013]**

약속만 잡고 올게. 사진은 실제 조사할 때 같이 확인하자.

*여백이 두 사람을 같은 휴게실에 남겨 두고 현관 조사 탁자로 간다. 목백로가 사진 봉투를 바로 내밀려다가 멈춘다.*

**P09 | 목백로 [S_CH02_08_0001]**

이 사진만 여기서 먼저 보면 덮개 모양에 끌려갈 것 같아요. 제가 찍은 자리와 수레가 온 길까지 같이 볼 때 여는 게 낫겠습니다. 덮개 아래가 사람처럼 보여서 찍은 건 맞습니다.

**P00 | 나여백 [S_CH02_08_0002]**

사진만 보고 내용을 확정하진 않겠습니다. 찍은 자리와 이동 가능한 길, 실제 인계 기록까지 같이 보겠습니다.

**P07 | 진새벽 [S_CH02_08_0003]**

내일이 아니라 오늘 오후에 할 수 있습니다. 먼저 주방에서 배한술 씨를 만나고, 그 다음 적재 데스크에서 사진과 수레를 확인하세요. 모눈이는 위험 구역에 데려가지 않습니다.

**P09 | 목백로 [S_CH02_08_0004]**

그리고 제 모래시계는 안 빌려드립니다. 지난번에 빌려드린 영수증을 아직 제가 갖고 있어서 순서가 꼬였습니다.

**P00 | 나여백 [S_CH02_08_0005]**

그건 반납한 물건의 영수증이 남은 거죠.

**P09 | 목백로 [S_CH02_08_0006]**

그러니까 더 위험합니다. 종이만 보면 아직 빌려준 것 같잖아요.

*여백은 그 말에 잠깐 멈춘다. 기록과 현재 상태를 구분해야 한다는 말이, 이번 장에서 반복해서 확인한 문제와 닮아 있다.*

**P00 | 나여백 [S_CH02_08_0007]**

사진도 같은 방식으로 보겠습니다. `보였던 것`과 `실제로 들어 있던 것`을 나누겠습니다.

*약속만 잡은 여백은 곧바로 휴게실로 돌아온다. 봉만실은 처음 자리에서 모눈과 점심 그릇을 정리하고 있다.*

**P02 | 봉만실 [S_CH02_08_0014]**

약속은 잡았어요? 모눈이는 계속 여기 있었어요. 이제 다시 데리고 있어요.

**P00 | 나여백 [S_CH02_08_0015]**

고맙습니다. 네, 다음 확인은 주방과 적재 데스크에서 하기로 했어요. 그때 다시 부탁드리기 전까지는 제가 같이 있겠습니다.

**P01 | 나모눈 [S_CH02_08_0016]**

그럼 지금은 밥부터. 사진은 진짜 보러 갈 때 같이 생각해.

---

## C_CH02_O1 — 목소리를 빌리는 일

### Context
- Place: L02.
- Cast: P00, P01, P05.
- Entry: after Q02 and C_CH02_04; available on a calm revisit. Uses only the selected B_PLAYBACK_RESPONSE branch.
- Exit: no evidence/K/relationship score change; consent language is clarified without granting new permission.
- E/S/K/B: reads B_PLAYBACK_RESPONSE; writes nothing.
- Repeat/resume: if replayed, only the selected apology-response callback is shown.

### Script

*휴게실. 모눈은 자기 녹음기 파일 목록을 소해금에게 보여 주되 화면은 자기 손에 들고 있다.*

**P01 | 나모눈 [S_CH02_O1_0001]**

이모 목소리는 허락받았고, 내 목소리는 내가 정하고, 의자 소리는 의자한테 물어볼 수 없잖아. 그럼 의자는 그냥 써도 돼?

**P05 | 소해금 [S_CH02_O1_0002]**

사람 목소리와 같은 동의 문제는 아니지만, 장소 규칙이나 다른 사람 대화가 같이 들어가면 또 달라져. 그래서 `무슨 소리를, 어디까지` 쓰는지 확인하는 게 좋아.

**P00 | 나여백 [S_CH02_O1_0003]**

허락을 한 번 받았다고 모든 사용이 허락되는 것도 아니고.

**P01 | 나모눈 [S_CH02_O1_0004]**

그건 오늘 배웠어. 별로 좋은 방법으로 배우진 않았지만.

**If B_PLAYBACK_RESPONSE=accept_apology**

**P05 | 소해금 [S_CH02_O1_0011]**

응. 네가 사과를 받아 준 걸 사용 허락으로 착각하지 않겠습니다.

**If B_PLAYBACK_RESPONSE=need_time**

**P05 | 소해금 [S_CH02_O1_0021]**

그리고 네가 아직 사과에 답하지 않은 것도 그대로 둘게. 파일 얘기 때문에 답을 재촉하지 않겠어.

*이 장면은 필수 단서를 주지 않는다.*

---

## C_CH02_O2 — 장비보다 먼저 사과하기

### Context
- Place: L03 public equipment edge.
- Cast: P00, P04, P05.
- Entry: optional window after C_CH02_05 and before C_CH02_07, while P01 is explicitly still supervised by P03 in L02. P00 walks from L01/L02 to the public equipment edge; no unresolved challenge is required.
- Exit: P00 returns toward L02; ordinary relationship beat only, no E/K/B change.
- Repeat/resume: one-time optional scene; revisit becomes a short equipment-check callback and does not re-run the apology.

### Script

*연회장. 탁두철이 케이블 카트를 부스 앞에 세우고 카트 손잡이에 대고 말한다.*

**P04 | 탁두철 [S_CH02_O2_0001]**

너는 여기서 멈추고, 바퀴 잠그고, 사람이 지나가면—

**P05 | 소해금 [S_CH02_O2_0002]**

카트가 대답하기 전에 나한테 먼저 말해.

**P04 | 탁두철 [S_CH02_O2_0003]**

...케이블 지난번에 내가 너무 세게 말아서 피복 상한 거 미안하다.

**P05 | 소해금 [S_CH02_O2_0004]**

그건 케이블한테 사과해야 하고.

**P04 | 탁두철 [S_CH02_O2_0005]**

그러니까 장비보다 사람 먼저 하라며.

**P05 | 소해금 [S_CH02_O2_0006]**

맞는데, 순서가 왜 늘 한 칸씩 어긋나.

**P00 | 나여백 [S_CH02_O2_0007]**

두 분 다 오늘은 고치려는 대상이 무엇인지 먼저 적지 않는 편이 낫겠습니다.

*둘이 동시에 여백을 본다. 장면은 웃음으로 억지 해소되지 않고, 해금이 카트 브레이크를 직접 확인하는 것으로 끝난다.*

---

## C_CH02_O3 — 비어 있는 자리

### Context
- Place: L02.
- Cast: P00, P02; P01 is physically present at the adjacent puzzle table but has no line.
- Entry: available after C_CH02_08. P00 returns from L01 to L02, where P02 has continuously supervised P01 since the C_CH02_08 handoff.
- Exit: P00 resumes direct supervision of P01 in the same lounge. Grief/absence beat only; no E/K/B change.
- Repeat/resume: one-time scene; no forced closure on revisit.

### Script

*저녁 직전 휴게실. 봉만실이 작은 상 하나를 차리다가 네 번째 수저를 놓고 멈춘다. 전날 표문식이 서서 식사하겠다고 고집했던 자리다.*

**P02 | 봉만실 [S_CH02_O3_0001]**

저 양반은 앉으라고 해도 그 의자는 서류 받는 자리라고 안 앉았어요. 발 아프다고 투덜대면서도.

**P00 | 나여백 [S_CH02_O3_0002]**

처음 만났을 때도 그랬습니다. 의자를 사람보다 먼저 업무에 배정했죠.

**P02 | 봉만실 [S_CH02_O3_0003]**

그래서 사람 없는 자리가 더 눈에 띄네요.

*봉만실은 수저를 치우지 않고 상 아래 서랍에 넣는다.*

**P02 | 봉만실 [S_CH02_O3_0004]**

빈 자리라고 바로 정리하면, 아직 밥 먹는 사람도 쫓아내는 것 같아서. 오늘은 그냥 여기까지만 둘래요.

**P00 | 나여백 [S_CH02_O3_0005]**

네. 정리는 나중에 하죠.

*필수 단서나 관계 점수는 발생하지 않는다.*

---

## CH02 current completion note

- Author note: CH02 assigned core/O/D/Q/H coverage is fully revised for r02. Next story entry: C_CH03_01.

