# CH01 — 옮겨진 방

- Packet: `YEOWUL-FULL-v3`
- Revision: `r03`
- Status: `draft`
- Fixed preceding continuity: accepted `C_PR_01..05` + revised candidate `C_PR_06..16` + `C_SYS_04`
- Coverage: focused r03 revision of all assigned CH01 units, preserving the working-r02-c01 local fixes. F01 hint selection and F02 early-Q01 live-state continuity are revised here.

## C_CH01_01 — 두 장의 방

### Context
- Place: L02
- Cast: P00, P01, P02
- Time: 10/22 morning
- Entry: After C_PR_16 and the arranged town-guesthouse night. P00/P01 return together for the planned workday. Held: E01/E02/E03/E18/E39/E28 and P00's consented public-event recording; no K.
- Exit: P02's memory sketch and E03 are recognized as different kinds of records. P00 has an ordinary reason to inspect the actual ballroom geometry before making any case claim.
- E/S/K/B: no new E/K/B. Existing E03 remains a non-scale public plan. No Q correction occurs here.
- Effects: none.
- Repeat/resume: revisit shows the same sketch and plan; no new geometry is generated from repeated viewing.

### Script

*아침 식사가 끝나 갈 무렵, 휴게실 탁자에는 토스트 접시 세 개와 여백의 작업 수첩, 어젯밤 접어 둔 행사장 안내도가 함께 놓여 있다. 모눈은 우유 잔 밑에 자기 분실물 접수표를 받침처럼 깔았다가 여백에게 한 번 제지당한 상태다.*

*봉만실은 현관에서 작은 나무패 두 개를 들고 들어온다. 하나에는 `203`, 다른 하나에는 `205`가 적혀 있다.*

**P02 | 봉만실 [S_CH01_01_0001]**

203은 오늘 비워 두고, 205는 점심 전에 말려야겠어요.

**P00 | 나여백 [S_CH01_01_0002]**

객실이요?

**P02 | 봉만실 [S_CH01_01_0003]**

우산이요.

*만실은 잠깐 정색하다가 나무패 뒤의 작은 고리를 보여 준다. 현관 우산꽂이에 걸던 번호표다.*

**P02 | 봉만실 [S_CH01_01_0004]**

방 번호를 우산한테 빌려줬더니 사람이 자꾸 체크아웃을 해요. 203 우산은 어제 손잡이가 빠져서 퇴역했고, 205는 젖었습니다.

**P01 | 나모눈 [S_CH01_01_0005]**

그럼 203호는 빈 방이 아니라 빈 우산 자리네.

**P00 | 나여백 [S_CH01_01_0006]**

방금은 제가 번호만 보고 객실이라고 생각했네요.

**P02 | 봉만실 [S_CH01_01_0007]**

그러니까 번호는 사람을 안심시키면 안 돼요. 우리 집 번호는 특히.

*만실은 번호패를 의자 위에 두려다가, 모눈의 접수표가 놓여 있는 걸 보고 탁자 끝으로 옮긴다. 그 과정에서 여백의 행사장 안내도가 반쯤 펼쳐진다.*

**P02 | 봉만실 [S_CH01_01_0008]**

그 약도 아직 보고 있어요?

**P00 | 나여백 [S_CH01_01_0009]**

어제 공개된 동선만 확인하려고요. 실제 비율이 아니라는 표시는 봤습니다.

*만실은 빈 냅킨 한 장을 끌어와 볼펜으로 네모를 그리고, 위쪽에 창을 하나, 가운데에 세로선을 하나 긋는다. 창 아래에는 의자처럼 보이는 작은 사각형을 그린다.*

**P02 | 봉만실 [S_CH01_01_0010]**

어젯밤 무록 씨는 여기 있었어요. 북쪽 창으로 보면 이쪽 방에 의자가 있고, 그 근처에 사람이 있었거든요.

**P00 | 나여백 [S_CH01_01_0011]**

이 선은 칸막이인가요?

**P02 | 봉만실 [S_CH01_01_0012]**

네. 직원들이 쓰는 쪽하고 손님들이 쓰는 쪽을 나누는 거요. 나는 창가가 작업하는 쪽이라고 생각했어요.

*여백은 냅킨을 들지 않고 행사장 안내도의 `직원 출입구` 표시와 북쪽 방향만 번갈아 본다. 약도에는 실제 비율이 아니라는 경고가 있어, 선만으로 거리를 확정할 수 없다.*

**P01 | 나모눈 [S_CH01_01_0013]**

둘 다 네모인데 왜 달라?

**P00 | 나여백 [S_CH01_01_0014]**

하나는 길 찾는 약도고, 하나는 봉 선생님 기억으로 그린 그림이라서. 어느 쪽도 자로 잰 도면은 아니야.

**P02 | 봉만실 [S_CH01_01_0015]**

그래도 창은 안 움직여요. 문도 안 움직이고. 칸막이는 움직여요. 어제 행사 때문에 넓혀 놨고요.

**P00 | 나여백 [S_CH01_01_0016]**

그럼 실제 방에서 창, 문, 칸막이 정지 위치를 따로 보는 게 먼저겠네요.

**P02 | 봉만실 [S_CH01_01_0017]**

두철 씨가 지금 그 바퀴 보고 있을 거예요. 어젯밤에 쓰고 나서 한쪽이 걸리더라고. 경찰 쪽에서도 손대기 전에 상태만 보라고 했고요.

**P01 | 나모눈 [S_CH01_01_0018]**

밥 다 먹고 가면 돼?

**P00 | 나여백 [S_CH01_01_0019]**

응. 방부터 뛰어가지는 말고. 네 접시도 끝내고.

*모눈이 마지막 토스트 조각을 입에 넣는다. 만실은 냅킨 그림 아래에 `기억 그림`이라고 적는다.*

**P02 | 봉만실 [S_CH01_01_0020]**

이건 증거 도면 아니에요. 내가 어젯밤에 어디라고 생각했는지 그린 거예요. 그건 구분해 둡시다.

**P00 | 나여백 [S_CH01_01_0021]**

좋습니다. 실제 위치를 보고 나서 비교하죠.

### Current revisit

*연회장 확인 전 다시 휴게실로 돌아오면 냅킨 그림과 행사장 안내도는 나란히 볼 수 있다. 둘을 겹쳐 하나의 정밀 도면처럼 취급할 수는 없다.*

**P00 | 나여백 [S_CH01_01_0091]**

지금 필요한 건 기억 그림을 더 자세히 꾸미는 게 아니라, 실제로 고정된 것과 움직이는 걸 확인하는 거예요.

**P01 | 나모눈 [S_CH01_01_0092]**

그리고 203은 방 아니고 우산 자리. 그건 이제 안 틀려.

---

## C_CH01_02 — 바퀴에게 먼저 말하는 사람

### Context
- Place: L03
- Cast: P00, P01, P04, P02
- Entry: C_CH01_01. P02 leads P00/P01 L02→L01→L03. P04 is first foregrounded while actually repairing the partition wheel. P00 still has no K.
- Exit: E04/E05 are inspected as distinct work/geometry sources. P02 states the sole current S_Q01_v1 without correcting it. E10 may be inspected early. Objective: `창가의 목격이 무엇을 증명하는지 확인하자.`
- E/S/K/B: acquire E04/E05; optional E10. Define S_Q01_v1 here only. No K and no E08/KQ01 before C_Q01 success.
- Effects: P04/P02 remain available for D01/D02; V01 is not joinable until K02.
- Repeat/resume: already acquired E04/E05/E10 are reopened, not reacquired; interrupted album viewing resumes on the same print.

### Script

*연회장 문 앞에서 만실이 먼저 멈춘다. 문 안쪽 바닥에는 노란 안전선이 임시로 붙어 있고, 어젯밤 보았던 긴 칸막이는 현재 서쪽으로 넓은 손님 공간을 만든 상태다. 한 남자가 칸막이 아래 바퀴 덮개를 열어 놓고 쪼그려 앉아 있다.*

*남자는 드라이버를 바닥에 두고, 바퀴를 손끝으로 두 번 밀어 본 뒤 낮게 말한다.*

**P04 | 탁두철 [S_CH01_02_0001]**

지금부터 네가 할 일은 안 움직이는 거야. 어제는 잘 움직였으니까 오늘은 그 반대쯤 해.

*그가 바퀴 옆에 끼워 둔 종이표가 바닥으로 미끄러진다.*

**P04 | 탁두철 [S_CH01_02_0002]**

아, 그 표만 좀 잡아주실래요? 바퀴는 말 안 듣는데 종이는 너무 잘 갑니다.

**P00 | 나여백 [S_CH01_02_0003]**

표만 잡겠습니다. 장비에는 손대지 않고요.

*여백이 종이표 끝을 눌러 준다. 남자는 나사를 조이려다가 공구 이름을 잠깐 잊은 듯 손에 든 것을 본다.*

**P04 | 탁두철 [S_CH01_02_0004]**

십자... 아니, 얘는 일자였나. 됐고, 저는 탁두철입니다. 이 건물 자잘한 수리 맡아 왔어요.

**P02 | 봉만실 [S_CH01_02_0005]**

자잘한 수리라고 말하면 견적서도 자잘해 보이잖아. 칸막이는 큰 수리예요.

**P04 | 탁두철 [S_CH01_02_0006]**

그럼 큰 수리 맡은 탁두철입니다. 지금은 바퀴 하나가 걸려서 작은 욕을 먹고 있고요.

**P01 | 나모눈 [S_CH01_02_0007]**

바퀴한테 먼저 말했어요.

**P04 | 탁두철 [S_CH01_02_0008]**

사람한테 말하면 대답을 하잖아요. 바퀴는 대답을 안 해서 편해요.

*두철은 일어나 칸막이 아래의 놋쇠 정지표시 두 곳을 가리킨다. 바닥에는 `6`, 조금 동쪽에는 `9`가 박혀 있고, 그 사이로 최근 바퀴 자국이 이어져 있다. 남쪽의 손님 출입문과 직원 출입문은 벽에 고정되어 있다. 북쪽 창도 같은 자리에 있다.*

**P04 | 탁두철 [S_CH01_02_0009]**

벽은 이 레일에서만 움직입니다. 여기 6, 저기 9. 창하고 문은 벽에 붙어 있으니 안 움직이고요.

#### E05 — 두 정지선

> 성인 입회 아래 촬영한 연회장 실측 사진과 치수 삽입도.
> 연회장 내부: 동서 12m × 남북 10m. 남서 모서리를 기준 `(0,0)`으로 표시.
> 남쪽 손님 출입문 중심 `x=3m`, 남쪽 직원 출입문 중심 `x=10m`, 북쪽 고정 창 중심 `x=7m`.
> 칸막이 놋쇠 정지선은 `x=6m`와 `x=9m`; 두 표식 사이에 최근 바퀴 자국이 남아 있다.
> 창과 두 문은 벽체에 고정되어 있고 칸막이만 레일 위에서 이동한다.
> 사진 안 눈금자와 바닥 치수는 실제 현장 실측이다.
> **제한:** 두 배치를 실제로 만들 수 있음을 보여 주지만, 바퀴 자국만으로 이동 시각을 정할 수 없다.

**P00 | 나여백 [S_CH01_02_0010]**

지금 칸막이는 바닥의 9미터 표식에 서 있네요.

**P04 | 탁두철 [S_CH01_02_0011]**

네. 어제 저녁 행사 크게 쓴다고 여기까지 옮겼습니다. 움직이는 건 맞는데, 저절로는 안 움직여요.

*두철이 아까 여백이 눌러 주던 종이표를 집어 든다. 칸막이 잠금쇠 열쇠에 클립으로 묶인 작업표다.*

#### E04 — 칸막이 작업표

> `10/21 19:40 시작 · 19:46 종료`
> `큰 홀 사용 / 정지선 9`
> `작업: 탁두철`
> `보조·확인: 봉만실`

**P00 | 나여백 [S_CH01_02_0012]**

어젯밤 작업하면서 바로 적은 겁니까?

**P04 | 탁두철 [S_CH01_02_0013]**

끝나고 잠금 확인하면서 적었습니다. 봉 사장님도 옆에 있었고요. 다만 종이에 적혀 있다고 바닥 자국이 그 시각에 생긴 것까지 자동으로 증명되는 건 아니죠. 제가 한 작업이라고 적은 거니까.

**P02 | 봉만실 [S_CH01_02_0014]**

내가 같이 민 건 맞아요. 손님들 앉을 자리가 모자라서 큰 홀로 썼고.

**P04 | 탁두철 [S_CH01_02_0015]**

그런데 사장님이 말하는 `큰 홀`하고 제가 기억하는 요청이 좀 달라요. 그 얘기는 벽 움직이기 전에 경찰 허락 받고 다시 합시다.

**P02 | 봉만실 [S_CH01_02_0016]**

뭐가 달라. 넓혀 달랬잖아요.

**P04 | 탁두철 [S_CH01_02_0017]**

넓힌 건 맞고, 어느 쪽을 손님 쪽으로 썼는지를 자꾸 반대로 부르시잖아요.

*만실은 북쪽 창 쪽을 보다가 목소리를 조금 높인다.*

**P02 | 봉만실 [S_Q01_v1]**

무록 씨는 그 방에 계속 있었어요. 창으로 제가 봤다니까요.

*두철이 입을 열려다가 닫는다. 그는 칸막이 문제와 사람 문제를 한꺼번에 답하지 않는다.*

**P04 | 탁두철 [S_CH01_02_0018]**

제가 말할 수 있는 건 벽 움직인 것까지입니다. 누가 거기 계속 있었는지는 제가 못 봤어요.

**P00 | 나여백 [S_CH01_02_0019]**

그럼 두 가지를 나누겠습니다. 먼저 창이 어느 공간을 비추는지, 다음으로 봉 선생님이 창에서 실제로 무엇을 확인했는지.

**P01 | 나모눈 [S_CH01_02_0020]**

창이 방 이름을 바꿔 부를 수도 있어?

**P00 | 나여백 [S_CH01_02_0021]**

창은 그대로일 거야. 우리가 어느 쪽을 방이라고 부르는지가 바뀌었는지 보자.

> **현재 목표:** `창가의 목격이 무엇을 증명하는지 확인하자.`

*두철은 바퀴 덮개를 임시로 닫고 안전선 밖으로 나온다.*

**P04 | 탁두철 [S_CH01_02_0022]**

경찰이 허락하면 6하고 9를 한 번씩 보여드릴 수는 있어요. 제가 밀고 봉 사장님이 반대쪽 잡는 방식으로. 아이는 선 밖에 있어야 하고요.

**P02 | 봉만실 [S_CH01_02_0023]**

좋아요. 대신 벽을 움직였다고 어젯밤까지 다시 움직이는 건 아니에요. 시험은 시험이라고 써요.

**P00 | 나여백 [S_CH01_02_0024]**

네. 어젯밤 기록하고 오늘 시험 상태를 따로 적겠습니다.

### Optional early evidence — 행사 사진첩 E10

*첫째 장에서 언제든 만실에게 어젯밤 공개 행사 사진을 요청할 수 있다. 이미 행사 사진을 획득했다면 아래 장면은 반복하지 않고 사진 열람으로 바로 간다.*

**P00 | 나여백 [S_CH01_02_0031]**

어젯밤 제가 같이 있던 공개 점검 사진도 남아 있습니까?

**P02 | 봉만실 [S_CH01_02_0032]**

즉석 사진 몇 장 있어요. 행사 끝나기 전에 앨범에 끼워 놨어요. 시간 찍히는 카메라는 아니고요.

*만실이 휴게실에 둔 작은 사진첩을 가져온다. 한 장에는 서비스 접속부 쪽 입구 가까이에 붉은 코트를 입은 차무록이 서 있고, 왼쪽 옷깃의 삼각형 수선 자국이 보인다. 사진 앞쪽에는 여백이 들고 있던 번호표가 일부 들어와 있다. 뒷면에는 만실의 글씨로 `점검 시작 전`이라고 적혀 있다.*

#### E10 — 행사 사진

> 차무록이 서비스 접속부 쪽 입구에 붉은 코트를 입고 서 있다.
> 왼쪽 옷깃의 삼각형 수선은 온전하다.
> 전경에는 여백이 들고 있던 공개 점검 번호표가 보인다.
> 뒷면: `점검 시작 전` — 봉만실 필기. 카메라 자체 시각표시는 아니다.

**P00 | 나여백 [S_CH01_02_0033]**

이 사진을 찍을 때 저는 번호표를 들고 있었고, 봉 선생님은 제 옆에서 점검을 준비하고 있었습니다. 그 장면은 제가 직접 봤어요.

**P02 | 봉만실 [S_CH01_02_0034]**

맞아요. 무록 씨가 지나가는 게 보여서 한 장 찍었고, 바로 다시 점검 준비했어요. 사진이 정확히 몇 시 몇 분인지는 사진만 보고 말하지 맙시다.

**P00 | 나여백 [S_CH01_02_0035]**

네. 제가 직접 겪은 공개 점검 순서와 같이 볼 때만 그 구간을 말하겠습니다.

*행사 사진과 여백의 공개 점검 관찰 기록을 함께 가진 경우 목격 정정을 먼저 시도할 수 있다. 이 경로로 정정을 먼저 얻어도 공간 구조와 칸막이 작업 문제는 별도로 남는다.*

### Current revisit / interrupted resume

**P04 | 탁두철 [S_CH01_02_0091]**

바닥 표식은 그대로 있습니다. 다시 보실 거면 선 밖에서 보세요. 바퀴를 다시 움직이는 건 허락 받고요.

**P02 | 봉만실 [S_CH01_02_0092]**

사진첩은 휴게실에 둬요. 이미 본 사진은 새 사진처럼 다시 생기지 않아요.

**P00 | 나여백 [S_CH01_02_0093]**

중간에 나갔다 돌아와도 칸막이 작업표와 두 정지선은 이미 확인한 기록에서 이어 보겠습니다.

*행사 사진을 펼친 상태에서 중단했다면 같은 사진과 같은 뒷면 메모에서 재개한다. 사진 획득 효과를 다시 실행하거나 새 촬영 시각을 만들어 내지 않는다.*

**P00 | 나여백 [S_CH01_02_0094]**

사진 열람이 끊겼다면 방금 보던 장부터 이어서 봐요. 제가 직접 본 공개 점검 맥락도 그대로이고, 새 사실이 생긴 건 아닙니다.

---

## C_D01 — 북쪽 창은 어느 쪽 공간을 비췄을까?

### Context
- Place: L03, at the measured ballroom plan/work area; P04 available nearby, P01 remains with P00 inside the public safety boundary.
- Cast: P00; P01/P04 respond when present. P02 may remain nearby but is not required for the judgment.
- Entry: standard after C_CH01_02 with E03/E05; early incomplete attempt allowed if either source is missing. Q01 may already have been corrected via E10/E18, but D01 remains a geometry question.
- Exit: success creates K01 only; it does not date the wall move or correct P02's testimony.
- E/S/K/B: uses E03/E05; branches B_D01_incomplete, B_D01_err_moving_window_or_door, B_D01_success, B_D01_retry; success → K01.
- Effects: no physical wall movement.
- Repeat/resume: editable diagram survives incomplete/wrong submissions and zero-point recovery; revisit uses K01 without resubmitting.

### Task setup

**P00 | 나여백 [S_D01_0001]**

창과 두 문은 고정이고 칸막이만 두 정지선 사이를 움직입니다. 공개 안내도의 방향과 현장 실측을 겹쳐, 북쪽 창이 각 배치에서 어느 쪽 공간에 들어가는지 먼저 정하겠습니다.

> **D01:** `북쪽 창은 어느 쪽 공간을 비췄을까?`

### Free clarification

**P01 | 나모눈 [S_D01_0002]**

창에서 보이는 걸 맞히는 거야, 아니면 창이 어느 방에 붙는지 맞히는 거야?

**P00 | 나여백 [S_D01_0003]**

지금은 두 번째. 사람은 아직 빼고, 고정된 창 좌표와 칸막이 위치만 보자.

### B_D01_incomplete

*행사장 안내도 또는 두 정지선이 없거나, 선택한 그림에 x6/x9 중 한 상태가 비어 있으면 제출되지 않는다.*

**P00 | 나여백 [S_D01_0011]**

아직 한쪽 상태가 비어 있어요. 틀렸다고 처리할 문제가 아니라, 실제 정지선과 공개 안내도를 둘 다 확인한 뒤 다시 그리겠습니다.

*여유 변화 없음. 편집 중인 도식은 그대로 남는다.*

### B_D01_err_moving_window_or_door

**P00 | 나여백 [S_D01_0021]**

제가 지금 고른 설명은 `칸막이가 움직일 때 창이나 문도 같이 옮겨졌다`는 전제예요.

**P04 | 탁두철 [S_D01_0022]**

그건 아닙니다. 저 벽만 레일 위에서 움직여요. 창은 외벽에 박혀 있고, 문도 벽체에 그대로 있어요. 문까지 움직였으면 저는 바퀴가 아니라 건물을 고치고 있었겠죠.

**P00 | 나여백 [S_D01_0023]**

고정된 좌표를 움직인 걸로 잡았네요. 창과 문은 고정하고, 칸막이 6과 9만 다시 놓겠습니다.

> 완결된 잘못된 전제로 제출했으므로 여유 `-2`. 작업 도식은 유지된다.

### B_D01_success — selected claim

**P00 | 나여백 [S_D01_0031]**

서쪽 벽을 기준으로 북쪽 창 중심은 7미터에 고정돼 있고, 칸막이는 6미터나 9미터 정지선에 섭니다. 6미터에 서면 창은 칸막이 동쪽 작업실 쪽이고, 9미터에 서면 창은 칸막이 서쪽 공개 공간 쪽입니다.

**P04 | 탁두철 [S_D01_0032]**

네. 벽이 창을 지나가니까 방 이름이 바뀌어 보이는 거지, 창이 움직이는 게 아닙니다.

**P00 | 나여백 [S_D01_0033]**

그럼 `창가`라는 말만으로 작업실인지 공개 공간인지 정하면 안 되겠네요. 어느 정지선이었는지가 같이 있어야 합니다.

- Author state: **K01 획득:** x6에서는 북쪽 창이 동쪽 작업실, x9에서는 서쪽 공개 공간에 속한다.

### B_D01_retry

**P00 | 나여백 [S_D01_0041]**

아까 그린 선은 남겨 둘게요. 창과 문을 고정한 상태에서 칸막이만 다시 옮겨 보겠습니다.

**P04 | 탁두철 [S_D01_0042]**

그렇게 보면 됩니다. 바퀴는 아직 안 움직여도 그림으로 충분해요.

### Current revisit

**P00 | 나여백 [S_D01_0091]**

북쪽 창과 칸막이 위치 결론은 창의 위치와 칸막이 상태를 분류한 결과예요. 어젯밤 실제로 언제 벽을 옮겼는지는 아직 칸막이 작업표와 별도로 봐야 합니다.

---

## C_H_D01 — D01 힌트

### Context
- Place/cast: wherever P00 can review the investigation notebook; no NPC is summoned by the hint.
- Entry: D01 unresolved or revisited. State selector uses held E03/E05, recent D01 error, or K01-complete state.
- Exit/effects: hints never acquire evidence, move the partition, spend 여유, or create K01.
- E/S/K/B: may reference only E03/E05 already held; missing-state text points to P02's public plan or P04's measured stops without revealing unseen contents.
- Repeat/resume: the same H level selects the wording matching current held/missing/recent-error state.

#### Deterministic selector (normative)
- Return **one Korean utterance only** for a hint request; never concatenate overlays.
- Priority: `K01 complete` → `missing prerequisite` → `recent named error (H3/H4 only)` → `requested held-source level`. Interruption keeps the same held/missing state and does not outrank it.
- `K01 complete`, any requested H0–H4 → `S_H_D01_0043`.
- E05 missing, any H0–H4 → `S_H_D01_0001`; else E03 missing, any H0–H4 → `S_H_D01_0002`. These acquisition lines intentionally reveal no x7/x6/x9 answer.
- All held: H0 `S_H_D01_0003`; H1 `S_H_D01_0011`; H2 `S_H_D01_0021`; H3 `S_H_D01_0032`; H4 `S_H_D01_0042`.
- With all sources held and recent `moving_window_or_door`, H3/H4 → `S_H_D01_0033`; H0–H2 still use their requested-level held-source line.

### H_D01_0

**If E05 missing**

**P00 | 나여백 [S_H_D01_0001]**

공개 안내도만으로는 실제 칸막이 정지 위치를 잴 수 없어요. 연회장에서 두철 씨가 보여 준 바닥의 두 정지선과 고정된 창·문 위치를 먼저 확인합시다.

**If E03 missing**

**P00 | 나여백 [S_H_D01_0002]**

현장 치수만 보지 말고, 봉만실 선생님이 처음 준 공개 행사장 안내도에서 북쪽과 출입문 이름을 다시 확인해요.

**If all held**

**P00 | 나여백 [S_H_D01_0003]**

재료는 다 있어요. 사람이나 목격은 빼고, `창 고정 + 문 고정 + 칸막이만 6/9`로 두 장을 겹쳐 봅시다.

### H_D01_1

**If E03/E05 both held**

**P00 | 나여백 [S_H_D01_0011]**

구분되는 건 창이 움직이는지가 아니라 칸막이가 고정 창의 서쪽에 서는지 동쪽에 서는지예요. 실측 그림에서 창 중심 7미터와 두 정지선 6·9미터를 차례로 놓아 보세요.

### H_D01_2

**If both E03/E05 held**

**P00 | 나여백 [S_H_D01_0021]**

행사장 안내도는 북쪽 방향과 출입문 이름을 알려 주고, 두 정지선은 실제로 `6`, `9` 정지선과 고정 창 위치를 보여 줍니다. 약도의 길이는 비율이 아니니 두 정지선의 실측을 우선해요.

**If only one held**

**P00 | 나여백 [S_H_D01_0022]**

지금 가진 자료 하나만으로는 두 상태를 확정하기 어렵습니다. 없는 쪽이 안내도면 봉 선생님에게, 정지선이면 연회장의 두철 씨에게 돌아가 확인합시다.

### H_D01_3

**If required source missing**

**P00 | 나여백 [S_H_D01_0031]**

행사장 안내도가 없으면 봉 선생님의 공개 안내도부터, 두 정지선이 없으면 연회장 바닥 정지선부터 확인하세요. 둘을 갖춘 다음에는 `창이 다른 방을 비췄다`고 해서 창이 움직였다고 생각하지 말고, 고정 창을 칸막이가 어느 쪽에 포함시키는지만 비교합니다.

**If all held**

**P00 | 나여백 [S_H_D01_0032]**

고정된 x7 창을 두고 칸막이만 x6과 x9에 세우세요. 어느 경우에 창이 동쪽/서쪽에 놓이는지 보면 됩니다.

**Recent error: moving_window_or_door**

**P00 | 나여백 [S_H_D01_0033]**

방금 틀린 전제는 창이나 문까지 이동했다는 부분이었어요. 그 둘을 제자리에 고정하고, 세로 칸막이만 x6과 x9에 번갈아 세워 보세요.

### H_D01_4

**If required source missing**

**P00 | 나여백 [S_H_D01_0041]**

지금은 정답 문장을 먼저 채우지 않습니다. 행사장 안내도가 없으면 봉 선생님에게 공개 안내도를 다시 보고, 두 정지선 실측이 없으면 연회장에서 두철 씨와 바닥의 `6`·`9` 표시와 고정 창·문 위치를 먼저 확인하세요. 필요한 두 자료가 모두 생긴 뒤 같은 단계의 힌트를 다시 요청하면 완성 문장으로 이어갑니다.

**If all held**

**P00 | 나여백 [S_H_D01_0042]**

이렇게 정리하면 됩니다. `북쪽 창은 x7에 고정이다. 칸막이가 x6이면 창은 동쪽 작업실에 포함되고, x9이면 창은 서쪽 공개 공간에 포함된다. 행사장 안내도의 방향 정보와 두 정지선의 실측 위치가 그 구분을 뒷받침한다.`

**If K01 already acquired**

**P00 | 나여백 [S_H_D01_0043]**

북쪽 창과 칸막이의 관계는 이미 확인했습니다. 같은 걸 다시 따지지 말고, 이제 어젯밤 칸막이가 실제로 언제 누구 손으로 옮겨졌는지 작업 이력을 보세요.

---

## C_CH01_03 — 창밖에서 본 높이

### Context
- Place: entry handoff in L02, then L04 north viewing walk.
- Cast: L04 core cast P00/P02/P07. P01 remains physically in L02 with P03 after an explicit same-place handoff; P03 pauses reception paperwork there until P00 returns.
- Entry: K01 after D01; E05 has already fixed the measured geometry. P07 authorizes a neutral sightline inspection, not a reenactment of the fall or culprit action.
- Exit: acquire E06/E07. Q01 becomes solvable by E06/E07+K02 once K02 exists, or may already be corrected through E10/E18.
- E/S/K/B: acquire E06/E07 only; no E08/KQ01 unless C_Q01 succeeds.
- Effects: fixed desk lamp remains at the window/chair; portable maintenance light is not used in this test. P01 never enters L04.
- Repeat/resume: completed frames are retained; interruption resumes at the next unrecorded frame or unopened recovery-photo envelope.

### Script

*북쪽 보행로로 나가기 전, 여백은 모눈을 데리고 휴게실로 돌아온다. 차무록은 접수 서류 한 묶음을 들고 휴게실 탁자에 앉는다. 여백이 돌아올 때까지 이 방을 비우지 않기로 한 상태다.*

**P00 | 나여백 [S_CH01_03_0031]**

모눈아, 이번 확인은 바깥 보행로라서 너는 여기 남아 있어. 차 선생님이 이 방에서 같이 있어 주실 거야.

**P03 | 차무록 [S_CH01_03_0032]**

제가 여기서 서류 보겠습니다. 접수대에 갈 일이 생겨도 혼자 두고 가지 않고, 먼저 연락하죠.

**P01 | 나모눈 [S_CH01_03_0033]**

알겠어. 나도 밖에 안 나가고 분실물 표만 정리할게.

*여백은 모눈의 물과 가방을 같은 탁자 곁에 둔 것을 확인하고 봉만실·진새벽과 함께 이동한다. 진새벽은 현관·접수대에서 여백의 요청을 듣고 짧은 질문 카드를 한 장 쓴다. `창밖에서 실제로 무엇까지 보이는가`. 카드를 주머니에 넣으려다 다른 카드 밑에 끼워 넣고는, 결국 찾지 못한 채 말로 다시 확인한다.*

**P07 | 진새벽 [S_CH01_03_0001]**

오늘 확인하는 건 시야입니다. 어젯밤 일을 재연하는 게 아니라, 현재 빈 방에서 보이는 범위를 시험합니다. 사람의 행동을 연기하지 않습니다.

**P00 | 나여백 [S_CH01_03_0002]**

모눈이는 휴게실에 남겼습니다. 차무록 씨가 같은 방에서 서류를 보면서 제가 돌아올 때까지 함께 있기로 했어요.

**P07 | 진새벽 [S_CH01_03_0003]**

확인했습니다. 그럼 세 분만 북쪽 보행로로 가죠.

*여백과 만실, 새벽은 연회장 손님 출입문으로 나와 바깥을 돌아 북쪽 관람 통로로 걷는다. 창은 방 바깥에서 허리보다 조금 높은 위치에 있고, 아래쪽은 반투명 처리되어 있다. 창가의 고정 책상등은 어젯밤과 같은 책상 자리에 남아 있다. 서비스 문 쪽에 보관하던 이동식 작업등은 이 시험에 가져오지 않았다.*

**P02 | 봉만실 [S_CH01_03_0004]**

내가 어젯밤 본 것도 여기서예요. 안으로 들어가진 않았어요.

**P07 | 진새벽 [S_CH01_03_0005]**

좋습니다. 먼저 빈 의자만 둔 상태, 다음에는 재킷을 걸친 상태, 그다음 성인이 앉고 서는 상태를 따로 봅니다. 각 장면 사이에 제가 안쪽 배치를 확인하겠습니다.

*첫 시험에서는 높은 의자에 파란 재킷만 걸고 한쪽 소매가 반투명 창 위로 올라오게 둔다. 두 번째에는 성인 한 명이 평소처럼 앉는다. 고정 책상등 몸체와 갓이 얼굴 높이를 가린다. 세 번째에는 같은 성인이 일어서서 어깨와 머리 높이 차이를 확인한다.*

**P00 | 나여백 [S_CH01_03_0006]**

재킷만 걸어도 위쪽에는 소매가 보입니다. 사람이 앉으면 얼굴 높이는 고정 책상등에 가리고, 일어서면 어깨와 머리 위치가 달라지네요.

**P07 | 진새벽 [S_CH01_03_0007]**

그 차이를 사진 세 장으로 남기겠습니다. 전부 오늘 시험이라고 표시합니다.

#### E06 — 북쪽 창 시야

> 오늘 실시한 중립 시험 사진 3종.
> 1) 빈 의자 + 재킷 소매가 반투명 창 위로 보임
> 2) 성인 착석 — 창가 고정 책상등이 얼굴 높이를 가림
> 3) 성인 기립 — 어깨/머리 높이가 달라짐
> 창 아래 반투명부 높이 약 1.25m.
> **제한:** 사람 식별 증거가 아니라, 짧은 목격이 얼마나 모호할 수 있는지 보여 주는 시험.

*시험이 끝나자 새벽이 별도 봉투에서 사건 당시 촬영된 회수 사진 한 장을 꺼낸다. 사진에는 높은 의자 등받이에 파란 재킷이 걸려 있고, 한쪽 소매가 창 쪽으로 올라와 있다. 주머니에서 발견된 수선 접수표에는 차무록의 이름이 적혀 있다.*

**P00 | 나여백 [S_CH01_03_0008]**

이게 어젯밤 발견 당시 상태입니까?

**P07 | 진새벽 [S_CH01_03_0009]**

네. 의자와 재킷은 현장 기록이 끝난 뒤 따로 보관했습니다. 주머니 표는 재킷 소유자를 연결하지만, 재킷이 걸려 있던 동안 그 사람이 계속 옆에 있었다는 뜻은 아닙니다.

#### E07 — 의자에 걸린 재킷

> 높은 의자에 파란 재킷이 걸려 있고 한쪽 소매가 창 위로 보이는 회수 사진.
> 재킷 주머니: 차무록 이름이 적힌 수선 접수표.
> **제한:** 재킷 소유자를 연결하지만 계속 재실을 증명하지 않는다.

### If Q01 is unresolved at this point

**P02 | 봉만실 [S_CH01_03_0010]**

저렇게 놓으면 비슷해 보이는 건 알겠어요. 그런데 나는 어젯밤 두 번이나 봤어요. 한 번 잘못 본 걸로 끝난 게 아니라고요.

**P00 | 나여백 [S_CH01_03_0011]**

그래서 아직 결론을 붙이지 않겠습니다. 두 번 봤다는 사실과, 두 번 모두 같은 사람을 확인했다는 주장은 나눠 볼게요.

*만실은 창을 다시 본다. 새벽은 시험 사진에 `10/22 재현시험`이라고 크게 적는다.*

**P07 | 진새벽 [S_CH01_03_0012]**

그리고 오늘 시험이 어젯밤 상태였다고 바꾸어 적지 않습니다. 어젯밤 칸막이 이동 기록은 별도로 확인하세요.

**P00 | 나여백 [S_CH01_03_0013]**

다음은 칸막이 작업표가 말하는 이동과 실제 정지선이 맞는지 보겠습니다.

**P07 | 진새벽 [S_CH01_03_0014]**

행사 전 칸막이 이동 결론까지 확인되면 칸막이는 두철 씨와 봉만실 씨가 안전선 안에서 한 번 시험해도 됩니다. x9에서 x6, 다시 x9까지만. 모눈이는 선 밖에 두고, 오늘 시험이라고 표시하세요.

### If Q01 was already corrected early via E10/E18

**P02 | 봉만실 [S_CH01_03_0021]**

사진 때문에 내가 `계속 있었다`는 말은 이미 고쳤어요. 그래도 이 시험은 해 둬야겠네요. 내가 뭘 사람으로 봤는지 확인하는 건 별개니까.

**P00 | 나여백 [S_CH01_03_0022]**

네. 이미 고친 진술을 다시 틀렸다고 만들지는 않겠습니다. 오늘 시험은 시야의 범위를 기록하는 겁니다.

### Current revisit / interrupted acquisition

**P07 | 진새벽 [S_CH01_03_0091]**

북쪽 창 시야는 오늘 시험, 의자에 걸린 재킷은 어젯밤 회수 기록입니다. 둘을 같은 사진처럼 합치지 마세요.

**P00 | 나여백 [S_CH01_03_0092]**

창밖에서 보이는 모양을 확인했어도, 어젯밤 벽이 언제 어느 정지선에 있었는지는 작업표와 당시 설명으로 따로 확인해야 합니다.

*북쪽 창 시야 세 시험 프레임 도중 중단했다면 완료한 프레임은 다시 만들지 않고 다음 미완료 프레임에서 재개한다. 의자에 걸린 재킷 봉투를 열기 전 중단했다면 봉투는 그대로 진새벽 보관 상태다.*

**P07 | 진새벽 [S_CH01_03_0093]**

시험 두 장까지 끝났다면 세 번째부터 이어갑니다. 이미 찍은 장면을 다시 어젯밤처럼 연기할 이유는 없습니다.

**P07 | 진새벽 [S_CH01_03_0094]**

회수 사진을 아직 확인하지 않았다면 그 봉투부터 이어서 보죠. 확인했다면 새 증거처럼 다시 열지 않습니다.

---

## C_D02 — 그날 실제로 바뀐 것은 무엇일까?

### Context
- Place: L03 beside the partition work area.
- Cast: P00, P04, P02; P01 may remain with P00 behind the public safety line when the scene is entered from L03.
- Entry: K01 + E04/E05. Q01 may already be corrected through E10/E18; that does not waive this work-history question.
- Exit: success → K02 and makes V01 joinable. It does not create any new incident-time wall movement.
- E/S/K/B: uses E04/E05/K01 and P04's free explanation; branches B_D02_incomplete, both named error branches, success, retry.
- Effects: no physical wall movement inside the task scene.
- Repeat/resume: editable claim survives incomplete/wrong attempts and recovery; revisit uses K02 without replaying work testimony.

### Task setup

**P00 | 나여백 [S_D02_0001]**

정지선이 둘 있다는 것과 어젯밤 실제로 어느 시각에 어느 쪽으로 옮겼다는 건 다른 문제예요. 작업표, 바닥 상태, 두 분의 설명을 맞춰 보겠습니다.

> **D02:** `그날 실제로 바뀐 것은 무엇일까?`

### Free P04 explanation

**P04 | 탁두철 [S_D02_0002]**

시작할 때는 6 쪽에 있었습니다. 행사 전에 봉 사장님하고 같이 밀어서 9에 잠그고, 끝난 뒤에는 그대로 뒀어요. 이 바닥 자국은 그 이동과 맞지만 자국만 보고 `19:40`이라고 읽을 수는 없습니다.

**P02 | 봉만실 [S_D02_0003]**

내가 반대쪽 잡고 민 것도 맞아요. 손님 자리 넓히려고요.

### B_D02_incomplete

*칸막이 작업표/두 정지선/북쪽 창과 칸막이 위치 결론 중 하나가 없거나, 실제 이동과 오늘 재현시험을 섞은 채 제출하려 하면 무료로 멈춘다.*

**P00 | 나여백 [S_D02_0011]**

지금은 `움직일 수 있다`와 `어젯밤 그렇게 움직였다`가 섞여 있어요. 방 구조에 대한 결론, 작업표의 시각·참여자, 바닥의 두 정지선을 나눠 놓고 다시 적겠습니다.

*여유 변화 없음. 작성 중인 주장은 유지된다.*

### B_D02_err_fresh_track_dates_exact_move

**P00 | 나여백 [S_D02_0021]**

바닥 자국이 새로 보이니까, 그 자국 자체가 19시 40분부터 46분 사이의 이동 시각을 증명한다고 보겠습니다.

**P04 | 탁두철 [S_D02_0022]**

자국에 시계는 없습니다. 최근에 움직였다는 건 보여도 몇 시인지는 작업표하고 당시 같이 민 사람 설명을 봐야 해요.

**P00 | 나여백 [S_D02_0023]**

물리 흔적에 시간을 붙여 버렸네요. 자국은 이동 가능성과 실제 상태를 보강하고, 시각은 칸막이 작업표와 당시 참여 설명에서 가져오겠습니다.

> 완결된 잘못된 전제로 제출했으므로 여유 `-2`.

### B_D02_err_culprit_moved_alone

**P00 | 나여백 [S_D02_0031]**

사건을 만들기 위해 누군가 혼자 몰래 칸막이를 옮겼다고 정리하겠습니다.

**P02 | 봉만실 [S_D02_0032]**

아니요. 적어도 행사 전에 9로 옮긴 건 나도 같이 했어요. 그걸 숨길 이유가 없어요.

**P04 | 탁두철 [S_D02_0033]**

그리고 저 벽은 혼자 못 민다는 뜻이 아니라, 어젯밤 기록된 그 이동이 혼자 한 일이 아니라는 뜻입니다. 범인을 먼저 넣지 마세요.

**P00 | 나여백 [S_D02_0034]**

맞습니다. 지금 증명할 건 작업 이력이지 범인 행동이 아니네요.

> 완결된 잘못된 전제로 제출했으므로 여유 `-2`.

### B_D02_success — selected claim

**P00 | 나여백 [S_D02_0041]**

어젯밤 19시 40분부터 46분 사이, 두철 씨가 작업하고 봉 선생님이 보조·확인해서 칸막이를 정지선 9로 옮겼습니다. 칸막이 작업표가 그 작업을 당시 기록했고, 두 정지선의 두 정지선과 현재 물리 상태가 그 설명과 맞습니다. 이건 행사 준비 전에 끝난 이동이지, 사건 중에 누군가 몰래 벽을 바꿨다는 근거가 아닙니다.

**P04 | 탁두철 [S_D02_0042]**

그게 제가 한 일입니다. 오늘 다시 움직이는 건 시험이고, 어젯밤 작업하고는 따로 적어 주세요.

**P02 | 봉만실 [S_D02_0043]**

나도 같이 밀었다는 건 맞아요. 내가 어느 쪽을 무슨 방이라고 불렀는지는 또 따져야겠지만.

**P00 | 나여백 [S_D02_0044]**

그럼 두 목격 때 칸막이는 이미 9미터 정지선에 있던 상태로 놓고 봐야 합니다.

- Author state: **K02 획득:** P04/P02는 행사 전 19:40–19:46 칸막이를 x9로 옮겼고, 두 목격 사이에 몰래 바꾼 벽이 아니다.
- Author state: **V01 사용 가능:** P07이 승인한 현재 재현시험을 L03에서 명시적으로 시작할 수 있다.

### B_D02_retry

**P00 | 나여백 [S_D02_0051]**

작성 중인 주장은 그대로 두고, `물리 흔적이 말하는 것`과 `작업표가 말하는 시각`을 나눠 고치겠습니다.

**P04 | 탁두철 [S_D02_0052]**

그렇게 하세요. 벽은 둘 다 보여 주지만, 자국이 달력을 읽진 않습니다.

### Current revisit

**P00 | 나여백 [S_D02_0091]**

행사 전 칸막이 이동 결론은 어젯밤 행사 전 이동을 확정한 겁니다. 오늘 칸막이 재현에서 벽을 다시 움직여도 그 시험이 새로운 어젯밤 이력이 되지는 않습니다.

---

## C_H_D02 — D02 힌트

### Context
- Place/cast: P00's investigation notebook; no absent NPC is summoned.
- Entry: D02 unresolved/revisited. Selector uses K01, held E04/E05, recent named error, and K02-complete state.
- Exit/effects: no evidence acquisition, wall movement, K gain or 여유 cost.
- E/S/K/B: may name E04/E05 only when held; missing text points to the actual person/place that can supply the source.
- Repeat/resume: interrupted answer drafting resumes with the same draft and most recent error state.

#### Deterministic selector (normative)
- Return one utterance only. Priority: `K02 complete` → `missing prerequisite` → `recent named error at H3/H4` → `requested held-source level`; interruption preserves the same selector state.
- `K02 complete`, any H0–H4 → `S_H_D02_0043`.
- K01 missing → `S_H_D02_0001`; else E04 missing → `S_H_D02_0002`; else E05 missing → `S_H_D02_0003`, regardless of requested H level.
- All held: H0 `S_H_D02_0004`; H1 `S_H_D02_0011`; H2 `S_H_D02_0021`; H3 `S_H_D02_0032`; H4 `S_H_D02_0042`.
- With all prerequisites held, recent `fresh_track_dates_exact_move` at H3/H4 → `S_H_D02_0033`; recent `culprit_moved_alone` at H3/H4 → `S_H_D02_0034`.

### H_D02_0

**If K01 missing**

**P00 | 나여백 [S_H_D02_0001]**

먼저 창과 칸막이의 위치 관계부터 정해야 합니다. 벽이 6미터와 9미터 정지선에서 어떤 공간을 만드는지 모르면 작업표의 `정지선 9` 의미도 흐려져요.

**If E04 missing**

**P00 | 나여백 [S_H_D02_0002]**

두철 씨에게 칸막이 잠금쇠에 붙어 있던 작업표를 다시 보여 달라고 하세요. 이동 시각과 참여자가 적힌 당시 기록이 필요합니다.

**If E05 missing**

**P00 | 나여백 [S_H_D02_0003]**

연회장 바닥의 `6`과 `9` 정지선, 그리고 그 사이 바퀴 자국을 먼저 확인합시다. 작업표만으로 물리 상태까지 대신 증명하지는 않아요.

**If all held**

**P00 | 나여백 [S_H_D02_0004]**

재료는 다 있습니다. `언제/누가 옮겼는가`는 칸막이 작업표와 당시 설명으로, `그 이동이 가능한 실제 구조인가`는 두 정지선과 북쪽 창과 칸막이 위치 결론으로 나누세요.

### H_D02_1

**If K01/E04/E05 all held**

**P00 | 나여백 [S_H_D02_0011]**

핵심 차이는 `움직일 수 있다`와 `그때 움직였다`입니다. 바닥에는 두 위치가 가능하다는 흔적이 있고, 작업표에는 행사 전 실제 작업이 적혀 있습니다.

### H_D02_2

**If E04/E05 held**

**P00 | 나여백 [S_H_D02_0021]**

칸막이 작업표에는 `10/21 19:40 시작 · 19:46 종료 / 정지선 9 / 작업 탁두철 / 보조·확인 봉만실`이 적혀 있고, 두 정지선에는 6과 9의 물리 정지선이 있습니다. 둘은 서로 다른 역할입니다.

**If one is missing**

**P00 | 나여백 [S_H_D02_0022]**

지금 가진 쪽만 이름 붙여 봅시다. 칸막이 작업표가 없으면 두철 씨의 작업표를, 두 정지선이 없으면 연회장 바닥 정지선을 확인해야 합니다. 모르는 자료의 내용을 미리 채우지는 않겠습니다.

### H_D02_3

**If prerequisite missing**

**P00 | 나여백 [S_H_D02_0031]**

북쪽 창과 칸막이 관계가 아직 불분명하면 그 구조부터 확인하고, 작업표나 바닥 정지선을 아직 안 봤다면 연회장에서 직접 확인하세요. 다 갖춘 뒤에는 새 바퀴 자국을 정확한 시계처럼 쓰거나, 사건이 있다는 이유만으로 `범인이 혼자 옮겼다`고 붙이지 않습니다.

**If all held**

**P00 | 나여백 [S_H_D02_0032]**

행사 전 정상 작업으로 설명되는 이동부터 고정하세요. 시각/참여자는 칸막이 작업표와 당사자 설명, 가능한 정지 위치는 두 정지선/북쪽 창과 칸막이 위치 결론이 맡습니다.

**Recent error: fresh_track_dates_exact_move**

**P00 | 나여백 [S_H_D02_0033]**

방금은 바닥 자국에 시각을 너무 많이 맡겼어요. 시각은 칸막이 작업표, 물리적으로 두 위치가 있다는 건 두 정지선으로 역할을 나누면 됩니다.

**Recent error: culprit_moved_alone**

**P00 | 나여백 [S_H_D02_0034]**

방금은 `사건이 있다`를 `범인이 벽을 옮겼다`로 건너뛰었습니다. 탁두철/봉만실이 함께 한 행사 전 이동을 먼저 사실로 고정하세요.

### H_D02_4

**If prerequisite missing**

**P00 | 나여백 [S_H_D02_0041]**

비어 있는 근거부터 채우세요. 창과 칸막이 관계가 없으면 그 구조 질문으로 돌아가고, 작업표가 없으면 두철 씨에게 잠금쇠에 붙은 기록을 요청하고, 바닥 실측이 없으면 연회장의 `6`·`9` 정지선을 확인합니다. 아직 보지 않은 시각·참여자·결론을 이 힌트가 대신 말하지 않습니다.

**If all held**

**P00 | 나여백 [S_H_D02_0042]**

완성된 주장은 이렇게 쓸 수 있습니다. `19:40–19:46 탁두철이 작업하고 봉만실이 보조·확인하여 칸막이를 x9로 옮겼다. 칸막이 작업표가 당시 작업을 기록하고 두 정지선이 그 정지 위치와 구조가 실제임을 뒷받침한다. 따라서 두 목격 사이의 비밀 이동으로 볼 근거는 없다.`

**If K02 already acquired**

**P00 | 나여백 [S_H_D02_0043]**

칸막이 이동에 대한 추론은 이미 끝났습니다. 같은 결론을 다시 만들지 말고, 칸막이 재현이나 현재 열려 있는 만실 씨 목격 진술 추궁으로 이어가세요.

---

## C_CH01_04 — 오늘 움직인 벽

### Context
- Place: handback in L02, then L03.
- Cast: L03 core P00/P01/P04/P02. P03 appears only for the explicit L02 supervision handback before P00 resumes responsibility for P01.
- Entry: K02. P00/P02 return from L04 to L02 first; P03 hands P01 back. P07's prior authorization covers a neutral x9→x6→x9 partition test. No task submission is active.
- Exit: V01 completes and actual current configuration is restored to x9. If Q01 is unresolved, either valid route remains; if corrected early, no second correction occurs.
- E/S/K/B: no new E/K. Test images are experiment records, not new historical evidence.
- Effects: adults P04/P02 move the partition; P01 remains behind the safety line under P00's direct supervision.
- Repeat/resume: if interrupted at x6, resume there and restore x9; completed movement/photos are not duplicated.

### Script

*북쪽 보행로 확인을 마친 여백과 만실이 먼저 휴게실로 돌아온다. 차무록은 처음 약속한 대로 모눈과 같은 탁자에 앉아 접수 서류를 보고 있다.*

**P03 | 차무록 [S_CH01_04_0025]**

돌아오셨군요. 모눈이는 계속 여기 있었습니다. 저는 접수 서류만 들고 들어와서 봤고요.

**P00 | 나여백 [S_CH01_04_0026]**

고맙습니다. 이제 제가 다시 같이 있겠습니다. 모눈아, 다음은 연회장 안전선 밖에서 보기만 하는 시험이야.

**P01 | 나모눈 [S_CH01_04_0027]**

응. 이번에는 같이 가되 선은 안 넘을게.

*세 사람은 연회장으로 이동한다. 노란 안전선은 칸막이에서 충분히 떨어진 위치에 다시 붙어 있다. 모눈은 선 바깥, 휴게실 쪽과 이어지는 손님 출입문 가까이에 서 있다. 여백은 모눈이 선을 넘지 않는 것을 확인한 뒤 두철과 만실 쪽으로 간다.*

**P00 | 나여백 [S_CH01_04_0001]**

지금부터 하는 건 10월 22일 재현시험입니다. 어젯밤 기록을 다시 만드는 게 아니라, x9와 x6에서 보이는 공간을 비교하겠습니다.

**P01 | 나모눈 [S_CH01_04_0002]**

나는 선 밖. 벽 안 밀기. 의자도 안 타기.

**P04 | 탁두철 [S_CH01_04_0003]**

좋습니다. 오늘 제일 말을 잘 듣는 건 사람 쪽이네요.

**P02 | 봉만실 [S_CH01_04_0004]**

벽한테 들리게 말하지 마요. 또 삐집니다.

*두철은 잠금 상태를 확인한다. 현재 칸막이는 x9다. 여백이 `시험 전 — x9` 표를 카메라 프레임 안쪽에 보이게 든다.*

**P04 | 탁두철 [S_CH01_04_0005]**

그런데 어제 제가 9까지 민 건, 사장님이 창가 의자까지 손님 쪽으로 쓰겠다고 해서예요.

**P02 | 봉만실 [S_CH01_04_0006]**

나는 큰 홀로 해 달라고 했지 `창가 의자까지`라고 말했는지는 기억 안 나요. 손님 자리 넓힌 건 맞고.

**P04 | 탁두철 [S_CH01_04_0007]**

제가 들은 건 그 뜻이었습니다. 그래서 9에 잠갔고요.

**P00 | 나여백 [S_CH01_04_0008]**

요청 문구 기억은 서로 다르지만, 실제 작업 결과가 x9였다는 건 칸막이 작업표와 두 분 설명이 일치합니다. 오늘은 그 결과가 공간을 어떻게 바꾸는지만 보겠습니다.

*두철과 만실이 서로 반대쪽 손잡이를 잡는다. 잠금을 풀고 천천히 칸막이를 x6까지 옮긴다. 바퀴가 레일을 지나며 낮은 금속 마찰음을 낸다. 모눈은 선 밖에서 귀를 막지 않고 소리만 듣는다.*

**P01 | 나모눈 [S_CH01_04_0009]**

벽이 방 이름을 끌고 가는 소리 같다.

**P00 | 나여백 [S_CH01_04_0010]**

이제 x6. 북쪽 창은 칸막이 동쪽, 작업실 쪽에 들어가요. 손님 출입문은 서쪽 공개 공간에 있고, 직원 문은 동쪽에 그대로 있습니다.

*여백은 `시험 중 — x6`이라고 적힌 표와 함께 한 장을 기록한다. 두철은 다시 잠금을 풀고 만실과 함께 칸막이를 x9로 천천히 되돌린다.*

**P04 | 탁두철 [S_CH01_04_0011]**

그리고 다시 9. 어젯밤 행사 전에 만든 상태는 이쪽입니다.

**P00 | 나여백 [S_CH01_04_0012]**

x9에서는 북쪽 창이 서쪽 공개 공간에 포함됩니다. 직원 문이 있는 동쪽 띠는 여전히 따로고요.

**P02 | 봉만실 [S_CH01_04_0013]**

그러니까 내가 `창가 작업실`이라고 부른 게 어제 실제 벽 상태하고 안 맞았던 거네요.

**P04 | 탁두철 [S_CH01_04_0014]**

그건 제가 아까 말하려던 겁니다. 벽은 큰 홀로 해 놓고, 사장님 머릿속 방 이름은 예전 걸 쓰고 있었어요.

**P02 | 봉만실 [S_CH01_04_0015]**

당신도 `큰 홀`이라고만 말했잖아. 이런 건 방 이름표를 달아 놨어야지.

**P04 | 탁두철 [S_CH01_04_0016]**

호텔 벽에 방 이름표까지 달면 다음 견적에는 글씨값도 넣겠습니다.

*두철이 x9 잠금을 다시 확인한다. 여백은 마지막 사진에 `시험 후 — x9 복원`이라고 적힌 표를 넣는다.*

**P00 | 나여백 [S_CH01_04_0017]**

시험 끝. 현재 상태는 x9로 복원했습니다. 오늘 x6로 갔던 기록은 어젯밤 이력하고 섞지 않겠습니다.

**P01 | 나모눈 [S_CH01_04_0018]**

그럼 어젯밤 창은 손님 쪽을 봤고, 오늘도 지금은 손님 쪽을 보는 거네.

### If Q01 unresolved

**P00 | 나여백 [S_CH01_04_0019]**

응. 이제 남은 건, 봉 선생님이 그 창으로 본 걸 어디까지 사람 확인이라고 말할 수 있는지야.

### If Q01 already succeeded early via E10/E18

**P02 | 봉만실 [S_CH01_04_0021]**

그 말은 이미 고쳤죠. `계속 있었다`고는 안 하기로 했어요.

**P00 | 나여백 [S_CH01_04_0022]**

네. 그 결론을 다시 따질 필요는 없습니다. 오늘 시험은 왜 방을 잘못 불렀는지와, 어젯밤 벽 상태를 분리해 확인한 겁니다.

**P02 | 봉만실 [S_CH01_04_0023]**

그래도 나는 두 번 봤어요. 방 이름을 틀렸다고 목격까지 없어지는 건 아니잖아요.

**P00 | 나여백 [S_CH01_04_0024]**

맞습니다. 목격 자체를 없애지 않고, 그 두 번이 무엇까지 증명하는지만 묻겠습니다.

*만실 씨 목격 진술 추궁의 표준 북쪽 창 시야/의자에 걸린 재킷+행사 전 칸막이 이동 결론 경로가 열린다.*

### Current revisit / V01 replay / interrupted save

*칸막이 재현 완료 후 다시 연회장에 오면 칸막이는 x9에 있다. 재현을 새 현재 사건처럼 반복하지 않고, `시험 전 x9 / 시험 중 x6 / 시험 후 x9` 기록을 열람한다.*

**P04 | 탁두철 [S_CH01_04_0091]**

다시 움직일 필요는 없습니다. 오늘 시험 사진 세 장에 두 위치가 다 있어요.

**P00 | 나여백 [S_CH01_04_0092]**

그리고 가운데 x6 사진은 `10/22 시험`입니다. 어젯밤 한때 x6였다는 증거로 바꾸어 쓰지 않습니다.

*칸막이 재현 진행 중 저장·중단되었다면 저장된 실제 시험 상태에서 이어 간다. x6까지 이동한 뒤 중단했다면 x9에서 처음부터 다시 시작하지 않고, `시험 중 x6` 상태를 확인한 뒤 안전하게 x9 복원 단계로 진행한다. 세계 효과와 사진 획득을 중복 실행하지 않는다.*

**P00 | 나여백 [S_CH01_04_0093]**

중간에 멈췄다면 벽이 저절로 원래 자리로 돌아갔다고 생각하지 않겠습니다. 멈췄을 때 실제 벽 위치부터 확인하고 남은 단계만 끝내죠.

**P04 | 탁두철 [S_CH01_04_0094]**

지금 6이면 6에서 이어서 9로 돌려놓겠습니다. 한 번 한 동작을 두 번 했다고 적지는 마세요.

---

## C_H_V01 — 칸막이 재현 방문 힌트

### Context
- Place/cast: P00's notebook before/after V01; actual V01 movement occurs only in L03 with P00/P01/P02/P04.
- Entry: K02 held; V01 not joined, in progress, interrupted at a known wall state, or completed.
- Exit/effects: hints do not move the partition or complete V01. They only direct the next safe action for the current saved state.
- E/S/K/B: refers to held E04/E05/K02 and already acquired E06/E07 only when actually held.
- Repeat/resume: state-specific text distinguishes pre-join, x6 interruption, restored x9, and already-complete revisit.

#### Deterministic selector (normative)
- V01 hint access is meaningful once K02 makes the appointment joinable. One request returns one line only.
- If V01 is complete: H0 → `S_H_V01_0002`, H1 → `S_H_V01_0012`, H2 → `S_H_V01_0021`, H3 → `S_H_V01_0032`, H4 → `S_H_V01_0042`.
- If interrupted at x6: H0 → `S_H_V01_0003`, H1 → `S_H_V01_0013`, H2 → `S_H_V01_0021`, H3 → `S_H_V01_0033`, H4 → `S_H_V01_0043`.
- If not yet joined and K02 is held: H0 → `S_H_V01_0001`, H1 → `S_H_V01_0011`, H2 → `S_H_V01_0021`, H3 → `S_H_V01_0031`, H4 → `S_H_V01_0041`.
- Defensive source guard: if an inconsistent resume lacks E04, return `S_H_V01_0022`; if it lacks E05, return `S_H_V01_0023` at any requested level. This guard does not create V01 eligibility.

### H_V01_0 — appointment / return

**Before appointment; K02 held**

**P00 | 나여백 [S_H_V01_0001]**

행사 전 칸막이 이동까지 확인했습니다. 연회장으로 돌아가 두철 씨와 봉만실 선생님에게 오늘 재현시험을 시작하겠다고 말하면 됩니다. 아직 정리 중인 질문이 있다면 메모를 그대로 남겨 두고 들어가요.

**Already completed**

**P00 | 나여백 [S_H_V01_0002]**

칸막이 재현은 이미 끝났고 칸막이는 x9로 복원됐습니다. 다시 사람을 불러 움직이지 말고 `시험 전 x9 / 시험 중 x6 / 시험 후 x9` 기록을 열어 보세요.

**Interrupted return**

**P00 | 나여백 [S_H_V01_0003]**

시험 도중 멈췄다면 그때 칸막이가 서 있던 자리부터 확인하세요. 이미 끝낸 이동을 처음부터 반복하지 않고, 남은 단계만 이어갑니다.

### H_V01_1 — actual history vs current test

**Before/during test**

**P00 | 나여백 [S_H_V01_0011]**

목적은 어젯밤 벽을 다시 만들어 내는 게 아니라 두 정지선에서 고정 창이 어느 공간에 들어가는지 현재 안전하게 비교하는 겁니다. 어젯밤 사실은 칸막이 작업표/행사 전 칸막이 이동 결론, 오늘 움직임은 칸막이 재현으로 따로 적으세요.

**After test already held**

**P00 | 나여백 [S_H_V01_0012]**

이미 가진 가운데 x6 사진은 `10/22 시험`입니다. 그 사진 때문에 어젯밤에도 x6였던 순간이 생기는 건 아닙니다. 역사 기록과 시험 기록의 날짜를 그대로 분리하세요.

**Interrupted at x6**

**P00 | 나여백 [S_H_V01_0013]**

멈췄을 때 벽이 x6에 서 있다면 그건 오늘 시험 도중의 위치입니다. 어젯밤 상태로 해석하지 말고, 비교를 마친 뒤 x9로 되돌리세요.

### H_V01_2 — inspect E04/E05

**Sources held**

**P00 | 나여백 [S_H_V01_0021]**

칸막이 작업표의 `19:40–19:46 / 정지선 9`와 두 정지선의 `6·9` 물리 표식을 같이 보세요. 하나는 어젯밤 작업 이력, 하나는 실제 구조와 가능한 두 위치를 보여 줍니다.

**E04 missing**

**P00 | 나여백 [S_H_V01_0022]**

작업 이력을 아직 안 봤다면 연회장의 두철 씨에게 잠금쇠에 붙은 작업표를 다시 요청하세요. 그 기록을 확인한 뒤에 오늘 시험과 섞이지 않게 비교합니다.

**E05 missing**

**P00 | 나여백 [S_H_V01_0023]**

두 정지선을 아직 실측하지 않았다면 먼저 연회장 바닥의 `6`, `9`와 고정 창·문을 확인하세요. 구조 없이 시험부터 시작하지 않습니다.

### H_V01_3 — supervised movement

**Before movement**

**P00 | 나여백 [S_H_V01_0031]**

두철 씨와 봉만실 선생님이 성인끼리 칸막이를 x9에서 x6로 옮겼다가 x9로 되돌립니다. 모눈이는 안전선 밖에 둡니다. 각 상태에서 창과 두 문이 움직이지 않는다는 점을 비교하세요.

**Movement already completed**

**P00 | 나여백 [S_H_V01_0032]**

이미 두 위치를 기록했다면 벽을 다시 움직일 필요가 없습니다. 세 장의 시험 기록에서 고정 창이 칸막이 어느 쪽에 들어가는지만 다시 보세요.

**Interrupted movement**

**P00 | 나여백 [S_H_V01_0033]**

중단 시점의 실제 벽 위치를 먼저 확인하세요. x6까지 갔다면 그 자리의 비교를 끝낸 뒤 x9로 되돌립니다. 보지 않은 이동을 있었던 일처럼 채워 넣지는 않습니다.

### H_V01_4 — exact completion / resume

**Not yet joined**

**P00 | 나여백 [S_H_V01_0041]**

연회장에서 두철 씨와 봉만실 선생님에게 재현시험을 시작하겠다고 말하고 함께 들어가세요. `시험 전 9미터 → 시험 중 6미터 → 시험 후 9미터`를 확인하고 원래 상태로 돌려놓는 데까지 끝냅니다. 이미 창 시야 시험이나 재킷 회수 사진을 봤다면 같은 일을 반복하지 말고 그 기록을 다시 펼쳐 보세요. 목격 정정이 아직이면 그 자료들을 묶어 목격 범위를 따지고, 이미 정정했다면 남은 공간 문제로 돌아갑니다.

**Already completed and E06 held**

**P00 | 나여백 [S_H_V01_0042]**

칸막이 재현과 북쪽 창 시야까지 이미 확인했습니다. 칸막이는 x9로 돌아와 있어야 합니다. 목격 정정이 아직이면 창 시야 시험·회수 사진·확인된 칸막이 위치를 함께 보세요. 이미 정정됐다면 같은 말을 되풀이하지 말고 아직 끝내지 않은 공간 질문으로 넘어가면 됩니다.

**Interrupted after x6 image**

**P00 | 나여백 [S_H_V01_0043]**

아까 `시험 중 x6`에서 멈췄다면 그 자리에서 고정 창 위치를 확인한 뒤, 두철 씨와 봉만실 선생님이 x9로 되돌리는 데까지 마치세요. 그 뒤에는 북쪽 창 시야와 만실 씨가 실제로 본 범위를 이어서 따지면 됩니다.

---

## C_Q01 — 그 두 번의 목격으로 어디까지 말할 수 있을까?

### Context
- Place: P02 must be physically present in L03/L04/L02 at a legitimate current revisit; no remote or historical replay can create the correction.
- Cast: P00, P02. Other present witnesses may remain silent unless the chosen route naturally includes them.
- Entry: early route after C_CH01_02 with E10+E18, or standard route after C_CH01_04 with E06+E07+K02. D01/D02/V01 may still be pending on the early route.
- Exit: one successful challenge creates the sole S_Q01_v2, E08 and KQ01. The unused proof route becomes supporting material only.
- E/S/K/B: targets the still-current S_Q01_v1. Branches: incomplete, route A, route B, named error, shared success, retry, aftermath/revisit/history.
- Effects: no automatic guilt, route use or culprit inference.
- Repeat/resume: after success, current revisit uses the corrected account; historical replay labels S_Q01_v1 as past and never makes it current again.

### Historical claim in scope

> **S_Q01_v1 — 봉만실:** `무록 씨는 그 방에 계속 있었어요. 창으로 제가 봤다니까요.`

### Free clarification — no exclusive fact leaked

**P00 | 나여백 [S_Q01_0001]**

봉 선생님, 아까 `무록 씨가 그 방에 계속 있었다`고 하셨죠. 창에서 본 두 장면을 근거로 그 말까지 확신하시는 겁니까?

**P02 | 봉만실 [S_Q01_0002]**

네. 같은 창에서 두 번 봤고, 나는 같은 사람이 같은 자리에 있었다고 봤어요. 그래서 `계속 있었다`는 말도 아직 그대로입니다.

**P00 | 나여백 [S_Q01_0003]**

알겠습니다. 그럼 지금은 그 주장을 그대로 두고, 제가 가진 자료가 그 범위를 어디까지 받쳐 주는지만 확인하겠습니다.

- Author state: **Q01:** `그 두 번의 목격으로 어디까지 말할 수 있을까?`

### B_Q01_incomplete

*선택한 경로의 필수 자료가 빠졌거나, `두 번 보았다`와 `그 사이 계속 있었다` 사이의 이유가 비어 있으면 무료로 보류된다.*

**P00 | 나여백 [S_Q01_0011]**

지금 주장은 `두 번 봤다` 다음에 곧바로 `계속 있었다` 또는 `계속 있지 않았다`로 넘어가요. 중간을 뒷받침할 자료를 하나의 경로로 완성한 뒤 다시 말하겠습니다.

*여유 변화 없음. 초안은 유지된다.*

### Valid route A — E10 + E18 direct counterexample

**P00 | 나여백 [S_Q01_0021]**

제가 어젯밤 공개 점검을 준비하던 동안 봉 선생님은 제 옆에 있었고, 봉 선생님이 찍은 행사 사진에는 차무록 씨가 서비스 접속부 쪽 입구에 붉은 코트를 입고 서 있습니다. 그 사진의 전경에 제가 들고 있던 번호표가 있고, 저는 그 사진이 찍히는 장면을 직접 봤습니다. 그러면 창에서 떨어진 두 번의 목격만으로 `그 사이에도 계속 그 방에 있었다`고 말할 수는 없습니다.

**P02 | 봉만실 [S_Q01_0022]**

그 사진은 내가 찍었으니 부정할 수가 없네요. 내가 본 두 장면 사이에 무록 씨가 다른 데 있었던 장면도 실제로 있었어요.

*이 경로는 칸막이 재현 전에도 성립한다. 창 위치 추론/칸막이 이동 추론은 방 구조와 정상 작업 이력을 밝히기 위해 계속 남는다.*

### Valid route B — E06/E07 + K02 sightline/configuration

**P00 | 나여백 [S_Q01_0031]**

행사 전 칸막이 이동 결론대로 두 목격 때 칸막이는 이미 x9였습니다. 북쪽 창 시야 시험에서는 빈 의자에 재킷만 걸어도 창 위로 소매가 보였고, 앉은 사람의 얼굴 높이는 고정 책상등에 가려졌습니다. 의자에 걸린 재킷에는 실제 발견 당시 차무록 씨 재킷이 의자에 걸려 있었습니다. 그러니 창에서 비슷한 모습을 두 번 본 것만으로 그 사람이 그 사이 계속 그 자리에 있었다고 확정할 수 없습니다.

**P02 | 봉만실 [S_Q01_0032]**

두 번 다 같은 자리에 비슷하게 보였다는 걸 내가 `같은 사람이 계속 있었다`로 이어 붙였다는 거죠.

### B_Q01_err_uncertainty_proves_complicity

**P00 | 나여백 [S_Q01_0041]**

그렇게 확실하지 않은 걸 확실하다고 말한 건 차무록 씨를 감싸기 위해서였다고 보겠습니다. 그러면 봉 선생님도 사건의 공범이라고—

**P02 | 봉만실 [S_Q01_0042]**

아니요. 내가 잘못 본 것과 누군가를 해치려고 입을 맞춘 건 같은 말이 아니에요. 내가 부풀린 부분은 고치겠지만, 하지 않은 일까지 그 틈에 넣지는 마세요.

**P00 | 나여백 [S_Q01_0043]**

맞습니다. 목격의 한계를 지적한 것만으로 공모 동기나 행동은 생기지 않습니다. 그 전제는 빼고 다시 말하겠습니다.

> 완결된 잘못된 전제로 제출했으므로 여유 `-2`. 초안/자료는 유지된다.

### B_Q01_success — shared correction

*유효 경로 A 또는 B의 주장과 이유가 완성되면 봉만실이 자기 진술 범위를 직접 정정한다. 정정 대사는 이 장면에서 한 번만 발생한다.*

**P02 | 봉만실 [S_Q01_v2]**

정정할게요. 내가 본 건 20시 8분쯤하고 20시 25분쯤, 북쪽 창 너머 의자 쪽에서 파란 소매 같은 게 보인 두 번뿐이에요. 얼굴은 한 번도 못 봤고, 그 사이를 계속 지켜본 것도 아닙니다. 그러니까 `무록 씨가 그 방에 계속 있었다`고 말한 건 내가 너무 많이 말한 거예요.

#### E08 — 창가 목격 정정

> 봉만실은 약 20:08과 20:25의 떨어진 두 목격만 인정한다.
> 두 번 모두 얼굴을 확인하지 못했고, 의자 쪽/소매처럼 보이는 부분만 보았다.
> 두 목격 사이를 연속 관찰하지 않았다.
> **제한:** 잘못된 확신의 정정이며, 공범·범인·이동 경로를 증명하지 않는다.

**P00 | 나여백 [S_Q01_0051]**

제가 기록할 정정은 거기까지입니다. 두 번 본 사실은 남기되, 얼굴 확인과 연속 관찰은 없었던 것으로 분리하겠습니다.

**P02 | 봉만실 [S_Q01_0052]**

내가 사람 이름까지 붙여 놓고 이제 소매였다고 고치는 게 모양은 안 좋네요. 그래도 그게 맞으면 그렇게 적어요.

**P00 | 나여백 [S_Q01_0053]**

모양보다 범위가 중요합니다. 이 정정만으로 누가 어디로 갔는지는 아직 모릅니다.

- Author state: **KQ01 획득. E08 획득.**
> D03 eligibility opens. If D01/D02 are still unfinished because early route A was used, they remain required and their prompts are reworded as unresolved configuration/work questions rather than repeating the alibi correction.

### B_Q01_retry

**P00 | 나여백 [S_Q01_0061]**

아까 주장은 버리지 않고, `두 번의 목격이 말하는 범위`와 `그 사이 계속 있었다는 추가 주장`을 분리해 다시 쓰겠습니다.

**P02 | 봉만실 [S_Q01_0062]**

내가 실제로 본 것만 묻는다면 다시 답할게요. 대신 내가 못 본 사이 일까지 나한테 채우라고 하진 마요.

### Immediate aftermath

**P02 | 봉만실 [S_Q01_0071]**

어젯밤에는 내가 이 집 구조를 제일 잘 안다고 생각했어요. 그러니까 내가 본 것도 제일 잘 안다고 착각했나 봐요.

**P00 | 나여백 [S_Q01_0072]**

구조를 오래 안 것과, 한 장면에서 사람을 확인한 건 다른 종류의 확실함이니까요.

### Current revisit

**P00 | 나여백 [S_Q01_0091]**

봉 선생님이 고친 범위는 이미 적었습니다. 더 기억난 게 없다면 같은 질문으로 그 사이 시간을 채워 넣지는 않겠습니다.

**P02 | 봉만실 [S_Q01_0092]**

두 번, 얼굴 못 봄, 그 사이 계속 본 것 아님. 지금은 그 이상 말하지 않을게요.

### Historical replay introduction

*기록에서 과거 진술을 열면 `초기 진술`과 `정정 진술`이 나란히 표시된다. 과거 문장을 다시 현재 사실처럼 재발화시키지 않는다.*

**P00 | 나여백 [S_Q01_0093]**

초기에는 `계속 있었다`고 기록했고, 정정 뒤에는 두 번의 제한된 목격으로 범위가 좁아졌습니다. 둘 사이의 변화 자체가 기록입니다.

---

## C_H_Q01 — Q01 힌트

### Context
- Place/cast: P00 reviewing the investigation notebook; no absent witness is called by a hint.
- Entry: Q01 unresolved, interrupted, recently wrong, or already corrected. Selector distinguishes route A (E10+E18), route B (E06+E07+K02), missing prerequisites, and E08-held completion.
- Exit/effects: hints do not create S_Q01_v2/E08/KQ01 and never disclose its exclusive times/face/gap facts before success.
- E/S/K/B: pre-success hints may name only held evidence or a currently available acquisition action. Recent-error wording addresses only `uncertainty_proves_complicity`.
- Repeat/resume: after Q01 success, all hint calls return current-correction/revisit guidance rather than another challenge.

#### Deterministic selector (normative)
- Return one line only. Priority: `Q01 complete/E08 held` → `no complete valid route` → `recent named error with a complete route (H3/H4)` → `requested route-specific level`.
- Q01 complete/E08 held, any H0–H4 → `S_H_Q01_0044`.
- Before success, if route A can be completed from the already witnessed prologue sequence and E10 is missing → `S_H_Q01_0001` at any level. Otherwise, if E06 or E07 is missing → `S_H_Q01_0002`; else if K02 is missing → `S_H_Q01_0003`. No higher-level answer is exposed while a route is incomplete.
- If route A (E10+E18) is complete: H0 `S_H_Q01_0004`; H1 `S_H_Q01_0011`; H2 `S_H_Q01_0021`; H3 `S_H_Q01_0032`; H4 `S_H_Q01_0042`.
- If route B (E06+E07+K02) is complete: H0 `S_H_Q01_0004`; H1 `S_H_Q01_0011`; H2 `S_H_Q01_0022`; H3 `S_H_Q01_0032`; H4 `S_H_Q01_0043`. If both are complete, prefer route A only when the player entered through the early-photo route; otherwise preserve the currently selected proof route.
- With a complete route and recent `uncertainty_proves_complicity`, H3/H4 → `S_H_Q01_0033`; H0–H2 remain requested-level route text. Interrupted drafting preserves the selected route and most recent error; it never reactivates S_Q01_v1 after success.

### H_Q01_0

**If early E10/E18 route is available but E10 missing**

**P00 | 나여백 [S_H_Q01_0001]**

프롤로그에서 제가 직접 겪은 공개 점검 순서는 이미 제 기록에 남아 있습니다. 봉 선생님에게 어젯밤 즉석 사진첩을 보여 달라고 하면, 그 구간에 무록 씨가 다른 위치에 있었는지 직접 비교할 수 있어요.

**If standard route missing E06/E07**

**P00 | 나여백 [S_H_Q01_0002]**

사진 경로를 쓰지 않는다면, 북쪽 관람 통로의 창 시야 시험과 진새벽이 보관한 의자·재킷 회수 기록이 필요합니다. 어젯밤 칸막이가 어떤 상태였는지도 작업표와 당시 설명으로 먼저 확인하세요.

**If K02 missing for standard route**

**P00 | 나여백 [S_H_Q01_0003]**

창 시험만으로는 어젯밤 어느 쪽 공간이었는지 붙일 수 없습니다. 행사 전에 칸막이가 9미터 정지선으로 옮겨졌다는 작업 이력을 먼저 확인하세요. 또는 행사 사진과 여백이 직접 본 공개 점검 장면을 연결할 수도 있습니다.

**If a valid route is fully held**

**P00 | 나여백 [S_H_Q01_0004]**

필요한 한 경로는 완성됐습니다. 질문은 `두 번 봤는가`가 아니라 `그 두 번으로 그 사이 계속 있었다고 말할 수 있는가`입니다.

### H_Q01_1

**If either valid proof route is complete**

**P00 | 나여백 [S_H_Q01_0011]**

두 번 본 장면이 정말 같은 사람의 연속된 재실을 식별할 수 있었는지에 집중하세요. 그 사이 다른 위치에서 직접 본 장면이 있거나, 창에서 비슷한 겉모습이 사람 없이도 만들어진다는 시험이 있다면 `계속 있었다`는 주장에는 추가 근거가 필요합니다.

### H_Q01_2

**If route A held**

**P00 | 나여백 [S_H_Q01_0021]**

행사 사진에는 공개 점검 준비 구간의 서비스 접속부 쪽 입구에 차무록 씨가 있고, 제 기록에는 그 사진이 찍힌 공개 점검 준비 순서가 남아 있습니다. 사진 자체 시각표시가 아니라 두 자료의 실제 맥락을 함께 쓰세요.

**If route B held**

**P00 | 나여백 [S_H_Q01_0022]**

창 시야 자료는 오늘의 중립 시험이고, 회수 사진은 어젯밤 의자에 걸려 있던 차무록 씨 재킷의 기록입니다. 별도로 확인한 행사 전 작업은 두 목격 때 칸막이가 9미터 정지선에 있었다는 조건을 붙입니다. 시험과 현장 기록을 같은 출처처럼 합치지는 마세요.

**If neither route complete**

**P00 | 나여백 [S_H_Q01_0023]**

지금 가진 자료 이름만 늘어놓기보다 한 경로를 완성합시다. 사진첩 행사 사진을 봉 선생님에게 요청해 공개 점검 기록과 잇거나, 북쪽 관람 통로 시험 북쪽 창 시야·회수 기록 의자에 걸린 재킷을 확보하고 행사 전 칸막이 이동 결론까지 확인하세요.

### H_Q01_3

**If no valid route complete**

**P00 | 나여백 [S_H_Q01_0031]**

먼저 한 경로를 완성하세요. 봉 선생님 사진첩의 행사 사진을 여백이 직접 본 공개 점검 장면과 잇거나, 창 시야 시험과 재킷 회수 사진을 어젯밤 칸막이 상태와 함께 보세요. 어느 쪽이든 결론은 `연속 재실을 증명하지 못한다`까지이고 공모 의도는 붙이지 않습니다.

**If route complete**

**P00 | 나여백 [S_H_Q01_0032]**

목격이 과장됐다는 걸 보여도 `그래서 공범이다`는 결론은 나오지 않습니다. 지금 고칠 건 목격의 범위뿐입니다. 의도나 범행은 별도 증거가 있어야 합니다.

**Recent error: uncertainty_proves_complicity**

**P00 | 나여백 [S_H_Q01_0033]**

방금은 불확실한 목격을 곧바로 공모 의도로 바꿨습니다. `연속 재실을 증명하지 못한다`까지만 정리하고, 왜 잘못 말했는지는 지금 단정하지 마세요.

### H_Q01_4

**If neither route complete**

**P00 | 나여백 [S_H_Q01_0041]**

지금 바로 결론을 쓰기보다 한 경로를 먼저 완성하세요. 사진을 쓸 거라면 봉 선생님 사진첩의 행사 사진을 여백이 직접 본 공개 점검 장면과 연결합니다. 창 쪽을 쓸 거라면 창 시야 시험, 진새벽이 보관한 재킷 회수 사진, 어젯밤 칸막이 상태를 함께 보세요. 그 뒤 지금 가진 경로에 맞는 주장으로 정리하면 됩니다.

**Route A final proof**

**P00 | 나여백 [S_H_Q01_0042]**

사진 경로라면 이렇게 말할 수 있습니다. `행사 사진에서 무록 씨는 공개 점검 무렵 서비스 접속부 쪽 입구에 있고, 공개 점검 기록으로 나는 그 사진이 만들어진 공개 순서를 직접 기억한다. 따라서 떨어진 두 창 목격만으로 그 사이에도 계속 같은 방에 있었다고 할 수 없다. 봉만실 선생님이 실제로 본 범위를 다시 말해야 한다.`

**Route B final proof**

**P00 | 나여백 [S_H_Q01_0043]**

창 시험 경로라면 이렇게 말할 수 있습니다. `행사 전 칸막이 이동 결론으로 두 목격 때 벽은 x9였고, 북쪽 창 시야에서는 빈 의자+재킷도 사람처럼 보일 수 있으며 의자에 걸린 재킷에는 실제로 무록 씨 재킷이 의자에 걸려 있었다. 그러므로 두 목격은 얼굴 확인이나 연속 재실을 증명하지 않는다. 실제로 본 두 순간의 범위만 정정해야 한다.`

**If Q01 already succeeded / E08 held**

**P00 | 나여백 [S_H_Q01_0044]**

이 목격 진술은 이미 정정됐습니다. 현재 기록은 `20:08쯤과 20:25쯤 두 번, 얼굴 미확인, 사이 시간은 지켜보지 않음`입니다. 다른 경로로 같은 정정을 되풀이하지 말고 아직 남은 질문으로 이어가세요.

---


---

## C_CH01_05 — 남겨 둔 자리와 남아 있던 사람

### Context
- Place: L03 after the completed partition work/test → L02 family rest area.
- Cast: P00, P01, P02.
- Entry: Q01 has succeeded and E08/KQ01 exist, and C_CH01_04/V01 has returned the partition to x9. P01 is already back under P00's direct supervision in L03. If Q01 succeeded by the early E10/E18 route, C_CH01_03/C_D02/C_CH01_04/V01 still occur before this scene.
- Exit: P02 accepts the limited correction without being converted into a culprit; P01 distinguishes a reserved place from continued presence. D03 is available when K01/K02/E07/E08 are actually held.
- E/S/K/B: reads E08 and, only if already held, E07/E10/E18; S_Q01_v2 remains the current P02 account. No new branch variable is set.
- Effects: no new E/K, no time or route fact, no automatic suspicion change.
- Repeat/resume: revisit preserves the one Q01 correction and does not replay the admission or create a second corrected time.

### Script

*칸막이를 x9로 돌려놓은 뒤, 여백은 모눈과 함께 만실을 따라 연회장을 나온다. 모눈은 방금까지 안전선 밖에서 시험을 지켜봤고, 여백이 다시 직접 함께 있는 상태다. 세 사람이 휴게실 문 앞에 이르자 만실은 자기 우산 번호표 하나를 괜히 반듯하게 돌려 놓는다.*

**P02 | 봉만실 [S_CH01_05_0001]**

내가 이 집에서 서른 해 가까이 문 열고 닫았는데, 창 하나 보고 사람을 틀렸다고 하니 좀 창피하네요.

**P00 | 나여백 [S_CH01_05_0002]**

틀린 건 `두 번 봤다`가 아니라, 그 두 장면을 `계속 있었다`로 이어 붙인 부분입니다. 실제로 본 두 번은 그대로 기록돼요.

**P02 | 봉만실 [S_CH01_05_0003]**

그러니까 더 모양이 안 좋아요. 없는 걸 본 것도 아니고, 본 것에 말을 더 얹은 거니까.

*모눈은 자기 분실물 접수대에 놓인 의자를 잠깐 본다. 등받이에는 `잠시 비움`이라고 적은 종이표가 걸려 있다.*

**P01 | 나모눈 [S_CH01_05_0004]**

이 의자도 내가 접수대 자리라고 정해 놨는데, 내가 화장실 가면 의자만 남잖아.

**P02 | 봉만실 [S_CH01_05_0005]**

그건 네 자리라고 써 있잖니.

**P01 | 나모눈 [S_CH01_05_0006]**

응. 근데 `내 자리`랑 `내가 여기 있음`은 다른 말이잖아.

*만실이 종이표를 쳐다본다. 바로 대답하지 않고 의자를 손으로 한 번 밀어 탁자 밑에 넣는다.*

**P02 | 봉만실 [S_CH01_05_0007]**

아이가 제일 기분 나쁜 방식으로 맞는 말을 하네.

**P01 | 나모눈 [S_CH01_05_0008]**

기분 나쁘게 하려고 한 건 아닌데.

**P02 | 봉만실 [S_CH01_05_0009]**

알아요. 그래서 더 그래.

**P00 | 나여백 [S_CH01_05_0010]**

지금 남은 질문도 그 차이입니다. 창가에 같은 소매가 보였다는 것과, 그 소매 주인이 방에 계속 있었다는 건 같은 기록이 아닙니다.

**P02 | 봉만실 [S_CH01_05_0011]**

그럼 내가 고친 말을 가지고 또 나를 몰아붙이는 겁니까?

**P00 | 나여백 [S_CH01_05_0012]**

아니요. 반대로, 정정한 범위를 넘어서지 않으려는 겁니다. 누가 어디에 갈 수 있었는지는 그다음 문제고요.

**P01 | 나모눈 [S_CH01_05_0013]**

사람이 없는 자리도 남아 있을 수 있고, 자리가 남아 있다고 사람이 남은 건 아니고.

**P02 | 봉만실 [S_CH01_05_0014]**

거기까지만 하자. 오늘 의자들이 너무 말을 많이 들어요.

### Task return wording

*목격 한계 추론 조건이 갖춰지면 여백은 창가 목격 정정과 의자에 걸린 재킷 회수 사진을 같은 화면에 놓는다. 행사 사진/공개 점검 기록 직접 반례를 이미 사용했다면 그것도 보조 자료로 열 수 있지만, 정정을 다시 요구하지 않는다.*

**P00 | 나여백 [S_CH01_05_0021]**

봉 선생님의 정정은 끝났습니다. 이제 사람을 다시 심문하는 게 아니라, 그 정정이 방 알리바이에 어디까지 영향을 주는지 따져 보겠습니다.

> **D03 진입:** `창가의 모습은 연속된 재실 증명일까?`

### Current revisit / interrupted return

**P02 | 봉만실 [S_CH01_05_0091]**

내 정정은 그대로예요. 두 번 봤고, 얼굴은 못 봤고, 그 사이를 계속 본 건 아니에요. 다시 더 크게 말하지 않을 겁니다.

**P01 | 나모눈 [S_CH01_05_0092]**

내 접수대 의자는 아직 내 자리인데, 내가 지금 여기 서 있는 것처럼.

*이 장면 도중 나갔다 돌아와도 창가 목격 정정의 내용은 바뀌지 않는다. 만실의 체면 반응만 과거 대화 기록으로 남고 새 정정이나 새 시각을 만들지 않는다.*

---

## C_D03 — 창가의 모습은 연속된 재실 증명일까?

### Context
- Place: L02 family rest area, using the investigation notebook; P02 is present because C_CH01_05 has just returned here.
- Cast: P00, P01, P02.
- Entry: K01 + K02 + E08 + E07. E10/E18 may also be held as an already-known direct counterexample; Q01 is already corrected and is not challenged again.
- Exit: success → K03 and permission to request V12. Failure retains the same draft and does not alter P02's corrected statement.
- E/S/K/B: uses K01/K02/E07/E08, optionally E10/E18; branches B_D03_incomplete, B_D03_err_ambiguous_chair_identifies_murderer, B_D03_success, B_D03_retry.
- Effects: no new route observation and no culprit assignment. V12 is merely made requestable after K03.
- Repeat/resume: missing prerequisites return to the actual provider/action; a saved draft resumes with the most recent error premise; revisit after K03 states only the established alibi limit.

### Task setup

**P00 | 나여백 [S_D03_0001]**

이제 정정된 목격을 방 구조에 다시 놓겠습니다. 같은 창, 같은 의자, 같은 소매처럼 보이는 것이 `사람이 계속 방에 있었다`는 알리바이로 남을 수 있는지 보죠.

> **D03:** `창가의 모습은 연속된 재실 증명일까?`

### Free clarification

**P01 | 나모눈 [S_D03_0002]**

소매가 사람처럼 보일 수 있다는 걸 맞히면 되는 거야?

**P00 | 나여백 [S_D03_0003]**

그보다 한 단계만 더. `사람처럼 보일 수 있다`는 시험과 `실제로 그 재킷이 의자에 있었다`는 회수 기록, 그리고 `두 번 사이를 보지 않았다`는 정정을 연결해서 알리바이 범위를 정하는 거야.

### B_D03_incomplete

*필수 K/E 중 하나가 없거나, `소매가 보였다` 다음에 곧바로 사람의 이동·범행을 채워 넣으면 제출 전에 무료로 보류한다.*

**P00 | 나여백 [S_D03_0011]**

아직 `창가가 모호했다`와 `그래서 누가 무엇을 했다` 사이가 비어 있습니다. 지금은 알리바이의 범위만 정할 수 있도록 구조와 정정 자료를 먼저 채우겠습니다.

*여유 변화 없음. 작성 중인 주장은 유지된다.*

### Valid realization A — E08/E07 + K01/K02

**P00 | 나여백 [S_D03_0021]**

북쪽 창과 칸막이 위치 결론과 행사 전 칸막이 이동 결론대로 두 목격 때 칸막이는 x9였고, 북쪽 창은 잠긴 동쪽 작업실이 아니라 서쪽 공개 공간 쪽을 비췄습니다. 창가 목격 정정에서 봉 선생님은 떨어진 두 순간에 얼굴 없이 소매 같은 부분만 봤다고 정정했습니다. 의자에 걸린 재킷에는 실제로 차무록 씨 재킷이 의자에 걸려 있었습니다. 그러면 같은 위치의 소매가 두 번 보였다는 사실만으로 차무록 씨가 그 사이 계속 방에 있었다고 말할 수 없습니다.

### Valid realization B — direct counterexample already held

**P00 | 나여백 [S_D03_0022]**

창가 목격 정정에는 두 목격 사이를 지켜보지 않았다고 적혀 있고, 제가 직접 본 공개 점검 과정과 그때 찍힌 행사 사진에는 차무록 씨가 서비스 접속부 쪽 입구에 있습니다. 북쪽 창과 칸막이 위치 결론/행사 전 칸막이 이동 결론까지 놓으면 창가 자리는 공개 공간 쪽이었으니, 창가의 두 장면을 `잠긴 작업실 안에서 계속 재실`로 읽을 근거도 없습니다. 이건 연속 재실을 부정하는 직접 반례이지, 그가 어디로 더 갔다는 증명은 아닙니다.

### B_D03_err_ambiguous_chair_identifies_murderer

**P00 | 나여백 [S_D03_0031]**

의자와 재킷만 남겨도 사람처럼 보일 수 있었다면, 그걸 일부러 남긴 사람이 곧 표문식 씨를 해친 사람이라고 보겠습니다.

**P00 | 나여백 [S_D03_0032]**

잠깐. 그 결론에는 행동이 하나 더 들어갔습니다. 우리는 재킷이 의자에 있었고 목격이 사람을 식별하지 못했다는 것까지 확인했습니다. 누가 어떤 목적으로 걸었는지, 누가 표문식 씨에게 갔는지는 여기서 증명되지 않습니다.

**P00 | 나여백 [S_D03_0033]**

모호한 알리바이를 곧바로 범인 식별로 바꿨네요. `계속 있었다는 증명이 아니다`까지만 남기겠습니다.

> 완결된 잘못된 전제로 제출했으므로 여유 `-2`. 자료와 초안은 유지된다.

### B_D03_success

*위 유효 실현 중 현재 보유 자료에 맞는 주장으로 제출하면 같은 창가 목격의 한계 결론으로 수렴한다.*

**P00 | 나여백 [S_D03_0041]**

정리하면, 창가의 두 모습은 차무록 씨가 그 자리에 계속 있었다는 연속 재실 증명이 아닙니다. 같은 소매 모양은 주인 없이 남을 수 있고, 봉 선생님은 그 사이를 지켜보지 않았습니다. 공개 점검 사진을 이미 확인했다면 실제로 그 사이 다른 위치에 있었던 장면까지 있습니다. 여기서 확정되는 건 알리바이의 약화이지 범행입니다.

**P00 | 나여백 [S_D03_0042]**

방 안에 계속 있었다는 전제는 뺄 수 있습니다. 밖에서 무엇을 했는지는 아직 열어 둡니다. 이 범위로만 기록하겠습니다.

**P02 | 봉만실 [S_D03_0043]**

내가 잘못 본 말을 고친 것까지는 인정해요. 그 다음 일을 내 눈으로 봤다고 만들지만 마세요.

- Author state: **K03 획득:** 창가 목격과 남겨진 재킷은 P03의 연속 재실을 증명하지 않는다. 범행 주체나 실제 이동은 아직 미확정.
- Author state: **V12 사용 가능:** P07에게 공용 출구와 L08 연결부의 성인 동선 실측을 요청할 수 있다.

### B_D03_retry

**P00 | 나여백 [S_D03_0051]**

아까 문장에서 사람의 행동을 너무 멀리 채웠습니다. 적어 둔 문장은 남겨 두고 `목격이 증명하지 못하는 범위`까지만 다시 쓰겠습니다.

**P00 | 나여백 [S_D03_0052]**

가능성과 실행을 분리해 두면 다음 동선 시험도 같은 방식으로 볼 수 있습니다. 창가 목격의 한계 결론이 정리되면 진새벽 씨에게 공용 출구 실측을 요청하겠습니다.

### Current revisit

**P00 | 나여백 [S_D03_0091]**

창가 목격의 한계 결론은 `차무록 씨가 계속 방에 있었다는 증거가 없다`입니다. `차무록 씨가 반드시 방을 나갔다`나 `누군가 재킷을 범행용으로 배치했다`까지는 아닙니다.

---

## C_H_D03 — D03 힌트

### Context
- Place/cast: P00 at the investigation notebook in L02; P01/P02 may remain physically present but are not summoned as new evidence providers.
- Entry: D03 unresolved/revisited. Selector checks K01/K02/E07/E08, optional E10/E18, recent named error, and K03-complete state.
- Exit: hint only; no K03, V12 request, evidence acquisition or 여유 change.
- E/S/K/B: held-source wording names only held material; missing-source wording points to the current provider/action without quoting unseen contents.
- Effects: none.
- Repeat/resume: interrupted D03 keeps its draft and most recent failed premise; K03-complete revisit does not restage the task.

#### Deterministic selector (normative)
- One request returns one line. Priority: `K03 complete` → `missing prerequisite` → `recent named error at H3/H4` → `requested held-source level`.
- `K03 complete`, any H0–H4 → `S_H_D03_0043`.
- K01 missing → `S_H_D03_0001`; else K02 missing → `S_H_D03_0002`; else E08 missing → `S_H_D03_0003`; else E07 missing → `S_H_D03_0004`, regardless of requested level.
- All required held: H0 `S_H_D03_0005`; H1 `S_H_D03_0011`; H2 `S_H_D03_0022` when E10+E18 are also held, otherwise `S_H_D03_0021`; H3 `S_H_D03_0031`; H4 `S_H_D03_0042`.
- Recent `ambiguous_chair_identifies_murderer` with all prerequisites held, H3/H4 → `S_H_D03_0032`. Interruption does not bypass missing checks.

### H_D03_0

**If K01 missing**

**P00 | 나여백 [S_H_D03_0001]**

먼저 북쪽 창이 칸막이가 6미터와 9미터 정지선에 있을 때 어느 공간에 속하는지 확인하세요. 창가가 잠긴 작업실 쪽인지 공개 공간 쪽인지 모르면 알리바이 범위를 정할 수 없습니다.

**If K02 missing**

**P00 | 나여백 [S_H_D03_0002]**

어젯밤 행사 전에 칸막이가 9미터 정지선으로 옮겨졌다는 실제 작업 이력을 확인하세요. 오늘 시험 상태를 어젯밤과 섞지 않습니다.

**If E08 missing**

**P00 | 나여백 [S_H_D03_0003]**

봉 선생님의 현재 진술이 아직 `계속 있었다`라면 그 주장부터 직접 확인해야 합니다. 이미 가진 행사 사진과 자신의 공개 점검 기억을 맞춰 볼 수도 있고, 창 시야 시험·회수 사진·확인된 칸막이 상태를 묶어 따져 볼 수도 있습니다.

**If E07 missing**

**P00 | 나여백 [S_H_D03_0004]**

진새벽이 보관한 발견 당시 의자·재킷 회수 사진을 북쪽 관람 통로 시야 확인에서 요청하세요. 오늘 시험 사진만으로 실제로 재킷이 남아 있었다고 대신하지 않습니다.

**If all required held**

**P00 | 나여백 [S_H_D03_0005]**

필수 자료는 있습니다. `x9의 창 위치`, `두 번의 제한된 목격`, `실제로 의자에 남은 재킷`을 한 줄로 연결해 연속 재실이 성립하는지 보세요.

### H_D03_1

**If a required source is still missing**

**P00 | 나여백 [S_H_D03_0012]**

아직 자료가 하나 비어 있다면 결론부터 쓰지 않겠습니다. 창과 칸막이 관계는 연회장 구조 확인으로, 어젯밤 칸막이 상태는 작업 이력으로, 목격 범위는 봉 선생님의 현재 진술로, 실제 재킷 상태는 진새벽이 보관한 회수 사진으로 채우면 됩니다.

**If all required sources are held**

**P00 | 나여백 [S_H_D03_0011]**

핵심은 `같은 소매가 보였다`와 `같은 사람이 계속 있었다`의 차이입니다. 의자에 걸린 재킷은 주인이 없어도 같은 자리에 남을 수 있고, 창가 목격 정정은 두 목격 사이를 계속 보지 않았다고 말합니다.

### H_D03_2

**If E08/E07 held**

**P00 | 나여백 [S_H_D03_0021]**

창가 목격 정정은 두 번의 제한된 목격과 연속 관찰 부재를, 의자에 걸린 재킷은 차무록 씨 재킷이 실제 의자에 남아 있던 상태를 보여 줍니다. 확인된 창 위치와 행사 전 칸막이 상태는 그 창가가 당시 공개 공간 쪽이었다는 구조 조건입니다.

**If direct E10/E18 also held**

**P00 | 나여백 [S_H_D03_0022]**

행사 사진과 공개 점검 기록은 별도 보강입니다. 공개 점검 중 차무록 씨가 서비스 접속부 쪽에 있었던 실제 장면을 여백이 경험한 순서와 연결하므로 `그 사이 계속 방에 있었다`는 주장에 직접 반례가 됩니다. 사진 한 장을 독립된 두 목격처럼 세지는 마세요.

**If source missing**

**P00 | 나여백 [S_H_D03_0023]**

창가 목격 정정이 없으면 만실 씨 목격 진술 추궁, 의자에 걸린 재킷이 없으면 북쪽 관람 통로의 회수 사진 확인으로 돌아가세요. 이름을 아직 모르는 미래 자료를 찾을 필요는 없습니다.

### H_D03_3

**If a required source is still missing**

**P00 | 나여백 [S_H_D03_0033]**

지금 단계에서 없는 자료의 내용을 상상하지 마세요. 비어 있는 항목을 실제 조사 위치에서 확보한 뒤, `두 번 보인 모습`과 `사람이 계속 있었다` 사이에 어떤 증명이 빠지는지만 적으면 됩니다.

**If all held**

**P00 | 나여백 [S_H_D03_0031]**

`두 번의 모습이 사람을 식별하지 못했고, 같은 재킷은 주인 없이 남을 수 있으며, 사이 시간은 관찰되지 않았다`까지 연결하세요. 그 뒤에 붙일 결론은 `연속 재실을 증명하지 못한다`입니다.

**Recent error: ambiguous_chair_identifies_murderer**

**P00 | 나여백 [S_H_D03_0032]**

방금은 모호한 의자 장면에서 범인을 골라 버렸습니다. 지금 가진 자료에는 범행 행동을 보여 주는 장면이 없습니다. 재킷을 왜 두었는지나 누가 사람을 해쳤는지는 말하지 말고 알리바이 범위만 줄이세요.

### H_D03_4

**If required source missing**

**P00 | 나여백 [S_H_D03_0041]**

없는 필수 조건부터 채우세요. 창과 칸막이 관계가 비었으면 공간 질문으로, 행사 전 이동이 비었으면 작업 이력으로, 만실 씨 진술 정정이나 의자·재킷 회수 기록이 비었으면 그 현재 조사로 돌아가세요. 아직 확보하지 않은 자료의 결론을 이 단계에서 대신 말하지 않습니다.

**If all held**

**P00 | 나여백 [S_H_D03_0042]**

이렇게 말할 수 있습니다. `두 목격 때 북쪽 창은 공개 공간 쪽을 향하고 있었다. 봉만실은 얼굴을 확인하지 못한 두 순간만 보았고 그 사이를 계속 보지 않았다. 실제로 차무록의 재킷은 의자에 남아 같은 소매 모습을 만들 수 있었다. 따라서 차무록이 그 사이 계속 그 자리에 있었다는 알리바이는 성립하지 않는다. 범행 여부는 별도다.`

**If K03 already acquired**

**P00 | 나여백 [S_H_D03_0043]**

창가 목격이 어디까지 말해 주는지는 이미 정리했습니다. 다음은 실제로 방 밖에서 어디까지 갈 수 있는지 진새벽에게 성인 동선 확인을 요청하세요. 가능한 길을 찾는 것과 누가 실제로 썼는지는 계속 분리합니다.

---

## C_CH01_06 — 잠긴 쪽을 열지 않고

### Context
- Place: L02 handoff → L03 guest door → L08 service junction → secured R08 boundary → return to L02 after D04.
- Cast: walk P00/P07/P04; handoff/return P01/P02.
- Entry: K03. P00 requests the authorized adult route check. P02 explicitly accepts same-place supervision of P01 in L02 before P00 leaves.
- Exit: E09 is acquired only after the actual walk to the permitted boundary; D04 is attempted at L08. After D04 success the adults retrace the public route and P00 reunites with P01.
- E/S/K/B: creates E09; reads K01/K03 for D04. V12/R05/R08 are author routing metadata only and are not spoken as IDs.
- Effects: the eastern workroom/service-door strip stays locked; nobody crosses the partition or enters L09. D04 alone can create K04.
- Repeat/resume: completed path segments are not re-walked after interruption; resume from the last permitted checkpoint, with P01 still supervised by P02.

### Script

*여백은 휴게실에서 모눈의 안전 구역 카드를 다시 탁자에 놓고 만실에게 맡긴다.*

**P00 | 나여백 [S_CH01_06_0001]**

모눈이는 여기서 봉 선생님과 있어. 저는 진새벽 씨, 탁두철 씨하고 공용 출구 동선만 보고 올게.

**P01 | 나모눈 [S_CH01_06_0002]**

잠긴 문 따러 가는 거 아니지?

**P00 | 나여백 [S_CH01_06_0003]**

반대야. 잠긴 쪽을 안 열고 어디까지 갈 수 있는지 보러 가는 거야.

**P02 | 봉만실 [S_CH01_06_0004]**

얘는 내가 데리고 있을게요. 돌아오면 우산 205번 말리는 거 도와줘요. 사람은 안 젖었는데 우산이 퇴근을 못 했어.

*연회장 손님 출입문 앞에서 새벽이 임시 출입 끈을 한쪽으로 옮긴다. 동쪽 작업실 쪽 서비스 문에는 사건 후 봉인 표지가 그대로 붙어 있다.*

**P07 | 진새벽 [S_CH01_06_0005]**

오늘 허가하는 건 공용 손님 문에서 서비스 접속부 연결부까지, 그리고 수영장 상부 랜딩으로 이어지는 통제선 앞까지입니다. 동쪽 작업실 문과 사건 현장 안쪽은 열지 않습니다.

**P04 | 탁두철 [S_CH01_06_0006]**

그러면 제가 먼저 걸을게요. 사람한테 설명하면 자꾸 지름길을 찾으니까, 바닥한테 설명한다고 생각하고 그대로 갑시다.

**P07 | 진새벽 [S_CH01_06_0007]**

바닥은 진술서 안 씁니다. 저한테 설명하세요.

**P04 | 탁두철 [S_CH01_06_0008]**

그래서 더 믿음직한데요.

*세 사람은 북쪽 창 아래 의자 위치에서 손님 출입문까지 걸어 나와, 남쪽으로 돌아 서비스 접속부 연결부를 향한다. 칸막이나 동쪽 작업실을 통과하지 않는다.*

**P00 | 나여백 [S_CH01_06_0009]**

의자에서 손님 문까지는 공개 공간 안에서 바로 닿습니다. 문을 나가면 남쪽 연결부로 이어지고요.

**P07 | 진새벽 [S_CH01_06_0010]**

손님 문에서 여기 서비스 접속부까지 약 26미터입니다. 보통 걸음으로 여러 번 확인한 범위가 30초에서 45초 정도예요. 오늘은 평소 걸음만 잽니다.

**P04 | 탁두철 [S_CH01_06_0011]**

여기서 왼쪽으로 꺾으면 서비스 문 바깥쪽하고 만납니다. 안쪽 작업실은 잠겨 있어도 이 공용 복도는 따로예요.

*서비스 접속부에서 두철이 손으로 두 경로를 가리킨다. 서쪽 뒤편은 방금 온 손님 문 쪽, 북쪽 가까운 짧은 길은 연회장 서비스 문 바깥쪽이다. 서비스 문 자체는 잠겨 있다. 동쪽으로는 수영장 상부 랜딩 방향 통제선이 보인다.*

**P00 | 나여백 [S_CH01_06_0012]**

즉, 작업실을 통과해서 여기로 나온 게 아니라 손님 문으로 건물 바깥쪽 연결부를 돌아온 겁니다.

**P07 | 진새벽 [S_CH01_06_0013]**

맞습니다. 동쪽 좁은 작업실 구간은 계속 잠긴 상태로 두고도, 손님 문에서 이쪽으로 돌아오는 공용 길은 열려 있습니다.

*새벽은 통제선 앞에 줄자를 놓고 수영장 상부 랜딩 방향을 가리킨다. 안쪽 사건 현장으로 들어가지는 않는다.*

**P07 | 진새벽 [S_CH01_06_0014]**

여기 서비스 접속부에서 수영장 상부 랜딩 경계까지는 약 12미터, 보통 걸음 15초에서 25초 범위입니다. 지금은 경계까지만 확인합니다. 안쪽 현장 검사는 별도 승인 뒤입니다.

**P04 | 탁두철 [S_CH01_06_0015]**

그러니까 방에서 나왔다고 작업실 열쇠가 필요한 건 아니었다는 거죠.

**P00 | 나여백 [S_CH01_06_0016]**

네. 하지만 이 길이 있다는 것과 누가 그 길을 실제로 걸었다는 건 아직 다릅니다.

**P07 | 진새벽 [S_CH01_06_0017]**

그 문장도 기록해 두세요. 동선 시험은 특히 그 차이를 자주 잃습니다.

#### E09 — 출입 동선 실측

> 북쪽 창 아래 의자 위치 → 연회장 손님 출입문 → 손님 통로 → 서비스 접속부 → 수영장 접근 통로 → 수영장 상부 랜딩 통제선.
> 손님 통로: 약 26m / 보통 걸음 30–45초.
> 수영장 접근 통로: 약 12m / 보통 걸음 15–25초.
> 연회장 동쪽 작업실/서비스 문 구간은 잠긴 상태로 별도 표시.
> `걸어서 잰 시간이며 달리기의 한계가 아님.`
> **제한:** 가능한 출발·도달 경로를 보여 줄 뿐, 특정 인물이 사용했다는 관찰 기록이 아니다.

**P00 | 나여백 [S_CH01_06_0018]**

출입 동선 실측은 `잠긴 작업실을 열지 않아도 공용 쪽에서 수영장 상부 랜딩 경계까지 갈 수 있다`는 시험입니다. 시각표나 목격으로 바꾸지 않겠습니다.

### Interrupted / resume states

**Interrupted before leaving L03**

**P07 | 진새벽 [S_CH01_06_0081]**

아직 실제로 걷기 전이라면 연회장 손님 문에서 시작하죠. 지도에 선만 그은 것과 직접 걸어 확인한 건 따로 적겠습니다.

**Interrupted at L08 after R05 measured**

**P07 | 진새벽 [S_CH01_06_0082]**

손님 문에서 여기 서비스 접속부까지는 이미 쟀습니다. 여기서 이어서 잠긴 서비스 문 바깥쪽을 확인하고, 허용된 수영장 상부 랜딩 통제선까지만 갑니다. 처음부터 다시 걸을 필요 없습니다.

**Interrupted after R08 boundary before acknowledgment**

**P00 | 나여백 [S_CH01_06_0083]**

두 구간 측정은 끝났고 현장 안쪽에는 들어가지 않았습니다. 지금 보던 동선 카드 확인부터 이어서 출입 동선 실측을 정리하겠습니다.

### Task transition at L08

*두 구간 실측을 마친 뒤에도 세 사람은 서비스 접속부 통제선 바깥에 그대로 서 있다. 모눈은 계속 휴게실에서 봉만실의 감독 아래 기다리고 있다. 여백은 돌아가기 전에 방금 걸은 경로를 지도 위에 한 번 정리한다.*

**P00 | 나여백 [S_CH01_06_0021]**

지금 확인한 건 `갈 수 있음`입니다. `누가 갔음`은 아직 아니고요. 돌아가기 전에 경로 자체부터 확정하겠습니다.

**P07 | 진새벽 [S_CH01_06_0022]**

좋습니다. 현장 안쪽으로 들어가지 말고 여기서 지도와 실측 카드만 사용하세요.

> **D04 진입:** `잠긴 작업실을 거치지 않고 나갈 수 있었을까?`

### Current revisit

**P07 | 진새벽 [S_CH01_06_0091]**

출입 동선 실측의 경로는 다시 걸어도 같은 공간 시험입니다. 새 목격자가 생기거나 실제 사용자가 확인되는 건 아닙니다.

---

## C_D04 — 잠긴 작업실을 거치지 않고 나갈 수 있었을까?

### Context
- Place: L08 service junction at the permitted boundary, immediately after the actual E09 walk.
- Cast: P00, P07, P04. P01 remains in L02 with P02 and is not summoned into this task.
- Entry: E09 + K01 + K03. The question is route feasibility only.
- Exit: success → K04, then P00/P07/P04 retrace the public route to L03; P00 returns to L02 and resumes direct supervision of P01.
- E/S/K/B: uses E09/K01/K03; branches B_D04_incomplete, both named error branches, success, retry.
- Effects: no door unlock, no L09 entry, no actual-user observation.
- Repeat/resume: the route card and draft survive wrong/incomplete attempts; revisit after K04 does not restage the walk.

### Task setup

**P00 | 나여백 [S_D04_0001]**

처음에는 `작업실이 잠겨 있으니 창가에 있던 사람은 갇혀 있었다`는 인상이 있었습니다. 출입 동선 실측과 지금까지의 방 구조를 놓고, 잠긴 동쪽 구간을 건드리지 않는 경로가 있는지 확인하겠습니다.

> **D04:** `잠긴 작업실을 거치지 않고 나갈 수 있었을까?`

### Free clarification

**P04 | 탁두철 [S_D04_0002]**

문이 두 개라서 헷갈리면, 열쇠부터 보지 말고 어디로 나가는 문인지 보세요. 손님 문은 공개 쪽, 서비스 문은 동쪽 작업실 쪽입니다.

**P00 | 나여백 [S_D04_0003]**

네. 경로를 실제 순서로 고르고, 닫힌 칸막이나 잠긴 서비스 문을 통과시키지 않겠습니다.

### B_D04_incomplete

*출입 동선 실측/북쪽 창과 칸막이 위치 결론/창가 목격의 한계 결론 중 하나가 없거나 출발·도착만 고르고 중간 연결부가 비어 있으면 무료 보류한다.*

**P00 | 나여백 [S_D04_0011]**

출발점과 도착점 사이가 비어 있습니다. `창가 공개 공간 → 손님 문 → 서비스 접속부 → 수영장 상부 랜딩 경계`가 실제로 이어지는지 출입 동선 실측을 포함해 다시 놓겠습니다.

*여유 변화 없음. 선택한 경로 조각은 유지된다.*

### B_D04_err_route_crosses_closed_partition

**P00 | 나여백 [S_D04_0021]**

창가에서 동쪽 작업실을 가로질러 서비스 문으로 나와 서비스 접속부로 가는 경로를 고르겠습니다.

**P04 | 탁두철 [S_D04_0022]**

그건 닫힌 칸막이를 통과시킨 겁니다. x9에서 창가 의자는 서쪽 공개 공간에 있고, 서비스 문은 동쪽 띠에 남아 있어요. 벽에는 사람 통과 구멍이 없습니다.

**P07 | 진새벽 [S_D04_0023]**

출입 동선 실측에서 실제로 걸은 건 손님 문으로 나가 서비스 접속부까지 돌아온 공용 길입니다. 잠긴 구간을 열지 않았다는 조건을 그대로 지키세요.

**P00 | 나여백 [S_D04_0024]**

벽을 지도 선처럼 무시했네요. 손님 문에서 남쪽 연결부로 도는 경로로 다시 잡겠습니다.

> 완결된 잘못된 전제로 제출했으므로 여유 `-2`.

### B_D04_err_feasible_route_proves_observed_use

**P00 | 나여백 [S_D04_0031]**

공용 경로가 실제로 열려 있었으니 차무록 씨가 그 길로 수영장 상부 랜딩까지 갔다고 확정하겠습니다.

**P07 | 진새벽 [S_D04_0032]**

시험한 건 `갈 수 있다`입니다. 그 시각 그 사람이 걷는 것을 본 목격이나 이동 기록은 지금 확인한 자료에 없습니다.

**P04 | 탁두철 [S_D04_0033]**

길이 있다고 다 제가 그 길을 걷는 건 아니죠. 호텔에 계단도 많은데 제가 다 오르진 않습니다.

**P00 | 나여백 [S_D04_0034]**

가능성을 실행 기록으로 바꿨습니다. 실제 사용 여부는 열어 두겠습니다.

> 완결된 잘못된 전제로 제출했으므로 여유 `-2`.

### B_D04_success — selected route

**P00 | 나여백 [S_D04_0041]**

가능 경로는 이 순서입니다. 9미터 정지선 상태의 창가 의자는 서쪽 공개 공간에 있고, 거기서 연회장 손님 출입문으로 나갑니다. 손님 통로를 돌아 서비스 접속부에 닿은 뒤, 수영장 접근 통로를 따라 상부 랜딩 통제선 방향까지 갈 수 있습니다. 이 과정에서 동쪽 작업실, 서비스 문, 칸막이를 통과할 필요가 없습니다. 직접 걸어 본 기록은 이 길이 실제로 이어진다는 것만 보여 주고, 누가 사용했는지는 증명하지 않습니다.

**P07 | 진새벽 [S_D04_0042]**

맞습니다. 잠긴 동쪽 구간은 그대로 잠겨 있어도 성립하는 경로입니다.

**P04 | 탁두철 [S_D04_0043]**

처음의 `잠긴 방에 갇혔다`는 인상은 방을 잘못 나눈 데서 생긴 거네요.

- Author state: **K04 획득:** 공용 창가 자리에서 손님 문을 나와 서비스 접속부를 거쳐 수영장 상부 랜딩 방향으로 이동 가능한 경로가 있다. 잠긴 동쪽 작업실은 장애가 아니며, 경로의 실제 사용은 미확정.

### After success — explicit return to P01

*공용 출구 동선 추론을 끝낸 뒤 여백·새벽·두철은 R05를 거꾸로 걸어 연회장으로 돌아온다. 새벽과 두철이 각자 업무로 빠지고, 여백은 곧바로 휴게실로 가서 모눈이 계속 봉만실과 함께 있었음을 확인한다.*

**P01 | 나모눈 [S_D04_0044]**

잠긴 문 안 열었어?

**P00 | 나여백 [S_D04_0045]**

안 열었어. 그런데도 바깥 연결부까지 갈 수 있는 길은 있었어.

**P01 | 나모눈 [S_D04_0046]**

그럼 `갈 수 있음` 표 하나 붙이면 되겠네. `갔음` 말고.

**P00 | 나여백 [S_D04_0047]**

맞아. 그 표를 그대로 두고 다음 사람 얘기를 들을 거야.

### B_D04_retry

**P00 | 나여백 [S_D04_0051]**

경로 선택은 남겨 두고, 닫힌 칸막이를 통과하는 조각이나 `가능=실행` 문장만 제거하겠습니다.

**P07 | 진새벽 [S_D04_0052]**

좋습니다. 공간 시험은 공간 결론까지만 쓰면 됩니다.

### Current revisit

**P00 | 나여백 [S_D04_0091]**

공용 출구 동선 가능성 결론은 `가능한 공용 경로`입니다. 나중에 누군가의 실제 위치와 결합하려면 별도 시간·목격 자료가 필요합니다.

---

## C_H_D04 — D04 힌트

### Context
- Place/cast: P00's notebook while the D04 state is active; no absent NPC is teleported into the hint.
- Entry: D04 unresolved/revisited. Selector checks K01/K03/E09, recent named error and K04-complete state.
- Exit/effects: hint only; no walking, unlock, E09 creation, K04 or 여유 change.
- E/S/K/B: held-source text may describe E09; missing-source text gives the currently allowed request to P07 without quoting an unheld card.
- Repeat/resume: interrupted route selection keeps its selected path pieces and recent error.

#### Deterministic selector (normative)
- One request returns one line. Priority: `K04 complete` → `missing prerequisite` → `recent named error at H3/H4` → `requested held-source level`.
- `K04 complete`, any H0–H4 → `S_H_D04_0043`.
- K03 missing → `S_H_D04_0001`; else K01 missing → `S_H_D04_0003`; else E09 missing → `S_H_D04_0002`, at any requested level.
- All held: H0 `S_H_D04_0004`; H1 `S_H_D04_0011`; H2 `S_H_D04_0021`; H3 `S_H_D04_0031`; H4 `S_H_D04_0042`.
- With all held, recent `route_crosses_closed_partition` at H3/H4 → `S_H_D04_0032`; recent `feasible_route_proves_observed_use` → `S_H_D04_0033`.

### H_D04_0

**If K03 missing**

**P00 | 나여백 [S_H_D04_0001]**

먼저 창가 목격이 한 사람의 연속 재실을 증명하지 않는다는 범위를 정리하세요. 그 뒤 진새벽에게 허가된 공용 출구 동선을 함께 걸어 달라고 요청할 수 있습니다.

**If E09 missing and K03 held**

**P00 | 나여백 [S_H_D04_0002]**

진새벽에게 허가된 공용 출구 동선을 직접 걸어 확인하고 싶다고 요청하세요. 모눈은 휴게실에 봉 선생님과 남기고, 성인끼리 연회장 손님 문→서비스 접속부→수영장 상부 랜딩 통제선까지만 실제로 걸어 봅니다.

**If K01 missing**

**P00 | 나여백 [S_H_D04_0003]**

칸막이가 9미터 정지선에 있을 때 북쪽 창가가 서쪽 공개 공간에 속한다는 구조부터 확인하세요. 출발 공간을 틀리면 경로가 잠긴 동쪽으로 잘못 들어갑니다.

**If all held**

**P00 | 나여백 [S_H_D04_0004]**

재료는 다 있습니다. 출입 동선 실측에서 실제로 걸은 문과 연결부를 출발부터 순서대로 선택하세요. 잠긴 서비스 문은 경로에 넣지 않습니다.

### H_D04_1

**If a required source is missing**

**P00 | 나여백 [S_H_D04_0012]**

아직 실제 동선을 걷지 않았다면 지도만 보고 답을 고르지 마세요. 먼저 창가가 공개 공간에 있었다는 구조와 목격의 한계를 정리하고, 진새벽과 허가된 공용 길을 직접 확인해야 합니다.

**If all required sources are held**

**P00 | 나여백 [S_H_D04_0011]**

구분할 지점은 `창가에서 어느 문으로 나가느냐`입니다. 9미터 정지선 상태의 창가는 공개 공간이므로 손님 문에 닿고, 그 문 바깥 공용 통로는 잠긴 동쪽 작업실과 별개입니다.

### H_D04_2

**If E09 held**

**P00 | 나여백 [S_H_D04_0021]**

출입 동선 실측에는 성인이 직접 걸어 확인한 `연회장 손님 문 → 서비스 접속부 → 수영장 상부 랜딩 통제선`이 있고, 동쪽 서비스 문은 잠긴 채 따로 표시돼 있습니다. 적힌 시간은 평소 걸음으로 잰 범위입니다.

**If E09 missing**

**P00 | 나여백 [S_H_D04_0022]**

지도만 보고 길을 확정하지 말고 창가 목격의 한계 결론 뒤 진새벽의 허가를 받아 실제 공용 동선을 걸으세요. 그 실측이 끝나야 경로 선택 자료가 생깁니다.

### H_D04_3

**If a required source is missing**

**P00 | 나여백 [S_H_D04_0034]**

필수 자료가 비어 있다면 지금은 사용자를 추측할 단계가 아닙니다. 빠진 구조 결론이나 실제 공용 동선 확인부터 끝내고, 그 뒤에도 `갈 수 있었음`까지만 답하세요.

**If all required sources are held and there is no recent named error**

**P00 | 나여백 [S_H_D04_0031]**

정답은 `잠긴 작업실을 통과하지 않아도 나갈 수 있다`까지입니다. 경로가 있다는 사실은 사용자를 알려 주지 않습니다. 손님 문→서비스 접속부→수영장 상부 랜딩 방향의 연결만 증명하세요.

**Recent error: route_crosses_closed_partition**

**P00 | 나여백 [S_H_D04_0032]**

방금 경로는 x9 칸막이를 통과했습니다. 창가가 있는 서쪽 공개 공간에서 바로 손님 문으로 나가야 합니다. 서비스 문은 동쪽 띠라서 쓰지 않습니다.

**Recent error: feasible_route_proves_observed_use**

**P00 | 나여백 [S_H_D04_0033]**

방금은 `갈 수 있음`을 `갔음`으로 바꿨습니다. 출입 동선 실측에는 특정 사람의 이동 목격이 없습니다. 이 길이 이어진다는 데까지만 말하세요.

### H_D04_4

**If required source missing**

**P00 | 나여백 [S_H_D04_0041]**

창가 목격의 한계가 아직 정리되지 않았다면 그 질문부터 끝내세요. 그 결론은 있지만 공용 동선 실측이 없다면 진새벽에게 허가된 길을 직접 함께 걸어 달라고 요청합니다. 아직 걷지 않은 경로의 세부 순서를 힌트가 먼저 채우지 않으며, 잠긴 동쪽 작업실은 열지 않습니다.

**If all held**

**P00 | 나여백 [S_H_D04_0042]**

정리하면 이렇습니다. `두 목격 때 창가 자리는 공개 공간에 있었고, 그 목격은 한 사람의 연속 재실을 증명하지 못한다. 직접 걸어 본 결과 창가에서 손님 문으로 나와 서비스 접속부를 거쳐 수영장 상부 랜딩 방향까지 갈 수 있었고, 동쪽 작업실은 잠긴 채였다. 따라서 이탈은 물리적으로 가능하지만 누가 그 길을 실제로 썼는지는 미확정이다.`

**If K04 already acquired**

**P00 | 나여백 [S_H_D04_0043]**

공용 길의 가능성은 이미 확인했습니다. 이제 그 길이 있다는 사실을 누군가의 죄로 바꾸지 말고, 방에서 확인된 정상 작업·목격 착오·약해진 알리바이를 따로 정리하세요.

---

## C_CH01_07 — 빈틈이 곧 죄는 아니다

### Context
- Place: L02 family rest area.
- Cast: P00, P01, P03.
- Entry: K04. P00 has already returned from the adult route walk and resumed direct supervision of P01. E10 may already be held; if not, P02's public album remains optional and does not block this scene.
- Exit: P03 states the fair alternative: weakened room alibi + feasible public route do not establish murder or actual route use. C_CH01_08 becomes the local-resolution scene.
- E/S/K/B: may refer to E10 only if held; reads K04. No Q statement changes here.
- Effects: no new E/K/B, no route use, no guilt finding.
- Repeat/resume: revisit preserves P03's objection; an optional E10 obtained later supplements but does not rewrite this exchange.

### Script

*휴게실로 돌아오자 차무록은 계약서 묶음 두 개를 탁자 끝에 내려놓고 스테이플러 심 통을 흔들어 본다. 통 안에는 새 심과 한 번 폈다가 다시 반듯하게 만든 심이 섞여 있다.*

**P03 | 차무록 [S_CH01_07_0001]**

이건 왜 새 심이랑 회수 심을 한 칸에 넣었습니까. 쓰임이 달라요.

**P01 | 나모눈 [S_CH01_07_0002]**

둘 다 스테이플러 심인데요.

**P03 | 차무록 [S_CH01_07_0003]**

그러니까 더 구분해야죠. 같은 모양이라고 같은 이력이 되는 건 아닙니다.

*무록은 자기가 방금 한 말을 알아차린 듯 여백 쪽을 본다.*

**P00 | 나여백 [S_CH01_07_0004]**

그 말은 지금 방 이야기에도 적용됩니다.

**P03 | 차무록 [S_CH01_07_0005]**

봉 사장님 진술 고친 건 들었습니다. 저를 창으로 계속 봤다는 말이 아니었다고요.

**P00 | 나여백 [S_CH01_07_0006]**

그리고 공용 손님 문에서 서비스 접속부 쪽으로 나가는 길도 물리적으로 열려 있었습니다.

*무록은 종이를 정렬하던 손을 멈춘다. 표정이 굳지만 목소리는 오히려 더 평평해진다.*

**P03 | 차무록 [S_CH01_07_0007]**

그럼 제가 방에 갇혀 있지 않았다는 건 알겠네요. 그런데 `나갈 수 있었다`가 `나가서 표 선생님을 만났다`는 뜻입니까?

**P00 | 나여백 [S_CH01_07_0008]**

아닙니다. 그 둘은 아직 다릅니다.

**P03 | 차무록 [S_CH01_07_0009]**

사진도 있죠. 행사 점검 전에 제가 서비스 접속부 쪽에 서 있던 거. 그건 숨길 일도 아니었습니다. 직원 동선 확인 때문에 그쪽을 오갔으니까요.

**P01 | 나모눈 [S_CH01_07_0010]**

그러면 방에 계속 있던 건 아니었네.

**P03 | 차무록 [S_CH01_07_0011]**

계속 있었다고 제가 말한 적은 없습니다. 봉 사장님이 그렇게 생각한 거죠. 그리고 제가 그 복도에 있었다고 해서 동쪽 끝까지 갔다는 것도 아닙니다.

**P00 | 나여백 [S_CH01_07_0012]**

맞습니다. 행사 사진이 있으면 `공개 점검 무렵 서비스 접속부 쪽에 있었다`는 장면을 확인할 수 있지만, 그 사진은 수영장 상부 랜딩 이동이나 사건 행동을 찍은 자료가 아닙니다.

**P03 | 차무록 [S_CH01_07_0013]**

그럼 기록도 그렇게 쓰세요. 알리바이가 약해졌다는 이유로 빈칸에 가장 나쁜 행동을 채우지 말고.

*무록은 회수 심 하나를 핀셋으로 집어 따로 작은 유리병에 옮긴다.*

**P03 | 차무록 [S_CH01_07_0014]**

빈칸은 빈칸입니다. 이 칸은 비워 두시면 안 된다는 말은 서류에나 쓰는 거고요.

**P01 | 나모눈 [S_CH01_07_0015]**

그 말 맨날 하는 사람도 빈칸을 둘 줄 아네.

**P03 | 차무록 [S_CH01_07_0016]**

사람 일에는 더 그래야죠.

*여백은 공용 출구 동선 가능성 결론 옆에 `가능 경로 ≠ 실제 사용`이라고 다시 적는다.*

**P00 | 나여백 [S_CH01_07_0017]**

그래서 지금은 방에 관한 세 가지를 분리해서 마무리하겠습니다. 누가 벽을 옮겼는지, 누가 무엇을 잘못 봤는지, 그리고 그 결과 누구의 알리바이가 약해졌는지.

### If E10 was not yet acquired

**P00 | 나여백 [S_CH01_07_0021]**

사진 자체는 아직 안 봤습니다. 봉 선생님 앨범을 확인하면 공개 점검 전 위치를 보조할 수 있지만, 그 사진이 없어도 공용 출구 동선 가능성 결론의 경로 가능성은 이미 별도로 성립합니다.

**P03 | 차무록 [S_CH01_07_0022]**

확인하세요. 사진이 있으면 있는 대로 보시면 됩니다. 다만 사진 밖을 사진이 찍었다고 하지 마십시오.

### Current revisit

**P03 | 차무록 [S_CH01_07_0091]**

제가 반박한 건 하나입니다. `방에 계속 있었다는 말이 틀렸다`와 `그래서 제가 사건 현장에 갔다` 사이에는 증거가 더 필요합니다.

**P00 | 나여백 [S_CH01_07_0092]**

그 반박은 현재 기록에 남아 있습니다. 마지막 정리에서도 그 빈칸을 억지로 채우지 않겠습니다.

---

## C_CH01_08 — 방이 틀렸다고 사람이 정해지지는 않는다

### Context
- Place: L02 supervision handoff → L03 public side → L02 reunion after the room resolution.
- Cast: L03 P00/P02/P05; L02 handoff/reunion P00/P01/P03.
- Entry: K04 + C_CH01_07. Before P00 leaves L02, P03 explicitly accepts same-place supervision of P01; P01 does not operate investigative equipment.
- Exit: D05 success → K05. P05 offers V02 for CH02 without revealing manual playback or any Q02-exclusive correction. P00 then returns to L02 and resumes direct supervision of P01.
- E/S/K/B: reads K02/K03/K04 in D05; no new E. V02 appointment state is set only after K05.
- Effects: K05 only through C_D05 success; no audio evidence is opened here.
- Repeat/resume: the three paper categories and D05 draft persist; if interrupted, P01 remains with P03 in L02 until P00 explicitly returns.

### Script — before D05

*휴게실에서 여백은 연회장으로 가기 전 모눈의 접수대 앞에 멈춘다. 차무록도 같은 탁자에서 계약서 묶음을 정리하고 있다.*

**P00 | 나여백 [S_CH01_08_0021]**

무록 씨, 제가 연회장에서 봉 선생님하고 해금 씨한테 방 조사 정리만 하고 올 동안 모눈이와 여기 같이 있어 주시겠습니까? 장비는 만지지 않고 접수대 안쪽에 있을 겁니다.

**P03 | 차무록 [S_CH01_08_0022]**

네. 저도 이 탁자에서 서류 정리할 겁니다. 모눈 씨가 다른 곳으로 이동해야 하면 기다렸다가 {playerName} 씨가 돌아온 뒤에 하겠습니다.

**P01 | 나모눈 [S_CH01_08_0023]**

나는 접수대 근무. 혼자 탐험 금지. 알겠어.

*여백은 세 사람이 같은 휴게실에 남아 있는 것을 확인하고 연회장으로 간다. 연회장에는 칸막이가 시험 전과 같은 x9에 고정돼 있다. 만실은 테이블 위에 `벽`, `목격`, `동선`이라고 쓴 종이 세 장을 펼쳐 둔다. 해금은 케이블 상자를 들고 음향 부스로 돌아가려다가 여백이 부르는 소리에 멈춘다.*

**P02 | 봉만실 [S_CH01_08_0001]**

내가 세 장으로 나눠 놨어요. 한 장에 다 쓰니까 자꾸 누가 누구 잘못인지 섞여서.

**P00 | 나여백 [S_CH01_08_0002]**

좋습니다. 벽을 실제로 옮긴 일, 봉 선생님 목격 정정, 그리고 밖으로 나갈 수 있었던 길을 따로 놓겠습니다.

**P05 | 소해금 [S_CH01_08_0003]**

저는 음향실 정리 중인데, 방 얘기 끝나면 한 가지 확인해 주세요. 어젯밤 늦게 나간 안내 목소리 때문에 시간 얘기가 또 꼬일 겁니다.

**P02 | 봉만실 [S_CH01_08_0004]**

그건 방부터 끝내고. 오늘은 한 번에 하나씩 틀립시다.

**P05 | 소해금 [S_CH01_08_0005]**

틀리려고 순서 정한 건 아닌데요.

**P00 | 나여백 [S_CH01_08_0006]**

지금은 방에서 확인된 사실과 아직 남은 사실을 나누겠습니다.

> **D05 진입:** `방에 관한 진술에서 확인된 일과 남은 일을 나누자.`

### After C_D05 success / K05

**P02 | 봉만실 [S_CH01_08_0011]**

그러면 벽은 두철 씨하고 내가 행사 전에 정상적으로 옮겼고, 내가 창에서 사람을 봤다고 너무 크게 말했고, 무록 씨는 그 자리에 계속 있었다고 증명된 건 아니고.

**P00 | 나여백 [S_CH01_08_0012]**

네. 거기에 공용 출구로 나갈 수 있었던 가능성까지 확인됐습니다. 하지만 그 경로를 누가 사건에 사용했는지는 이 장에서 정하지 않았습니다.

**P05 | 소해금 [S_CH01_08_0013]**

그럼 제 쪽 얘기를 봐야겠네요. 저는 어젯밤 20시 30분 안내가 나간 걸 압니다. 목소리를 들은 사람도 많고요.

**P00 | 나여백 [S_CH01_08_0014]**

그 목소리가 무엇을 증명하는지 확인하려면, 음향실에서 실제 진행표와 들을 수 있는 파일을 따로 봐야겠습니다.

**P05 | 소해금 [S_CH01_08_0015]**

음향 부스로 오세요. 제가 콘솔을 켜고, 리허설이랑 마이크 입력이 어떻게 다른지 먼저 보여드릴게요. 모눈이도 같이 오면 자기 의자 샘플까지만 들을 수 있게 하겠습니다. 다른 사람 음성은 허락 범위부터 확인하고요.

**P02 | 봉만실 [S_CH01_08_0016]**

아이 데리고 갈 거면 내가 여기 정리 끝나고 같이 이동 확인할게요. 혼자 장비 만지게 하지는 말고.

**P00 | 나여백 [S_CH01_08_0017]**

좋습니다. 방 문제는 여기까지 정리하고, 다음에는 늦게 들린 목소리가 실제로 무엇을 말해 주는지 음향 부스에서 확인하겠습니다.

*여백은 약속을 잡은 뒤 휴게실로 돌아간다. 차무록은 처음 자리에서 서류를 정리하고 있고 모눈은 분실물 접수표를 쓰고 있다.*

**P03 | 차무록 [S_CH01_08_0024]**

끝났습니까? 모눈 씨는 여기 있었습니다. 접수표 세 장 쓰고, 우산 하나 세워 둔 게 전부입니다.

**P00 | 나여백 [S_CH01_08_0025]**

고맙습니다. 모눈아, 이제 내가 다시 같이 있을게. 음향 부스는 해금 씨와 시간을 맞춰서 같이 가자.

- Author state: **V02 예약:** CH02에서 L07 음향 부스 방문 가능. 아직 E11/E12/E14의 비교 결론이나 Q02 정정은 발생하지 않는다.

### Current revisit / task-return wording

**Before D05 success**

**P02 | 봉만실 [S_CH01_08_0091]**

세 장은 그대로 있어요. `벽`, `목격`, `동선`. 누가 범인인지 쓰는 종이는 아직 없습니다.

**After K05**

**P05 | 소해금 [S_CH01_08_0092]**

방 정리는 끝났죠. 다음에 오실 곳은 음향 부스입니다. 지금 여기서 파일 내용을 대신 설명하지 않을게요. 직접 콘솔에서 구분해 봅시다.

*장면 중 역할 분리 추론을 열었다 닫아도 세 장의 분류 상태와 추리 초안은 유지된다. 방 구조·목격·이동 역할 분리 결론 성공 뒤에는 역할 분리 추론을 새 사건처럼 다시 실행하지 않는다.*

---

## C_D05 — 방에 관한 진술에서 확인된 일과 남은 일을 나누자

### Context
- Place: L03 public side, inside C_CH01_08.
- Cast: P00, P02, P05. P01 remains in L02 with P03 throughout the task.
- Entry: K02 + K03 + K04.
- Exit: success → K05 and returns control to C_CH01_08 for the V02 appointment and L02 reunion.
- E/S/K/B: uses K02/K03/K04; branches B_D05_incomplete, both named error branches, success, retry. No new evidence is created.
- Effects: resolves only the CH01 room strand; no culprit, route use, or audio truth is established.
- Repeat/resume: the three-category sheet and draft survive incomplete/wrong attempts; revisit after K05 summarizes the separation without rerunning the scene.

### Task setup

**P00 | 나여백 [S_D05_0001]**

같은 방 이야기 안에 서로 다른 종류의 일이 섞여 있었습니다. 실제 칸막이 작업, 목격의 과장, 그리고 그 목격으로 이익을 보던 알리바이. 확인된 것과 아직 열린 것을 구분하겠습니다.

> **D05:** `방에 관한 진술에서 확인된 일과 남은 일을 나누자.`

### Free clarification

**P02 | 봉만실 [S_D05_0002]**

내가 벽도 같이 밀고, 사람도 잘못 봤으니까 두 일이 한 덩어리처럼 보이는 거죠?

**P00 | 나여백 [S_D05_0003]**

네. 하지만 역할은 다릅니다. 벽을 실제로 움직인 사람, 목격을 잘못 확장한 사람, 그 잘못된 목격으로 `계속 방에 있었다`는 인상을 얻은 사람을 따로 적어야 합니다.

### B_D05_incomplete

*행사 전 칸막이 이동 결론/창가 목격의 한계 결론/공용 출구 동선 가능성 결론 중 하나가 없거나, 세 역할 중 하나가 빈 채 제출하려 하면 무료로 보류한다.*

**P00 | 나여백 [S_D05_0011]**

아직 `누가 벽을 옮겼는지`, `누가 무엇을 잘못 봤는지`, `그 결과 어떤 알리바이가 약해졌는지` 중 하나가 비어 있습니다. 그 부분의 조사를 먼저 끝내고 다시 정리하겠습니다.

*여유 변화 없음. 분류표는 유지된다.*

### B_D05_err_collective_guilt

**P00 | 나여백 [S_D05_0021]**

탁두철 씨는 벽을 옮겼고, 봉만실 선생님은 잘못 봤고, 차무록 씨는 그 알리바이의 이익을 받았습니다. 세 사람이 역할을 나눠 공모했다고 정리하겠습니다.

**P02 | 봉만실 [S_D05_0022]**

아니요. 내가 벽 민 건 행사 준비였고, 잘못 본 건 내 착오예요. 그 두 개를 누군가하고 짜고 했다는 증거는 없잖아요.

**P00 | 나여백 [S_D05_0023]**

각자 다른 사실에 등장한다는 이유만으로 하나의 공모로 묶었습니다. 공동 의도나 합의 자료가 없으니 그 결론은 뺍니다.

> 완결된 잘못된 전제로 제출했으므로 여유 `-2`.

### B_D05_err_all_rooms_unlocked

**P00 | 나여백 [S_D05_0031]**

공용 경로로 나갈 수 있었으니 결국 작업실도 잠기지 않았고, 방 전체가 자유롭게 통했다고 정리하겠습니다.

**P02 | 봉만실 [S_D05_0032]**

아니요. 동쪽 작업실 문은 잠긴 채였어요. 우리가 확인한 건 손님 문으로 바깥 연결부를 돌아갈 수 있었다는 거지, 잠긴 곳이 없었다는 게 아니에요.

**P00 | 나여백 [S_D05_0033]**

공용 출구 동선 가능성 결론을 `모든 문이 열려 있었다`로 넓혔네요. 동쪽 구간은 잠긴 채로 남기겠습니다.

> 완결된 잘못된 전제로 제출했으므로 여유 `-2`.

### B_D05_success — selected reconstruction

**P00 | 나여백 [S_D05_0041]**

확인된 일을 나누면 이렇습니다. 첫째, 탁두철 씨와 봉만실 선생님은 행사 전에 정상 작업으로 칸막이를 x9로 옮겼습니다. 둘째, 봉만실 선생님은 창에서 얼굴을 확인하지 못한 두 장면을 `차무록 씨가 계속 있었다`고 잘못 확장했고 그 부분을 정정했습니다. 셋째, 차무록 씨 재킷은 사람 없이 의자에 남을 수 있었고, 공개 공간의 손님 문에서 서비스 접속부·수영장 상부 랜딩 방향으로 나가는 경로도 물리적으로 가능했습니다. 그래서 차무록 씨의 `계속 재실` 인상은 성립하지 않습니다. 하지만 누가 재킷을 어떤 목적으로 남겼는지, 누가 그 경로를 실제로 썼는지, 표문식 씨의 죽음에 누가 관여했는지는 아직 열려 있습니다.

**P02 | 봉만실 [S_D05_0042]**

내가 한 일하고 잘못 본 일을 따로 써 놓으니, 적어도 내가 안 한 일까지 따라오진 않네요.

**P05 | 소해금 [S_D05_0043]**

그리고 방에서 빠져나갈 수 있었다면, 나중 시각을 증명한다고 생각했던 다른 것도 다시 봐야겠네요.

**P00 | 나여백 [S_D05_0044]**

맞습니다. 다음은 소리입니다. 하지만 방에서 얻은 결론을 소리의 정답으로 미리 쓰지는 않겠습니다.

- Author state: **K05 획득 — CH01 local resolution:**
  - 탁두철·봉만실의 칸막이 이동은 정상 행사 준비 작업.
  - P02의 연속 재실 확신은 잘못된 목격 확장.
  - P03의 재킷/창가 모습은 P03의 계속 재실을 증명하지 않음.
  - 공용 출구 경로는 가능하나 실제 사용·범행 주체는 미확정.
  - 다음 장에서 음향 부스를 다시 확인할 동기가 성립한다.

### B_D05_retry

**P00 | 나여백 [S_D05_0051]**

분류표는 그대로 둡니다. `같은 장면에 등장했다`를 `함께 범행했다`로 바꾸거나, `공용 길이 있다`를 `모든 방이 열렸다`로 넓힌 부분만 지우고 다시 정리하겠습니다.

**P02 | 봉만실 [S_D05_0052]**

그 정도면 나도 다시 읽어 볼게요. 내 잘못은 줄이지 말고, 남의 잘못도 덧붙이지 말고.

### Current revisit

**P00 | 나여백 [S_D05_0091]**

방 문제에 대한 정리는 끝났습니다. 벽 작업자, 잘못 본 목격자, 약해진 알리바이의 당사자는 구분됐지만 범행 주체는 아직 정해지지 않았습니다.

---

## C_H_D05 — D05 힌트

### Context
- Place/cast: P00's notebook during C_CH01_08; P02/P05 remain in L03 but hints do not make them reveal new facts.
- Entry: D05 unresolved/revisited. Selector checks K02/K03/K04, recent named error, and K05-complete state.
- Exit/effects: hint only; no K05, V02 appointment, evidence or 여유 change.
- E/S/K/B: missing-state text points to the actual earlier investigation without naming unseen future material; held-state text uses only established room conclusions.
- Repeat/resume: the three-category sheet and recent failed premise persist across interruption.

#### Deterministic selector (normative)
- One request returns one line. Priority: `K05 complete` → `missing prerequisite` → `recent named error at H3/H4` → `requested held-source level`.
- `K05 complete`, any H0–H4 → `S_H_D05_0043`.
- K02 missing → `S_H_D05_0001`; else K03 missing → `S_H_D05_0002`; else K04 missing → `S_H_D05_0003`, at any requested level.
- All held: H0 `S_H_D05_0004`; H1 `S_H_D05_0011`; H2 `S_H_D05_0021`; H3 `S_H_D05_0031`; H4 `S_H_D05_0042`.
- With all held, recent `collective_guilt` at H3/H4 → `S_H_D05_0032`; recent `all_rooms_unlocked` → `S_H_D05_0033`. Interruption preserves the three-category draft and uses the same priority.

### H_D05_0

**If K02 missing**

**P00 | 나여백 [S_H_D05_0001]**

어젯밤 칸막이를 실제로 누가, 언제, 어느 정지선으로 옮겼는지 작업표와 당사자 설명으로 먼저 확인하세요. 정상 작업과 사건 행동을 분리해야 합니다.

**If K03 missing**

**P00 | 나여백 [S_H_D05_0002]**

창가 목격이 차무록 씨의 연속 재실을 증명하지 않는다는 범위를 먼저 정하세요. 그 범위가 정리되면 진새벽에게 공용 동선을 실제로 확인해 달라고 요청할 수 있습니다.

**If K04 missing**

**P00 | 나여백 [S_H_D05_0003]**

잠긴 동쪽 작업실을 거치지 않고 손님 문에서 서비스 접속부를 거쳐 수영장 상부 랜딩 방향으로 갈 수 있는지 실제 동선 카드로 확인하세요. 여기서는 `가능`까지만 증명하면 됩니다.

**If all held**

**P00 | 나여백 [S_H_D05_0004]**

방 조사에 필요한 세 결론이 다 있습니다. 이제 사람 셋을 한 팀처럼 묶지 말고 `실제 작업`, `잘못된 목격`, `알리바이 수혜`, `아직 모르는 범행 행동` 네 칸으로 나누세요.

### H_D05_1

**If a prerequisite is missing**

**P00 | 나여백 [S_H_D05_0012]**

세 칸 가운데 비어 있는 사실이 있으면 먼저 그 조사로 돌아가세요. 벽을 실제로 옮긴 일, 목격이 어디까지 틀렸는지, 잠긴 작업실을 거치지 않는 공용 길의 가능성을 각각 확인해야 마지막 분류가 됩니다.

**If all prerequisites are held**

**P00 | 나여백 [S_H_D05_0011]**

행사 전 칸막이 이동 결론은 정당한 칸막이 작업, 창가 목격의 한계 결론은 연속 재실을 증명하지 못한 목격, 공용 출구 동선 가능성 결론은 가능한 공용 이동 경로입니다. 서로 다른 종류의 결론이라 하나의 공모 이야기로 합치면 안 됩니다.

### H_D05_2

**If all held**

**P00 | 나여백 [S_H_D05_0021]**

행사 전 칸막이 이동 결론에서 벽 이동자는 탁두철·봉만실, 창가 목격의 한계 결론에서 잘못 확장된 목격은 봉만실의 것, 그 잘못된 알리바이의 대상은 차무록입니다. 공용 출구 동선 가능성 결론은 누구든 사용할 수 있는 공용 경로의 가능성만 말합니다. 이 네 역할을 그대로 분리하세요.

**If a prerequisite is missing**

**P00 | 나여백 [S_H_D05_0022]**

비어 있는 조사부터 끝내세요. 벽 작업은 행사 전 칸막이 이력, 알리바이 범위는 창가 목격의 한계, 공용 경로는 진새벽과 실제로 걸어 본 길에서 확인할 수 있습니다. 아직 보지 않은 음향이나 사건 현장 자료는 필요하지 않습니다.

### H_D05_3

**If a prerequisite is missing**

**P00 | 나여백 [S_H_D05_0034]**

아직 한 칸이 비어 있다면 `누가 범인인가`로 메우지 마세요. 빠진 방 조사만 끝내고 돌아오면 됩니다.

**If all prerequisites are held and there is no recent named error**

**P00 | 나여백 [S_H_D05_0031]**

정답의 마지막 칸은 반드시 `아직 모름`이 남아야 합니다. 방 조사는 차무록의 완전한 재실 알리바이를 무너뜨리지만, 그가 실제 경로를 썼거나 범행했다는 행동 증거까지 주지는 않습니다.

**Recent error: collective_guilt**

**P00 | 나여백 [S_H_D05_0032]**

방금은 역할이 다르다는 사실을 공모로 묶었습니다. 정상 작업을 한 사람, 목격을 잘못한 사람, 그 목격으로 이익을 본 사람 사이에 합의 증거는 없습니다.

**Recent error: all_rooms_unlocked**

**P00 | 나여백 [S_H_D05_0033]**

방금은 공용 길이 있다는 사실을 `모든 방이 열림`으로 넓혔습니다. 동쪽 작업실은 잠긴 채입니다. 손님 문을 통해 우회할 수 있다는 공용 출구 동선 가능성 결론만 남기세요.

### H_D05_4

**If prerequisite missing**

**P00 | 나여백 [S_H_D05_0041]**

세 선행 결론 가운데 비어 있는 것부터 끝내세요. 행사 전 칸막이 이동이 없으면 작업 이력으로, 창가 목격의 한계가 없으면 그 추궁으로, 공용 출구 동선 가능성이 없으면 허가된 실측으로 돌아갑니다. 세 가지가 모두 갖춰지기 전에는 사람별 역할이나 최종 분류를 이 힌트가 대신 말하지 않습니다.

**If all held**

**P00 | 나여백 [S_H_D05_0042]**

이렇게 말할 수 있습니다. `탁두철과 봉만실은 행사 전에 정상적으로 칸막이를 x9로 옮겼다. 봉만실은 얼굴 없는 두 목격을 차무록의 연속 재실로 잘못 확장했다. 차무록 재킷은 의자에 남을 수 있고 공용 손님 문을 통한 외부 경로도 가능하다. 따라서 차무록의 방 알리바이는 성립하지 않지만, 누가 경로를 실제로 사용했고 누가 범행했는지는 아직 증명되지 않았다.`

**If K05 already acquired**

**P00 | 나여백 [S_H_D05_0043]**

방과 동선 문제는 여기까지입니다. 다음은 소해금이 제안한 음향 부스 약속을 확인할 차례예요. 늦게 들린 목소리를 사람의 늦은 생존과 바로 같은 것으로 보지 말고, 실제 음향 자료부터 확인하세요.

---

## C_CH01_O1 — 의자의 민원인은 누구인가

### Context
- Place: L02 family rest area.
- Cast: P00, P01.
- Entry: after Q01 correction; optional/skippable. P00 is physically with P01.
- Exit: returns to the current CH01 hub; no mandatory investigation is blocked by skipping.
- E/S/K/B: reads B_PR_02 for one of two callbacks; no E/K/S correction is created.
- Effects: only relationship/agency memory.
- Repeat/resume: the selected B_PR_02 history is recalled once; revisit uses the completed line and never chooses the other history.

### Script

*모눈의 분실물 접수대에는 높은 의자에 대한 민원표가 새로 놓여 있다. 민원인 칸에는 `의자 본인?`이라고 쓰였다가 물음표가 세 번 덧그어져 있다.*

**P00 | 나여백 [S_CH01_O1_0001]**

민원인이 의자예요?

**P01 | 나모눈 [S_CH01_O1_0002]**

처음엔 그렇게 썼는데, 의자가 진짜 싫다고 한 건 아니잖아. 사람들이 자꾸 누구 자리라고 정한 거지.

**P00 | 나여백 [S_CH01_O1_0003]**

그럼 민원 내용은 뭔데?

**P01 | 나모눈 [S_CH01_O1_0004]**

`나를 사람 대신 쓰지 마세요.` 근데 이것도 내가 의자 대신 쓴 말이라서 좀 이상해.

### If B_PR_02=environment_first

**P00 | 나여백 [S_CH01_O1_0011]**

처음에 네가 사람 목소리보다 주변 소리부터 모으겠다고 했던 것처럼, 물건은 관찰할 수 있어도 사람 뜻까지 대신 적으면 안 되겠네.

**P01 | 나모눈 [S_CH01_O1_0012]**

응. 의자 삐걱이는 건 녹음해도, `의자가 화났다`는 건 내가 붙인 말이라고 써야 돼.

### If B_PR_02=ask_voice_later

**P00 | 나여백 [S_CH01_O1_0021]**

처음에 사람 목소리는 나중에 허락받고 쓰겠다고 했지. 물건한테 허락을 받을 수 없다고 해서, 물건이 사람 대신 말한 것처럼 써도 된다는 건 아니고.

**P01 | 나모눈 [S_CH01_O1_0022]**

응. 내가 붙인 설명이면 `모눈 생각`이라고 적을래.

### Merge

**P01 | 나모눈 [S_CH01_O1_0031]**

그럼 민원인은 `나모눈`이고, 의자는 참고인으로 할까?

**P00 | 나여백 [S_CH01_O1_0032]**

그게 더 정직하네.

*모눈은 민원인 칸을 자기 이름으로 고치고, 의자 옆에는 `본인 발언 없음`이라고 적는다.*

### Current revisit

**P01 | 나모눈 [S_CH01_O1_0091]**

의자 민원은 끝났어. 내가 쓴 말은 내 말이라고 표시했어. 사건 증거로 들어가는 건 아니야.

---

## C_CH01_O2 — 미뤄 둔 수리의 가격

### Context
- Place: L03 public side after V01/D02.
- Cast: P00, P02, P04.
- Entry: optional after the supervised partition test; P01 is not required and is not used as an investigative helper.
- Exit: returns to the current CH01 hub; no mandatory clue is gated here.
- E/S/K/B: may reference already-held E04/K02 only as established work history; no new E/K/B.
- Effects: ordinary debt/maintenance relationship only; no guilt or document proof.
- Repeat/resume: conversation completes once; revisit only distinguishes the repair bill from the incident work log.

### Script

*두철은 칸막이 바퀴 덮개를 닫고 오래된 수리 청구서 묶음을 고무줄로 감는다. 만실이 맨 위 종이를 보자마자 뒤집는다.*

**P02 | 봉만실 [S_CH01_O2_0001]**

그건 왜 아직 갖고 있어요.

**P04 | 탁두철 [S_CH01_O2_0002]**

돈 못 받은 종이는 잘 안 버려집니다. 종이가 저보다 기억력이 좋아요.

**P02 | 봉만실 [S_CH01_O2_0003]**

못 준 게 아니라 미룬 거죠.

**P04 | 탁두철 [S_CH01_O2_0004]**

세 번 미루면 못 준 쪽으로 분류합니다. 제 장부는 냉정해서.

**P00 | 나여백 [S_CH01_O2_0005]**

칸막이 수리도 여기 있습니까?

**P04 | 탁두철 [S_CH01_O2_0006]**

바퀴 교체 권고가 두 번, 실제 교체는 한 번 미뤘고, 어제는 행사 전에 움직임 확인만 했습니다. 지금 걸리는 건 오늘 발견해서 손보는 중이고요.

**P02 | 봉만실 [S_CH01_O2_0007]**

이 호텔은 팔리기 직전에 제일 성실하게 고장 나요.

**P04 | 탁두철 [S_CH01_O2_0008]**

아니요. 오래전부터 고장 났는데 사장님이 이제 성실하게 보고 계신 겁니다.

*만실이 대꾸하려다 청구서 한 장의 접힌 모서리를 펴 준다.*

**P02 | 봉만실 [S_CH01_O2_0009]**

이건 매각 정리할 때 같이 줍시다. 사건하고 상관없는 빚까지 없어지는 건 아니니까.

**P04 | 탁두철 [S_CH01_O2_0010]**

그 말 녹음해도 됩니까?

**P00 | 나여백 [S_CH01_O2_0011]**

저는 지금 작업 기록만 합니다. 계약 약속은 두 분이 문서로 남기세요.

*이 장면은 기존 칸막이 작업표/행사 전 칸막이 이동 결론의 내용을 바꾸지 않고, 새로운 사건 증거를 생성하지 않는다.*

### Current revisit

**P04 | 탁두철 [S_CH01_O2_0091]**

수리비 얘기는 수리비 얘기입니다. 어젯밤 칸막이 이동 기록은 이미 칸막이 작업표로 따로 남아 있어요.

---

## C_CH01_O3 — 스테이플러 심의 퇴근 절차

### Context
- Place: L01 reception.
- Cast: P00, P03.
- Entry: optional after C_CH01_07; P00 walks from L02 and no child handoff is implied by this optional scene. If P01 is currently under P00's care, she remains with P00 in the public reception area but has no investigative role.
- Exit: returns to the current CH01 hub; no mandatory clue or financial proof is exclusive here.
- E/S/K/B: no new E/K/B and no Q statement changes.
- Effects: ordinary manager habit and document-return courtesy only.
- Repeat/resume: return signature is not repeated; revisit recalls only that it was completed.

### Script

*여백이 계약서 묶음을 돌려주러 현관·접수대에 오자 무록은 접수대 아래에서 투명한 병 세 개를 꺼낸다. `새것`, `펴서 재사용`, `정말 버림`이라고 적혀 있다.*

**P00 | 나여백 [S_CH01_O3_0001]**

정말 세 종류로 나눕니까?

**P03 | 차무록 [S_CH01_O3_0002]**

두 종류로 나누면 두 번째 병이 너무 빨리 찹니다. `정말 버림` 기준이 생각보다 높아요.

**P00 | 나여백 [S_CH01_O3_0003]**

이건 재고 절약입니까, 취미입니까?

**P03 | 차무록 [S_CH01_O3_0004]**

업무 습관입니다. 취미라고 하면 제가 즐기는 것 같잖습니까.

*무록은 계약서에서 휘어진 심 하나를 빼다가 종이가 찢어질 뻔하자 손을 멈춘다.*

**P03 | 차무록 [S_CH01_O3_0005]**

이건 빼지 말죠. 종이를 보존하려다 종이를 망치면 순서가 틀린 겁니다.

**P00 | 나여백 [S_CH01_O3_0006]**

그 판단은 동의합니다.

**P03 | 차무록 [S_CH01_O3_0007]**

그리고 이 계약서 반환 칸에 서명 부탁드립니다. 돌려받았다는 사실만 확인하는 칸입니다. 내용에 동의한다는 칸 아니고요.

**P00 | 나여백 [S_CH01_O3_0008]**

범위를 먼저 말해 주니 좋네요.

**P03 | 차무록 [S_CH01_O3_0009]**

그 칸은 비워 두시면 안 됩니다.

*여백이 서명하고 펜을 내려놓자 무록은 휘어진 심을 `정말 버림` 병에 넣는다. 잠시 고민하다 병을 다시 열고 `펴서 재사용` 쪽으로 옮긴다.*

**P00 | 나여백 [S_CH01_O3_0010]**

방금 판정이 바뀌었네요.

**P03 | 차무록 [S_CH01_O3_0011]**

증거가 추가됐습니다. 아직 한 번 더 펼 수 있겠어요.

*그 말은 이 장면에서는 스테이플러 심에 대한 농담 섞인 업무 습관일 뿐, 사건의 범행이나 문서 변조를 예고하는 단서로 처리하지 않는다.*

### Current revisit

**P03 | 차무록 [S_CH01_O3_0091]**

반환 서명은 이미 끝났습니다. 다시 서명할 필요 없습니다. 스테이플러 심 분류도 사건 기록에는 들어가지 않습니다.

---

## CH01 completion state

- Assigned CH01 core, optional, D/Q, hint, and revisit units are all defined above.

**P00 | 나여백 [S_CH01_END_0001]**

방은 범인을 가두고 있지 않았습니다. 우리가 잘못 붙인 방 이름과, 너무 크게 말한 목격이 사람을 가둬 놓고 있었어요. 이제 늦게 들린 목소리가 무엇을 증명하는지 확인하겠습니다.

- Author state: 다음 핵심 진입: **CH02 — 남아 있던 목소리 / C_CH02_01**
