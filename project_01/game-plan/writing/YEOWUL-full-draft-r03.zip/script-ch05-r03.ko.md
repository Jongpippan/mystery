# CH05 — 창 너머의 두 사람

- Packet: `YEOWUL-FULL-v3`
- Revision: `r03`
- Status: `draft`
- Coverage: complete CH05 assignment — `C_CH05_01..08`, `C_CH05_O1..O3`, `C_D21..D25`, `C_Q05`, `C_H_D21..D25`, `C_H_Q05`, `C_H_V05`
- Preceding continuity: focused CH04 r03 with K20; P05 requested a controlled sightline check without yet retracting S_Q05_v1. P01 remains a child and is never brought to L09.

## C_CH05_01 — 같이 가지 않는 조사

### Context
- Place: L02
- Cast: P00, P01, P02, P07
- Entry: K20 / V51 request
- Exit: P01 supervision explicitly begins; adult inspection route authorized
- World effects: V51 begins; no E yet
- Supervision: P02 explicitly accepts direct supervision of P01 in L02 until P00 returns; P01 never enters L07/L09
- Repeat/resume: if site access is interrupted, resume from the last cleared adult waypoint without moving P01

### Script

*진새벽이 휴게실 탁자 위에 `성인 현장 확인`이라고 적힌 카드를 놓는다. 모눈은 그 카드를 자기 쪽으로 끌어오려다가 여백이 손으로 막는다.*

**P01 | 나모눈 [S_CH05_01_0001]**

이번엔 나도 보는 거 아니야? 계속 휴게실만 보고 있잖아.

**P00 | 나여백 [S_CH05_01_0002]**

이번 장소는 네가 갈 수 없는 보수 구역이야. 네가 도움이 안 돼서가 아니라 안전선이 다른 거야.

**P01 | 나모눈 [S_CH05_01_0003]**

도움 되는 건 다 어른들 위험한 데 있고, 나는 안전해서 도움이 안 되는 느낌이야.

**P07 | 진새벽 [S_CH05_01_0004]**

그건 제가 고쳐 말할게요. 이번 조사는 `위험한 곳을 보는 사람`이 필요한 게 아니라, 어른이 가서 위험을 확인하고 돌아오는 일입니다. 네 역할을 미끼로 만들지 않을 겁니다.

**P02 | 봉만실 [S_CH05_01_0005]**

모눈이는 나랑 있어요. 우산 번호 다시 붙이는 거 도와줘. 대신 사람한테 방 번호 붙이지 말고.

**P01 | 나모눈 [S_CH05_01_0006]**

사람은 분실물 접수 안 해.

**P00 | 나여백 [S_CH05_01_0007]**

좋아. 내가 어디까지 봤는지 돌아와서 설명할게. 네가 전날 직접 들은 공개 신호는 나중에 시간 순서를 맞출 때만 쓰자.

*여백과 새벽이 음향 부스 방향으로 나간다. 모눈은 휴게실에 남고 감독 상태가 기록된다.*

---

## C_H_V05 — V05 시야 확인 재방문 힌트

### Context
- Place: L02→L07/L09 / help overlay
- Cast: P00 guidance
- Entry: K20 and P05 sightline request; V51 not joined, running or completed
- Exit: routes to supervision, adult escort, pane/notebook inspection or secured test without culprit disclosure
- State keys: first request / supervision missing / adult route active / E40 missing / E41 missing / E42 missing / test pending / interrupted / completed

#### Deterministic selector (normative)
- Return **one Korean utterance only** for each hint request; never concatenate state overlays.
- Priority: `V51 complete` → `first request` → `P01 supervision not yet handed to P02` → `interrupted adult route` → `missing E40` → `missing E41` → `missing E42` → `requested current level`. A higher requested H level never skips a missing physical step.
- `V51 complete`, any H0–H4 → `S_H_V05_0091`.
- Before the visit is requested, any H0–H4 → `S_H_V05_0002`.
- Visit requested but P01 supervision is not explicitly in P02's hands, any H0–H4 → `S_H_V05_0011`.
- Adult route interrupted after a safe handoff, any H0–H4 → `S_H_V05_0022`.
- E40 missing, any H0–H4 → `S_H_V05_0032`; else E41 missing → `S_H_V05_0033`; else E42 missing → `S_H_V05_0042`.
- With E40/E41/E42 held and V51 not complete: H0 `S_H_V05_0001`; H1 `S_H_V05_0012`; H2 `S_H_V05_0021`; H3 `S_H_V05_0031`; H4 `S_H_V05_0041`. `S_H_V05_0041` tells the player to finish Q05 before the safe action comparison and does not reveal the correction.


### H_V05_0
**P00 | 나여백 [S_H_V05_0001]**

아직 현장 확인을 요청하지 않았다면 휴게실의 새벽 경위에게 해금 씨가 부탁한 시야 확인을 요청합니다. 이미 약속했다면 마지막으로 확인한 성인 이동 단계부터 이어 갑니다.

#### State — first request
**P00 | 나여백 [S_H_V05_0002]**

먼저 새벽 경위에게 `반투명 창에서 실제로 어디까지 보이는지만 안전하게 확인하고 싶다`고 요청하겠습니다.

### H_V05_1
**P00 | 나여백 [S_H_V05_0011]**

현장으로 가기 전에 모눈이를 누가 맡는지 분명히 해야 합니다. 만실 씨가 휴게실에서 직접 감독을 받아야 성인 조사팀이 이동합니다.

#### State — supervision already set
**P00 | 나여백 [S_H_V05_0012]**

모눈이는 만실 씨와 휴게실에 남아 있습니다. 이제 저와 새벽 경위만 성인 통제 구역으로 이동하면 됩니다.

### H_V05_2
**P00 | 나여백 [S_H_V05_0021]**

성인 이동은 부스와 새벽 경위가 장벽을 설치한 상부 랜딩까지만입니다. 게이트 안쪽이나 아래 수영장으로 내려가지 않습니다.

#### State — route interrupted
**P00 | 나여백 [S_H_V05_0022]**

중간에 돌아왔다면 이미 확인한 통제선은 다시 밟지 않고, 다음 미확인 지점에서 이어 갑니다.

### H_V05_3
**P00 | 나여백 [S_H_V05_0031]**

부스에서는 맑은 연회장 창과 반투명 직원통로 창을 따로 보고, 해금 씨가 당시 적은 접힌 수첩은 요청해서 엽니다.

#### State — missing pane test
**P00 | 나여백 [S_H_V05_0032]**

창 실측이 없다면 두 창의 위치와 반투명 창의 관찰 거리부터 확인합니다. 사람 이름을 맞히는 시험이 아닙니다.

#### State — missing notebook
**P00 | 나여백 [S_H_V05_0033]**

수첩을 아직 안 봤다면 해금 씨에게 당시 메모를 보여 달라고 요청합니다. 메모도 해금 씨 한 사람의 관찰 기록이라는 점을 유지합니다.

### H_V05_4
**P00 | 나여백 [S_H_V05_0041]**

창 실측과 게이트 위치를 확인해 시야 한계를 먼저 정하고, 해금 씨의 현재 진술과 수첩을 대조합니다. 정정이 끝난 뒤에만 장벽 뒤에서 헛디딤·부축·밀침의 **보이는 차이**를 안전하게 비교합니다. 얼굴이나 범인은 이 절차로 나오지 않습니다.

#### State — missing E42
**P00 | 나여백 [S_H_V05_0042]**

게이트 상태를 아직 확인하지 않았다면 새벽 경위 장벽 밖에서 경첩·경고표·마른 랜딩만 확인하세요. 위험 동작은 하지 않습니다.

#### State — completed
**P00 | 나여백 [S_H_V05_0091]**

시야 확인 방문에 필요한 창·수첩·게이트와 안전 비교는 모두 끝났습니다. 현재 남은 D/Q를 이어 가면 됩니다.

## C_CH05_02 — 맑은 창과 흐린 창

### Context
- Place: L07
- Cast: P00, P05, P07
- Entry: V51 adult access; CH04_08 request only, no Q05 correction yet
- Exit: E40/E41 acquired; sole live S_Q05_v1 defined; objective opens
- World effects: D21 awaits E42 from C_CH05_03
- Supervision: P01 remains in L02 with P02
- Q discipline: P05's denial is a current defended statement here; E43/contact/fall/cue bounds remain exclusive to S_Q05_v2
- Repeat/resume: after S_Q05_v1 capture, revisit shows it as current live statement until Q05 succeeds; E41 is not reacquired

### Script

*부스 안에서 해금이 연회장 쪽 큰 맑은 창을 가리킨 뒤, 반대편 위쪽의 반투명 관찰창으로 손을 옮긴다.*

**P05 | 소해금 [S_CH05_02_0001]**

이쪽 맑은 창으로는 전날 공개 테이블이 보였어요. 저쪽은 직원 통로 쪽이고 유리가 흐립니다. 둘을 같은 창으로 생각하면 제가 본 것보다 훨씬 많이 본 사람이 돼요.

**P00 | 나여백 [S_CH05_02_0002]**

20시 15분부터 22분 사이 제가 해금 씨를 계속 볼 수 있었던 건 이 맑은 창과 부스의 낮은 안전 조명 덕분이었습니다. 지금 확인하는 건 반대편 반투명 창의 범위고요.

**P07 | 진새벽 [S_CH05_02_0003]**

맞습니다. 주조명이 잠깐 꺼졌을 때도 부스 안 낮은 안전 조명은 유지됐습니다. 그 조명이 수영장 통로까지 비춘 건 아니고, 공개 자리의 해금 씨 위치만 계속 보이게 했죠. 두 창의 거리와 관찰점을 따로 재겠습니다.

#### E40 — 부스 창 실측

> 맑은 연회장 창과 별도의 반투명 직원통로 창. 표시된 성인 위치에서 반투명 창 너머 **사람 수와 큰 전후 움직임**은 구별 가능. 얼굴·표정·의복 색은 신뢰할 수 없음. 공개 테이블/부스의 낮은 안전 조명은 정전 중 봉만실과 소해금의 위치를 계속 보이게 했지만 수영장 상부 랜딩 쪽 사건 위치는 비추지 않음.

**P00 | 나여백 [S_CH05_02_0010]**

해금 씨, 수첩을 보기 전에 현재 진술부터 확인하겠습니다. 그날 반투명 창 쪽 사람 움직임을 봤습니까?

**P05 | 소해금 [S_Q05_v1]**

그날 창에 비친 사람 움직임은 보지 못했어요.

*해금은 대답하고도 수첩 쪽을 보지 않는다. 여백이 `그때 적어 둔 메모가 있으면 같이 보고 싶다`고 요청하자, 해금이 진행표 밑에 접힌 작은 수첩을 꺼낸다.*

#### E41 — 접힌 음향 수첩

> `둘. 앞으로. 두 손. 말하지 못함.`  
> 이름, 외투 색, 정확한 시각은 적혀 있지 않음. 소해금이 10월 21일 리셋 무렵 자기 관찰을 적은 메모.

**P05 | 소해금 [S_CH05_02_0004]**

제가 쓴 건 맞아요. 지우지도 않았고요. 그런데 지금은... 제가 이걸 어떻게 말해야 할지 모르겠습니다.

**P00 | 나여백 [S_CH05_02_0005]**

수첩도 해금 씨가 적은 같은 관찰입니다. 두 번째 목격자로 세지 않겠습니다. 먼저 이 창에서 무엇이 보이고 무엇이 안 보이는지 확인한 뒤, 지금 말씀과 메모의 차이를 다시 묻겠습니다.

> **Objective:** `목격된 움직임과 보지 못한 부분을 구분하자.`

## C_CH05_03 — 열려 있던 보수문

### Context
- Place: L09
- Cast: P00, P07, P04
- Entry: V51; P01 remains L02
- Exit: E42 acquired; D21 eligible
- World effects: temporary barrier is present and visually distinct from Oct21 state
- Supervision: P01 remains in L02 with P02; no child route to L09 exists
- Repeat/resume: barrier/gate inspection resumes from the unchecked item; the later barrier is never mistaken for Oct21 evidence

### Script

*진새벽이 설치한 임시 장벽 밖에서 세 사람은 상부 랜딩만 본다. 빈 수영장 아래로 내려가는 안전문에는 접근하지 않는다. 원래 경고표 `보수 중 — 통행 금지`가 그대로 남아 있고, 새 장벽에는 `10/22 경찰 설치`가 따로 적혀 있다.*

#### E42 — 열린 보수문

> 경첩과 열린 유지보수 게이트, 기존 경고표, 마른 랜딩 바닥. 새 임시 장벽은 사후 설치임이 명확히 표시된다.

**P04 | 탁두철 [S_CH05_03_0001]**

게이트는 제가 오후 보수할 때 열었습니다. 작업 멈추고 닫았어야 했는데 못 닫았습니다.

**P00 | 나여백 [S_CH05_03_0002]**

그 책임은 기록합니다. 하지만 열린 게이트 자체가 누가 사람을 밀었다는 증거는 아닙니다.

**P04 | 탁두철 [S_CH05_03_0003]**

알아요. 그래도 제가 열어 둔 건 제 잘못입니다. 그걸 살인 아니라고 말하면서 없애고 싶진 않습니다.

**P07 | 진새벽 [S_CH05_03_0004]**

좋습니다. 시야 실험은 이 장벽 밖 위치에서만 합니다. 실제 추락 동작은 재연하지 않습니다.

---

## C_D21 — 그 창에서 구별할 수 있는 것과 없는 것은?

### Context
- Place: L07
- Cast: P00, P05, P07
- Entry: E40/E42
- Exit: K21; Q05 eligible with E41
- Repeat/resume: keep the visible/not-visible split and latest error

### Script

**P00 | 나여백 [S_D21_0001]**

부스 창 실측의 창 실측과 열린 보수문의 실제 위치를 연결해, 목격자가 볼 수 있었던 범위를 먼저 정하겠습니다.

> **D21:** `그 창에서 구별할 수 있는 것과 없는 것은?`

### B_D21_incomplete
**P00 | 나여백 [S_D21_0011]**

부스 창 실측과 열린 보수문을 둘 다 확인해야 합니다. 하나가 없으면 먼저 그 관찰 조건부터 확인하겠습니다.

### B_D21_err_silhouette_identifies_person
**P00 | 나여백 [S_D21_0021]**

실루엣의 키와 자세로 창 너머 사람이 차무록 씨라고 식별할 수 있습니다.

**P05 | 소해금 [S_D21_0022]**

저도 그렇게 자신 있게 말할 수 없어요. 얼굴도 안 보였고 색도 흐렸습니다. 제가 본 건 사람 수랑 큰 동작 정도예요.

> 여유 `-2`.

### B_D21_err_nothing_was_visible
**P00 | 나여백 [S_D21_0031]**

유리가 흐렸으니 아무 움직임도 볼 수 없었습니다.

**P07 | 진새벽 [S_D21_0032]**

부스 창 실측 실측에서는 성인 두 사람의 수와 큰 전후 이동은 구별됐습니다. 보이지 않는 것과 보이는 것을 둘 다 남기세요.

> 여유 `-2`.

### B_D21_success
**P00 | 나여백 [S_D21_0041]**

부스 창 실측/열린 보수문 조건에서는 반투명 창 너머 **사람 수와 큰 움직임**은 구별할 수 있지만, 얼굴과 의복 색으로 사람을 특정할 수는 없습니다. 따라서 이후 진술은 행동 범위로 검증하되 신원은 별도 증거가 필요합니다.

- Author state: **K21 acquired. Q05 eligible with E41.**

### B_D21_retry
**P00 | 나여백 [S_D21_0081]**

실루엣을 신원으로 바꾸거나 반대로 전부 무효화하지 않고, `보이는 특징 / 안 보이는 특징` 두 칸으로 다시 정리합니다.

### Current revisit
**P00 | 나여백 [S_D21_0091]**

반투명 창에서 보이는 것과 안 보이는 것의 한계는 행동을 볼 수 있다는 결론과 신원은 못 본다는 한계를 동시에 남깁니다.

---

## C_H_D21 — D21 힌트

### Context
- Place: L07 / reasoning help
- Cast: P00 guidance
- Entry: D21 available or interrupted
- Exit: state-selected return
- State keys: missing E40 / missing E42 / all-held / identity error / nothing-visible error / interrupted / K21-complete

#### Deterministic selector (normative)
- Return **one Korean utterance only**. Priority: `K21 complete` → `missing prerequisite` → `recent named error (H3/H4 only)` → `requested all-held level`. Interruption does not outrank a missing source.
- `K21 complete`, any H0–H4 → `S_H_D21_0091`.
- E40 missing, any H0–H4 → `S_H_D21_0002`; else E42 missing → `S_H_D21_0003`.
- With E40/E42 held and recent `silhouette_identifies_person`, H3/H4 → `S_H_D21_0032`; recent `nothing_was_visible`, H3/H4 → `S_H_D21_0033`.
- With both held: H0 `S_H_D21_0004`; H1 `S_H_D21_0011`; H2 `S_H_D21_0021`; H3 `S_H_D21_0031`; H4 `S_H_D21_0041`.


### H_D21_0
**P00 | 나여백 [S_H_D21_0001]**

창 실측과 게이트 관찰 위치가 모두 있어야 합니다. 빠진 쪽만 먼저 확인하겠습니다.

#### State — missing E40
**P00 | 나여백 [S_H_D21_0002]**

부스의 맑은 창과 반투명 창을 실제 위치에서 구분하고, 반투명 창 너머 성인 실루엣의 수·큰 움직임이 보이는지부터 재세요.

#### State — missing E42
**P00 | 나여백 [S_H_D21_0003]**

수영장 상부 랜딩의 열린 게이트와 안전 장벽 밖 관찰 위치를 먼저 확인하세요. 게이트 안으로 들어갈 필요는 없습니다.

#### State — all held
**P00 | 나여백 [S_H_D21_0004]**

두 조건이 모두 있습니다. `보이는 것: 사람 수·큰 전후 움직임 / 안 보이는 것: 얼굴·옷 색`으로 나누면 됩니다.

### H_D21_1
**P00 | 나여백 [S_H_D21_0011]**

흐린 창에서도 큰 움직임은 남지만 얼굴과 색은 사라집니다. 그 중간 범위를 그대로 쓰세요.

### H_D21_2
**P00 | 나여백 [S_H_D21_0021]**

창 실측은 관찰 능력, 게이트 기록은 실제 위치 조건입니다. 어느 쪽도 사람 이름을 알려 주지 않습니다.

### H_D21_3
**P00 | 나여백 [S_H_D21_0031]**

실루엣을 차무록이라고 지정하는 것도, 유리가 흐리니 아무것도 안 보였다고 하는 것도 과합니다.

#### State — recent identity error
**P00 | 나여백 [S_H_D21_0032]**

방금은 큰 실루엣을 신원으로 바꿨습니다. 얼굴·색이 안 보였다는 한계를 다시 넣으세요.

#### State — recent nothing-visible error
**P00 | 나여백 [S_H_D21_0033]**

방금은 흐린 유리를 `완전히 안 보임`으로 바꿨습니다. 수와 전후 움직임은 실제 실측에서 구별됐습니다.

### H_D21_4
**P00 | 나여백 [S_H_D21_0041]**

저라면 `반투명 창에서는 사람 수와 큰 전후 움직임은 볼 수 있지만 얼굴과 옷 색으로 신원을 정할 수 없다`고 정리하겠습니다.

#### State — interrupted
**P00 | 나여백 [S_H_D21_0042]**

중단했다면 `보이는 것 / 안 보이는 것` 두 칸에서 비어 있는 쪽만 이어 적습니다.

#### State — complete
**P00 | 나여백 [S_H_D21_0091]**

시야 한계는 이미 정리했습니다. 이제 해금 씨의 현재 `움직임을 못 봤다`는 진술과 당시 수첩을 대조할 수 있습니다.

## C_Q05 — 수첩이 숨긴 게 아니라 사람이 숨긴 말

### Context
- Place: L07
- Cast: P00, P05, P07
- Entry: live S_Q05_v1 + E41 + K21
- Exit: sole S_Q05_v2, E43/KQ05
- Exclusivity: advance/two-arm/backward-fall/cue-reset correction first appears in S_Q05_v2
- Repeat/resume: after success use corrected current account; E41 and E43 remain one witness source

### Entry states
- Required: S_Q05_v1 + E41 + K21
- Success creates E43/KQ05; E41 and E43 are one witness source, not two.

### Script

**P00 | 나여백 [S_Q05_0001]**

해금 씨, 처음에는 움직임을 보지 못했다고 했습니다. 그런데 접힌 음향 수첩에는 `둘, 앞으로, 두 손`이 적혀 있습니다. 신원을 요구하지 않고, 실제로 본 움직임 범위만 다시 묻겠습니다.

- Author state: **Q05:** `움직임을 보지 못했다는 말과 수첩의 기록을 비교하자.`

### B_Q05_incomplete
**P00 | 나여백 [S_Q05_0011]**

접힌 음향 수첩과 반투명 창에서 보이는 것과 안 보이는 것의 한계가 필요합니다. 둘 중 하나가 없으면 먼저 확인한 뒤 다시 묻겠습니다.

### B_Q05_err_notebook_is_second_witness
**P00 | 나여백 [S_Q05_0021]**

해금 씨 진술과 수첩 기록이 서로 독립된 두 목격이므로 같은 행동이 두 번 확인됐습니다.

**P07 | 진새벽 [S_Q05_0022]**

수첩도 해금 씨가 적었습니다. 같은 관찰에서 나온 메모와 진술은 한 목격자의 서로 다른 형태이지 두 사람이 아닙니다.

> 여유 `-2`.

### B_Q05_err_demand_guessed_coat_color
**P00 | 나여백 [S_Q05_0031]**

그 사람 외투가 빨간색이었는지 추측해서라도 말해 주세요. 그래야 진술을 믿을 수 있습니다.

**P05 | 소해금 [S_Q05_0032]**

그 창으로는 색을 믿을 수 없었어요. 모르는 걸 색으로 채우라고 하면 또 거짓말하게 됩니다.

**P07 | 진새벽 [S_Q05_0033]**

관찰 가능한 범위를 넘는 답을 요구하지 않습니다.

> 여유 `-2`.

### B_Q05_success

**P00 | 나여백 [S_Q05_0041]**

접힌 음향 수첩과 반투명 창에서 보이는 것과 안 보이는 것의 한계를 함께 보면, 해금 씨는 신원을 볼 수 없었지만 두 사람의 큰 움직임은 기록했습니다. `아무 움직임도 보지 못했다`는 진술은 그 범위에서 맞지 않습니다. 이름이나 외투 색은 묻지 않겠습니다.

*해금이 오래 숨을 내쉰다.*

**P05 | 소해금 [S_Q05_v2]**

봤어요. 두 사람 그림자가 있었고, 한 사람이 앞으로 다가가서 두 팔을 다른 사람 윗몸 쪽으로 뻗는 걸 봤습니다. 그 다음 다른 사람이 뒤로 밀리듯 열려 있던 문 쪽으로 넘어갔어요. 조명 확인 신호가 들린 뒤였고, 전원이 돌아와 리셋 확인하기 전이었습니다. 얼굴도, 옷 색도 못 봤어요.

**P05 | 소해금 [S_Q05_0042]**

처음에 숨긴 건 제가 방송 일도 거짓말했다는 게 드러나면, 제가 본 모양까지 다들 두철 씨라고 정할까 봐 무서웠기 때문입니다. 그 사람인지 아닌지는 저는 모릅니다.

#### E43 — 목격 진술 정정

> **소해금의 창 목격 정정 기록**  
> - 반투명 창 너머에 사람 그림자 둘이 있었음  
> - 한 사람이 앞으로 다가가 두 팔을 다른 사람의 윗몸 쪽으로 뻗음  
> - 다른 사람은 뒤로 밀리듯 열려 있던 문 쪽으로 넘어감  
> - 관찰 경계: **20:18 라이브 조명 확인 신호 뒤, 20:20 전원 복귀·리셋 확인 전**  
> - 얼굴과 옷 색은 식별하지 못함  
> - **출처/한계:** 앞서 확보한 접힌 음향 수첩과 같은 소해금의 창 관찰을 정정한 기록이며, 독립된 두 번째 목격이 아님. 행위자의 신원을 독립적으로 증명하지 않음

- Metadata (not player-facing): E43 and KQ05 are acquired only on Q05 success; provenance remains the same P05 witness line as E41.

### B_Q05_retry
**P00 | 나여백 [S_Q05_0081]**

수첩을 두 번째 목격자로 만들거나 해금 씨에게 색을 추측시키지 않고, `실제로 본 동작과 시각 경계`만 다시 묻겠습니다.

### Historical replay / current revisit
**P00 | 나여백 [S_Q05_0091]**

현재 진술은 정정된 창 목격 설명이며, 얼굴과 옷 색은 식별하지 못했다는 한계가 붙습니다. 접힌 음향 수첩은 같은 목격자가 당시 적은 메모로만 사용합니다.

---

## C_H_Q05 — Q05 힌트

### Context
- Place: L07 / testimony help
- Cast: P00 guidance
- Entry: Q05 live or interrupted
- Exit: returns without leaking S_Q05_v2
- State keys: missing E41 / missing K21 / all-held-live-v1 / notebook-second-witness error / guessed-color error / interrupted / KQ05-complete

#### Deterministic selector (normative)
- Return **one Korean utterance only**. Priority: `KQ05 complete` → `missing prerequisite` → `recent named error (H3/H4 only)` → `requested live-v1 level`. Never expose `S_Q05_v2` content through a hint.
- `KQ05 complete`, any H0–H4 → `S_H_Q05_0091`.
- E41 missing, any H0–H4 → `S_H_Q05_0002`; else K21 missing → `S_H_Q05_0003`.
- With E41+K21 and live `S_Q05_v1`, recent `notebook_is_second_witness`, H3/H4 → `S_H_Q05_0032`; recent `guessed_color`, H3/H4 → `S_H_Q05_0033`.
- Otherwise with E41+K21: H0 `S_H_Q05_0004`; H1 `S_H_Q05_0011`; H2 `S_H_Q05_0021`; H3 `S_H_Q05_0031`; H4 `S_H_Q05_0041`. Interrupted state uses the same held-source rule; if no recent named error applies, H4 may use `S_H_Q05_0042` only when resuming an already-written question.


### H_Q05_0
**P00 | 나여백 [S_H_Q05_0001]**

수첩과 시야 한계 결론이 모두 있는지 먼저 봅니다. 빠진 쪽을 확인한 뒤 해금 씨의 현재 `움직임을 못 봤다`는 말과 비교합니다.

#### State — missing E41
**P00 | 나여백 [S_H_Q05_0002]**

해금 씨에게 당시 접어 둔 음향 수첩을 보여 달라고 요청하세요. 그 메모는 해금 씨와 같은 관찰자에서 나온 자료입니다.

#### State — missing K21
**P00 | 나여백 [S_H_Q05_0003]**

먼저 반투명 창에서 무엇이 실제로 보이는지 정리하세요. 보이지 않는 신원·색을 추궁에 요구하면 안 됩니다.

#### State — all held / live v1
**P00 | 나여백 [S_H_Q05_0004]**

현재 진술은 `사람 움직임을 보지 못했다`입니다. 수첩에는 이름 없이 `둘 / 앞으로 / 두 손`이 적혀 있고, 실측상 그 정도 큰 움직임은 보일 수 있습니다.

### H_Q05_1
**P00 | 나여백 [S_H_Q05_0011]**

수첩에 없는 얼굴·색·정확한 시각을 채우지 말고, 적혀 있는 움직임만 현재 진술과 대조하세요.

### H_Q05_2
**P00 | 나여백 [S_H_Q05_0021]**

수첩과 현재 진술은 둘 다 해금 씨 한 사람에게서 나왔습니다. 서로 독립된 두 목격처럼 세면 안 됩니다.

### H_Q05_3
**P00 | 나여백 [S_H_Q05_0031]**

`수첩=두 번째 증인`도, `색을 추측해 신원을 말하라`도 버리고 관찰 가능한 행동만 다시 묻습니다.

#### State — recent second-witness error
**P00 | 나여백 [S_H_Q05_0032]**

방금은 같은 사람의 메모와 말을 두 목격으로 셌습니다. 한 관찰자의 모순으로만 사용하세요.

#### State — recent guessed-color error
**P00 | 나여백 [S_H_Q05_0033]**

방금은 보이지 않는 옷 색을 추측시키려 했습니다. 얼굴·색은 질문에서 빼고 큰 동작만 남기세요.

### H_Q05_4
**P00 | 나여백 [S_H_Q05_0041]**

질문은 이렇게 좁히면 됩니다. `이 창에서는 사람 수와 큰 움직임은 볼 수 있고, 당신 수첩에도 둘·전진·두 손이 적혀 있습니다. 그런데 지금은 움직임을 보지 못했다고 말합니다. 실제로 본 동작을 신원이나 색 없이 다시 설명해 주시겠습니까?`

#### State — interrupted
**P00 | 나여백 [S_H_Q05_0042]**

중단했다면 현재 부정과 수첩 세 단어를 그대로 두고 이어 질문합니다. 정정 내용을 먼저 제시하지 않습니다.

#### State — complete
**P00 | 나여백 [S_H_Q05_0091]**

해금 씨 진술은 이미 정정됐습니다. 이후 행사 중 창 목격 기록과 정정 진술을 독립된 두 목격처럼 세지 말고, 시야 한계를 붙인 한 목격자 계열로 사용합니다.

## C_CH05_04 — 안전선 뒤의 동작

### Context
- Place: L07/L09 secured observation pair
- Cast: P00, P05, P07, P04
- Entry: K21 + Q05 success/E43; E42 held
- Exit: E45 acquired after three distinct safe action comparisons; D22 and D23 independently eligible
- Supervision: P01 remains in L02 with P02
- Safety: nobody crosses the barrier, approaches the open gate edge, or acts out a fall; the receiving adult stops at a marked safe line
- Repeat/resume: resume at the next untested alternative; test playback is not a new witness and does not generate another E45

### Script

*새벽이 실제 게이트에서 충분히 떨어진 평평한 구역에 세 줄의 테이프를 붙인다. `관찰 시작`, `접촉`, `정지`. 해금은 부스의 반투명 창 뒤에 서고, 두철과 새벽은 성인 실루엣 역할만 맡는다.*

**P07 | 진새벽 [S_CH05_04_0002]**

세 경우를 모두 같은 시작점에서 해 보겠습니다. 누구도 게이트 쪽으로 넘어가지 않고, 뒤로 움직이는 사람은 `정지` 선에서 끝냅니다. 과거 사건을 재연하는 게 아니라, 해금 씨가 말한 순서가 이 창에서 어떻게 보이는지 비교하는 겁니다.

**P04 | 탁두철 [S_CH05_04_0001]**

제가 넘어지는 척도 안 합니다. 발 위치랑 팔 동작만 하죠.

#### 비교 A — 혼자 헛디딤

*새벽은 제자리에 있고, 두철만 뒤로 한 걸음 물러난다. 접근하는 두 번째 실루엣도, 먼저 뻗는 두 팔도 없다.*

**P05 | 소해금 [S_CH05_04_0010]**

둘은 보이지만 한쪽이 먼저 다가오는 모양은 없어요. 뒤로 가는 사람만 움직인 건 구별됩니다.

#### 비교 B — 부축

*두철이 먼저 몸을 뒤로 기울인다. 그 뒤 새벽이 한 걸음 다가가 팔을 내밀고, 두 사람은 접촉 선에서 멈춘 채 가까워진다.*

**P05 | 소해금 [S_CH05_04_0011]**

이번엔 뒤로 움직이는 쪽이 먼저예요. 다른 사람이 나중에 붙어서 잡는 모양이고, 둘 사이가 다시 가까워집니다.

#### 비교 C — 밀어내는 접촉

*새벽이 먼저 한 걸음 전진한다. 두 팔이 두철의 윗몸 쪽까지 나가고, 그 직후 두철이 뒤로 한 걸음 물러난다. 둘은 정지 선에서 끝낸다.*

**P05 | 소해금 [S_CH05_04_0012]**

이번엔 다가오는 쪽이 먼저고, 팔이 나간 다음 다른 쪽이 뒤로 갑니다. 제가 정정한 순서와 비교할 수 있는 차이는 그거예요. 얼굴은 셋 다 안 보여요.

**P00 | 나여백 [S_CH05_04_0013]**

세 경우가 이 창에서 같은 모양으로 뭉개지는 건 아니군요. `누가 누구인지`는 못 보지만, 누가 먼저 움직였는지와 두 팔 접촉의 순서는 비교할 수 있습니다.

#### E45 — 시야·신호 대조 기록

> 장벽 뒤 성인 안전 비교. 세 가설은 끝까지 라벨링: `혼자 헛디딤 / 부축 / 밀어내는 접촉`.  
> - 헛디딤: 상대 접근·선행 양팔 동작 없음, 후퇴만 먼저 보임.  
> - 부축: 후퇴/흔들림이 먼저, 이후 접근·팔 동작, 두 실루엣이 가까워지며 안정.  
> - 밀어내는 접촉: 한 실루엣이 먼저 전진→양팔을 상대 윗몸 쪽으로 뻗음→상대가 뒤로 이동.  
> 소해금의 정정 진술은 세 번째 순서와 비교 가능. 얼굴·옷 색은 어느 경우에도 식별 불가.  
> 앞서 확보한 공개 진행표·전원 기록·복귀 확인을 대조해 실시간 공개 신호 20:18, 복귀 확인 20:20을 함께 표기. 실험 자체는 10월 21일의 독립 목격이 아님.

- Metadata (not player-facing): E45 compares P05 corrected witness account E43 with the live cue/power/recovery chain already established by E12/E17/E18.

**P04 | 탁두철 [S_CH05_04_0014]**

게이트가 열려 있으면 혼자 헛디딜 위험이 있었던 건 맞습니다. 그렇다고 그 위험 때문에 팔 동작까지 없던 걸로 만들 순 없겠네요.

**P07 | 진새벽 [S_CH05_04_0015]**

반대로 오늘 세 번째 동작이 가능했다고 해서 어제도 반드시 그 동작이었다고 정하는 것도 안 됩니다. 이제 목격 진술과 오늘 비교가 각각 어디까지 말해 주는지 나눠 정리하면 됩니다.

**P05 | 소해금 [S_CH05_04_0003]**

제가 본 범위를 더 크게 만들고 싶지는 않아요. 다만 제가 말한 `다가감, 두 팔, 뒤로 감`이 이 창에서 전혀 볼 수 없는 모양은 아니었다는 건 확인했습니다.

**P00 | 나여백 [S_CH05_04_0004]**

행동 설명과 시간 범위는 별개로 정리하겠습니다. 어느 쪽을 먼저 풀어도 다른 한쪽을 대신하지 않습니다.

## C_D22 — 헛디딤·부축·밀침 중 어떤 설명이 관찰과 맞을까?

### Context
- Place: L07 / secured comparison record
- Cast: P00, P05, P07, P04
- Entry: E42/E43/E45
- Exit: K22
- Repeat/resume: reuse the recorded safe alternatives; do not rerun a fall or create new eyewitness evidence

### Script

**P00 | 나여백 [S_D22_0001]**

열린 문 자체와, 목격된 접촉 동작을 구분해 세 설명을 비교하겠습니다.

> **D22:** `헛디딤·부축·밀침 중 어떤 설명이 관찰과 맞을까?`

### B_D22_incomplete
**P00 | 나여백 [S_D22_0011]**

열린 보수문/목격 진술 정정/시야·신호 대조 기록이 모두 필요합니다. 해금 씨의 창 목격 진술 추궁에 성공하기 전에는 목격 진술 정정을 추측으로 만들지 않습니다.

### B_D22_err_open_gate_proves_push
**P00 | 나여백 [S_D22_0021]**

게이트가 열려 있었으니 누군가 밀었다는 사실이 증명됩니다.

**P04 | 탁두철 [S_D22_0022]**

제가 문을 열어 둔 건 사고 위험을 만든 잘못입니다. 하지만 열린 문만으로 다른 사람이 팔을 썼다는 사실까지 나오진 않아요.

> 여유 `-2`.

### B_D22_err_test_is_record_of_past
**P00 | 나여백 [S_D22_0031]**

오늘 실험에서 밀침 모양이 재현됐으니 어제 실제로도 똑같이 밀쳤다고 물리적으로 증명됐습니다.

**P07 | 진새벽 [S_D22_0032]**

오늘 실험은 가능성을 확인한 재연입니다. 과거의 독립 기록은 목격 진술 정정 목격입니다. 둘을 한 목격처럼 세지 마세요.

> 여유 `-2`.

### B_D22_success
**P00 | 나여백 [S_D22_0041]**

열린 보수문의 열린 게이트만 보면 헛디딤 사고도 가능했습니다. 하지만 목격 진술 정정은 한 사람이 앞으로 다가가 양팔을 상대 윗몸 쪽으로 뻗고, 상대가 뒤로 넘어갔다고 정정합니다. 시야·신호 대조 기록 안전 실험에서 그 동작은 해당 시야에서 구별 가능하고 `부축`보다 밀어내는 동작과 더 잘 맞습니다.

**P00 | 나여백 [S_D22_0042]**

따라서 현재 가장 지지되는 설명은 **밀침**입니다. 근거 유형은 `제한된 목격 진술 + 그 진술이 물리적으로 가능한지 확인한 실험`이며, 실험 자체가 과거를 다시 목격한 것은 아닙니다.

- Author state: **K22 acquired.**

### B_D22_retry
**P00 | 나여백 [S_D22_0081]**

열린 문만으로 결론 내리거나 오늘 실험을 과거 기록으로 만들지 않고, 정정된 목격과 오늘 시야·신호 비교가 맡는 역할을 나눠 다시 정리합니다.

### Current revisit
**P00 | 나여백 [S_D22_0091]**

관찰된 동작이 밀침과 가장 맞는다는 결론은 밀침이 가장 잘 맞는다는 행동 결론입니다. 신원은 아직 남습니다.

---

## C_H_D22 — D22 힌트

### Context
- Place: L07 / reasoning help
- Cast: P00 guidance
- Entry: D22 available or interrupted
- Exit: state-selected return
- State keys: missing E42/E43/E45 / all-held / gate-proves-push error / test-is-past error / interrupted / K22-complete

#### Deterministic selector (normative)
- Return **one Korean utterance only**. Priority: `K22 complete` → `missing prerequisite` → `recent named error (H3/H4 only)` → `requested all-held level`.
- `K22 complete`, any H0–H4 → `S_H_D22_0091`.
- If any of E42/E43/E45 is missing, any H0–H4 → `S_H_D22_0002`; this line does not invent Q05's correction when E43 is absent.
- With all three held and recent `gate_proves_push`, H3/H4 → `S_H_D22_0032`; recent `test_is_past`, H3/H4 → `S_H_D22_0033`.
- With all held: H0 `S_H_D22_0003`; H1 `S_H_D22_0011`; H2 `S_H_D22_0021`; H3 `S_H_D22_0031`; H4 `S_H_D22_0041`. Interrupted state without a named recent error uses the requested all-held line, except H4 may use `S_H_D22_0042` when resuming a partially filled comparison.


### H_D22_0
**P00 | 나여백 [S_H_D22_0001]**

게이트 상태, 해금 씨의 정정된 동작, 세 가지 안전 비교 기록이 모두 있는지 확인합니다. 하나가 없으면 그 단계부터 이어 갑니다.

#### State — missing prerequisite
**P00 | 나여백 [S_H_D22_0002]**

`열린 게이트 / 정정된 목격 / 헛디딤·부축·밀어내는 접촉 비교` 가운데 빠진 것을 먼저 확인하세요. 목격 정정은 Q05 성공 전에는 추측하지 않습니다.

#### State — all held
**P00 | 나여백 [S_H_D22_0003]**

세 자료가 모두 있습니다. 누가 먼저 움직였는지, 두 팔이 언제 나왔는지, 상대가 그 뒤 어떻게 움직였는지를 세 가설과 비교하면 됩니다.

### H_D22_1
**P00 | 나여백 [S_H_D22_0011]**

헛디딤은 상대의 선행 접근·양팔이 없고, 부축은 흔들림/후퇴가 먼저, 밀어내는 접촉은 접근·양팔이 먼저 나온 뒤 상대가 뒤로 갑니다.

### H_D22_2
**P00 | 나여백 [S_H_D22_0021]**

게이트는 사고 가능 조건, 해금 씨 정정은 과거 목격, 오늘 비교는 그 동작을 이 시야에서 구별할 수 있는지 확인한 실험입니다. 역할을 합치지 마세요.

### H_D22_3
**P00 | 나여백 [S_H_D22_0031]**

열린 문만으로 밀침을 만들지 말고, 오늘 실험을 어제의 새 목격으로 만들지도 마세요.

#### State — recent gate-proves-push error
**P00 | 나여백 [S_H_D22_0032]**

방금은 위험한 게이트 자체를 고의 접촉의 증거로 만들었습니다. 목격된 팔 동작을 따로 붙이세요.

#### State — recent test-is-past error
**P00 | 나여백 [S_H_D22_0033]**

방금은 오늘 가능성 비교를 과거 사건 기록으로 바꿨습니다. 과거 행동은 해금 씨 목격, 오늘 기록은 식별 가능성 확인입니다.

### H_D22_4
**P00 | 나여백 [S_H_D22_0041]**

저라면 `열린 게이트만으로는 헛디딤도 가능하지만, 정정된 목격은 한 사람이 먼저 다가가 두 팔을 상대 윗몸 쪽에 뻗은 뒤 상대가 뒤로 갔다고 한다. 안전 비교에서도 그 순서는 부축보다 밀어내는 접촉과 더 잘 맞는다. 실험은 과거의 독립 목격이 아니다`라고 정리하겠습니다.

#### State — interrupted
**P00 | 나여백 [S_H_D22_0042]**

중단했다면 세 가설 중 아직 비교하지 않은 동작부터 이어 봅니다.

#### State — complete
**P00 | 나여백 [S_H_D22_0091]**

행동은 밀침과 가장 잘 맞는다고 정리했습니다. 신원과 정확한 한 분은 아직 별도 문제입니다.

## C_D23 — 추락 사건의 시각은 어디까지 좁힐 수 있을까?

### Context
- Place: L02 or L07 reasoning view
- Cast: P00, P07
- Entry: E43 + prior cue/order conclusion + E13/E17/E18
- Exit: K23 = 20:17–20:21 incident interval
- Repeat/resume: retain ordered anchors and one-minute uncertainty; never expose author-only exact minute

### Script

**P00 | 나여백 [S_D23_0001]**

해금 씨가 동작을 본 경계를 기존 공개 신호와 시계 오차에 겹치겠습니다.

> **D23:** `추락 사건의 시각은 어디까지 좁힐 수 있을까?`

### B_D23_incomplete
**P00 | 나여백 [S_D23_0011]**

목격 진술 정정과 공개 신호·정전·재생 순서 결론, 시계 대조 기록/전원 복귀 기록/공개 점검 기록이 필요합니다. 빠진 것이 있으면 그 자료부터 확인하겠습니다.

### B_D23_err_outage_alone_dates_death
**P00 | 나여백 [S_D23_0021]**

전원 기록이 20:19 차단을 찍었으니 추락도 사망도 정확히 20:19입니다.

**P07 | 진새벽 [S_D23_0022]**

전원 차단은 전원 사건입니다. 목격 경계와 1분 오차를 같이 써야 하고, 생리적 사망 시각을 여기서 정하지 않습니다.

> 여유 `-2`.

### B_D23_err_recorded_voice_proves_alive_2030
**P00 | 나여백 [S_D23_0031]**

20시 30분에 문식 씨 목소리가 들렸으니 추락은 그 뒤입니다.

**P07 | 진새벽 [S_D23_0032]**

20시 30분 목소리는 이미 18시 10분 파일의 수동 재생으로 정정됐습니다. 그걸 다시 생존 증거로 쓰면 앞서 확인한 재생 사실을 되돌리는 셈입니다.

> 여유 `-2`.

### B_D23_success
**P00 | 나여백 [S_D23_0041]**

바로잡힌 목격의 동작은 실시간 신호 뒤, 복귀 확인 전입니다. 공개 신호·정전·재생 순서 결론/전원 복귀 기록/공개 점검 기록에서 명목상 신호는 20:18, 차단/복귀는 20:19–20:20이고, 시계 대조 기록 때문에 경계에 1분 오차를 둡니다.

**P00 | 나여백 [S_D23_0042]**

그래서 우리가 자료로 말할 수 있는 추락 사건의 범위는 **20:17–20:21**입니다. 그 사이의 한 분을 억지로 찍거나 정확한 생리적 사망 시각까지 정하지 않겠습니다.

- Author state: **K23 acquired.**

### B_D23_retry
**P00 | 나여백 [S_D23_0081]**

정전 한 줄이나 20:30 녹음으로 시간을 정하지 않고, 목격의 앞뒤 신호와 1분 오차를 다시 겹치겠습니다.

### Current revisit
**P00 | 나여백 [S_D23_0091]**

사건이 20시 17분에서 21분 사이였다는 결론은 추락 행동의 입증 가능한 범위입니다. 그 안의 특정 한 분이나 생리적 사망 시각을 확정한 결론은 아닙니다.

---

## C_H_D23 — D23 힌트

### Context
- Place: L02 / reasoning help
- Cast: P00 guidance
- Entry: D23 available or interrupted
- Exit: state-selected return
- State keys: missing E43 / missing timing sources / all-held / outage-only error / 20:30-live error / interrupted / K23-complete

#### Deterministic selector (normative)
- Return **one Korean utterance only**. Priority: `K23 complete` → `missing E43` → `missing timing source` → `recent named error (H3/H4 only)` → `requested all-held level`.
- `K23 complete`, any H0–H4 → `S_H_D23_0091`.
- E43 missing, any H0–H4 → `S_H_D23_0002`.
- If any required live-signal/recovery/clock-comparison source is missing, any H0–H4 → `S_H_D23_0003`.
- With all required sources and recent `outage_only`, H3/H4 → `S_H_D23_0032`; recent `20_30_live`, H3/H4 → `S_H_D23_0033`.
- With all sources: H0 `S_H_D23_0004`; H1 `S_H_D23_0011`; H2 `S_H_D23_0021`; H3 `S_H_D23_0031`; H4 `S_H_D23_0041`.


### H_D23_0
**P00 | 나여백 [S_H_D23_0001]**

해금 씨의 정정, 앞서 공개 자리에서 확인한 신호 순서, 시계 대조 기록, 전원 복귀 기록, 공개 점검 기록이 모두 있어야 합니다. 빠진 쪽부터 확인합니다.

#### State — missing E43
**P00 | 나여백 [S_H_D23_0002]**

해금 씨가 본 동작의 앞뒤 신호가 아직 없습니다. Q05 정정을 먼저 끝내세요.

#### State — missing prior timing source
**P00 | 나여백 [S_H_D23_0003]**

실시간 신호·복귀 순서 또는 1분 이내 시계 대조가 빠져 있습니다. 앞서 남긴 공개 점검 기록을 확인한 뒤 범위를 계산합니다.

#### State — all held
**P00 | 나여백 [S_H_D23_0004]**

동작은 20:18 실시간 신호 뒤, 20:20 복귀 확인 전입니다. 시계는 1분 안쪽 차이가 있으니 바깥 경계를 각각 한 분 넓힙니다.

### H_D23_1
**P00 | 나여백 [S_H_D23_0011]**

정정 진술은 `신호 뒤 / 복귀 전`, 전원·공개 기록은 순서, 시계 대조는 경계 오차를 줍니다.

### H_D23_2
**P00 | 나여백 [S_H_D23_0021]**

20:18과 20:20에 ±1분을 바깥으로 적용하면 20:17–20:21입니다. 특정 한 분을 골라내는 계산이 아닙니다.

### H_D23_3
**P00 | 나여백 [S_H_D23_0031]**

20:19 전원 차단만으로 추락을 찍지 말고, 20:30 목소리는 이미 녹음 재생이므로 생존 증거로 쓰지 마세요.

#### State — recent outage-only error
**P00 | 나여백 [S_H_D23_0032]**

방금은 전원 사건 하나를 추락 시각으로 만들었습니다. 목격의 앞뒤 신호와 시계 오차를 다시 붙이세요.

#### State — recent 20:30-live error
**P00 | 나여백 [S_H_D23_0033]**

방금은 정정된 녹음 재생을 다시 생존 목소리로 사용했습니다. 20:30 음성은 사건 시각 하한/상한이 아닙니다.

### H_D23_4
**P00 | 나여백 [S_H_D23_0041]**

저라면 `목격된 동작은 실시간 20:18 신호 뒤, 20:20 복귀 확인 전이고 시계 대조의 1분 불확실성을 양쪽 바깥으로 적용하므로 사건 범위는 20:17–20:21`이라고 정리하겠습니다.

#### State — interrupted
**P00 | 나여백 [S_H_D23_0042]**

중단했다면 `앞 신호 / 뒤 신호 / 오차` 세 칸 중 비어 있는 칸부터 이어 갑니다.

#### State — complete
**P00 | 나여백 [S_H_D23_0091]**

사건의 입증 가능한 범위는 20:17–20:21로 정리됐습니다. 한 분짜리 사망 시각은 만들지 않습니다.

## C_CH05_05 — 둘 중 하나가 먼저 끝났을 때

### Context
- Place: L07
- Cast: P00, P05, P04
- Entry: Q05 success; D22/D23 may have been solved in either order
- Exit: serious aftermath; remaining unsolved task explicitly stays open

### Script

**If K22 acquired and K23 not yet**

**P05 | 소해금 [S_CH05_05_0001]**

제가 본 동작이 밀침 쪽과 맞는 건 이제 알겠어요. 그래도 그게 정확히 몇 시였는지는 제 기억만으로 말하고 싶지 않습니다.

**P00 | 나여백 [S_CH05_05_0002]**

그래서 다음은 앞뒤 신호와 시계 오차를 따로 맞춥니다.

**If K23 acquired and K22 not yet**

**P05 | 소해금 [S_CH05_05_0011]**

시간 범위는 좁혔는데, 그 안에 본 동작이 사고인지 부축인지 밀침인지 아직 남았네요.

**P04 | 탁두철 [S_CH05_05_0012]**

게이트를 열어 둔 제 잘못 때문에 사고처럼 보일 수도 있습니다. 그걸 핑계로 밀침 여부를 흐리진 마세요.

**If K22 and K23 acquired**

**P05 | 소해금 [S_CH05_05_0021]**

제가 숨긴 말 때문에 시간이랑 행동을 둘 다 늦게 확인하게 됐네요.

**P04 | 탁두철 [S_CH05_05_0022]**

나한테 미안하다고 먼저 할 필요는 없어. 내가 게이트 열어 둔 건 내가 책임질 일이고.

**P05 | 소해금 [S_CH05_05_0023]**

당신한테 사과하는 게 아니라, 내가 못 본 얼굴을 봤다고 만들 뻔한 사람들한테 하는 말이야.

*두 사람은 화해하지 않는다. 각자의 책임을 인정한 채 장비 상자를 함께 옮기되, 서로 손잡이를 동시에 잡았다가 한 사람이 놓는다.*

---

## C_CH05_06 — 안전한 곳으로 돌아온 시간표

### Context
- Place: L02
- Cast: P00, P07, P01, P02
- Entry: Q05 success; E45 held; D22/D23 may be completed in either order
- Exit: public cue/reset alignment is reviewed; K22/K23 both required before coat strand
- Supervision: adult team explicitly returns P01 from P02 supervision to P00; P01 recalls only the public sound she actually heard in L03 during PR13; the present conversation is in L02
- Repeat/resume: if D23 remains open, this scene leaves the ordered anchors available; no new event time is created

### Script

*여백과 새벽이 휴게실로 돌아오자 만실이 모눈의 우산 번호표 묶음을 여백에게 건넨다. 모눈은 자리에서 일어나 여백 옆으로 붙는다.*

**P02 | 봉만실 [S_CH05_06_0005]**

모눈이는 여기서 한 발짝도 안 나갔어요. 우산 번호 바꾸느라 나를 세 번 불렀으니까. 이제 다시 {playerName} 씨가 맡아요.

**P01 | 나모눈 [S_CH05_06_0006]**

두 번이야. 그리고 이모, 어제 연회장이 어두워졌다가 다시 켜졌을 때 나는 거기서 `다시 시작`이라는 소리 들었어.

**P00 | 나여백 [S_CH05_06_0002]**

응. 네가 수영장 쪽을 본 건 아니고, 어제 연회장의 공개 탁자에서 실제로 들은 복귀 신호지. 그 차이를 같이 적자.

**P07 | 진새벽 [S_CH05_06_0004]**

공개 점검 기록에도 같은 구분이 있습니다. 20시 18분 실시간 신호 뒤, 20시 19분 부하 차단, 20시 20분 복귀와 공개 자리 확인. 주조명이 꺼진 짧은 동안에도 연회장의 공개 탁자와 부스의 낮은 안전 조명은 남아 있어서 만실 씨와 해금 씨 위치는 계속 보였습니다. 그때 {playerName} 씨가 있던 연회장 탁자에서는 수영장 통로가 보이지 않았고요.

**P01 | 나모눈 [S_CH05_06_0001]**

그러면 내가 들은 소리는 `누가 떨어진 소리`가 아니라, 여기서 다시 시작한 소리네.

**P00 | 나여백 [S_CH05_06_0003]**

맞아. 사건 시간을 맞출 때는 해금 씨가 본 동작의 앞뒤와, 네가 있던 공개 자리의 신호를 섞지 않고 순서대로 놓겠습니다.

**P07 | 진새벽 [S_CH05_06_0010]**

시계 대조 기록상 현관·주방·음향 시계는 1분 안쪽으로 차이가 납니다. 그래서 신호 숫자를 초 단위 사실처럼 쓰지 않고, 앞뒤 경계를 바깥으로 한 분씩 넓혀야 합니다.

*여백은 `20:18 신호 → 20:19 차단 → 20:20 복귀` 세 카드를 놓고, 양쪽 바깥에 `±1분` 쪽지를 붙인다. 아직 D23이 끝나지 않았다면 이 상태 그대로 추론으로 돌아갈 수 있다.*

## C_CH05_07 — 옷이 사람보다 오래 남는 경우

### Context
- Place: L01
- Cast: P00, P07; P04 and P03 enter in separate interview turns
- Entry: K22 and K23; V52 requested
- Exit: E44/E46/E47 and E10 comparison available; D24 eligible
- Supervision: P01 remains in L02 with P02 during evidence handling/interviews
- Evidence discipline: E44 recovery/custody label is shown separately from any wearer statement; neither interview is gated by friendliness
- Repeat/resume: physical match persists; either coat statement can be revisited freely without overwriting the other

### Script

*새벽은 증거 봉투를 열지 않고 두 장의 고해상도 사진을 화면에 띄운다. 왼쪽은 10월 21일 피해자 시신과 함께 회수되어 봉인된 붉은 천 조각, 오른쪽은 이후 증거 보관에 들어온 붉은 비옷의 왼쪽 옷깃이다.*

#### E44 — 옷깃 조각 대조

> **회수 기록:** 10월 21일 빈 수영장 바닥에서 발견된 표문식의 시신과 함께 붉은 천 조각이 회수됨. 진새벽이 회수·봉인 기록에 시신과 함께 나온 조각이라는 출처와 봉인 번호를 남김.  
> **의복 기록:** 이후 확보한 붉은 비옷 왼쪽 옷깃.  
> 두 상세 사진의 불규칙한 찢김선이 맞고, 삼각형 수선 박음질이 끊겼다가 이어짐.  
> 이 비교는 **현장 조각↔붉은 비옷**의 물리 연결만 증명하며 당시 착용자는 적지 않음.

**P07 | 진새벽 [S_CH05_07_0001]**

회수 위치와 봉인 기록은 조각이 어디서 왔는지를 말하고, 찢김·수선선은 어느 옷에서 떨어졌는지를 말합니다. `누가 그때 입었나`는 별도 질문입니다.

*먼저 두철이 들어온다. 새벽은 붉은 비옷 사진을 보여 주기 전에 서비스 랙 기록을 연다.*

#### E47 — 젖은 작업복 기록

> 탁두철의 파란 작업복이 서비스 접속부 랙에서 젖은 상태로 기록됨. 이전 날짜 수선 사진으로 붉은 비옷과 구별됨. 젖음은 화물 덮개 작업, 소매의 재는 주방 소각 작업과 부합. 젖음/재만으로 살인 또는 알리바이를 증명하지 않음.

**P04 | 탁두철 [S_CH05_07_0002]**

인계 끝나고 제 작업복이 젖어 있었어요. 랙으로 돌아왔을 때, 20시 26분쯤 무록 씨가 붉은 비옷을 줬습니다. 그 전에는 안 입었습니다.

**P00 | 나여백 [S_CH05_07_0010]**

그 시각은 두철 씨 현재 진술로 기록하겠습니다. 공개용 인계표의 시각을 근거로 덧붙이지는 않겠습니다.

*두철이 나간 뒤 차무록이 들어온다. 같은 질문을 처음부터 다시 묻는다.*

**P03 | 차무록 [S_CH05_07_0003]**

저는 20시 17분 전에 탁두철 씨에게 빌려줬습니다. 그 뒤엔 제가 입지 않았습니다.

#### E46 — 외투 인계 진술

> 탁두철: `인계 뒤 약 20:26 차무록에게서 받음.`  
> 차무록: `20:17 이전 탁두철에게 빌려줌.`  
> 둘은 서로 충돌하는 현재 진술로 함께 보존. 어느 쪽도 자동 확정하지 않음.

**P07 | 진새벽 [S_CH05_07_0011]**

두 진술은 덮어쓰지 않습니다. 둘 다 남겨 놓고 다른 기록과 비교하죠.

*여백은 이미 확보한 행사 사진을 화면 옆에 띄운다.*

**P00 | 나여백 [S_CH05_07_0004]**

행사 사진은 `점검 시작 전`이라는 현장 맥락 속에서 20시 16분 무렵 차무록 씨가 **아직 찢어지지 않은 삼각 수선 붉은 비옷**을 입은 모습을 보여 줍니다. 옷깃 조각은 그 옷이 나중에 수영장 상부 랜딩 현장과 물리적으로 이어진다는 사실을 더합니다. 하지만 사건 시 착용자는 두 사람의 인계 시각 주장이 갈립니다.

**P03 | 차무록 [S_CH05_07_0012]**

사진이 찍힌 뒤 바로 빌려줬다면 모순은 아닙니다.

**P00 | 나여백 [S_CH05_07_0013]**

맞습니다. 그래서 사진 한 장이나 나중 소지 하나로 착용자를 정하지 않고, 인계의 실제 시간과 독립된 동선을 더 확인해야 합니다.

## C_D24 — 옷깃 조각이 연결하는 것은 사람일까, 옷일까?

### Context
- Place: L01
- Cast: P00, P07
- Entry: E44/E46/E47/E10
- Exit: K24
- Repeat/resume: preserve both conflicting coat handoff statements

### Script

**P00 | 나여백 [S_D24_0001]**

물리 조각이 사람을 직접 가리키는지, 옷의 이동을 가리키는지 나누겠습니다.

> **D24:** `옷깃 조각이 연결하는 것은 사람일까, 옷일까?`

### B_D24_incomplete
**P00 | 나여백 [S_D24_0011]**

옷깃 조각 대조/외투 인계 진술/젖은 작업복 기록/행사 사진이 모두 필요합니다. 하나가 없으면 먼저 그 자료를 확인하겠습니다.

### B_D24_err_later_holder_is_actor
**P00 | 나여백 [S_D24_0021]**

붉은 비옷을 나중에 탁두철 씨가 갖고 있었으니, 옷깃 조각은 탁두철 씨가 밀었다는 증거입니다.

**P07 | 진새벽 [S_D24_0022]**

조각은 옷을 연결합니다. 옷이 사람 사이에 언제 이동했는지가 다투어지는 상황에서 나중 소지만으로 사건 시 착용자를 확정할 수 없습니다.

> 여유 `-2`.

### B_D24_err_silhouette_identifies_red
**P00 | 나여백 [S_D24_0031]**

소해금 씨가 창 너머 붉은색 외투를 봤으니 사건 착용자가 붉은 비옷을 입었습니다.

**P07 | 진새벽 [S_D24_0032]**

해금 씨 정정에는 얼굴도 옷 색도 보지 못했다고 명시돼 있습니다. 실루엣 진술에 빨간색을 새로 넣으면 안 됩니다.

> 여유 `-2`.

### B_D24_success
**P00 | 나여백 [S_D24_0041]**

옷깃 조각 대조는 사건에 닿은 천 조각과 붉은 비옷을 물리적으로 연결합니다. 행사 사진은 20:16 무렵 차무록이 그 옷을 입었음을 보여 주고, 젖은 작업복 기록은 탁두철이 별도 파란 작업복을 입고 화물 작업을 했음을 설명합니다. 그러나 외투 인계 진술에서 탁두철은 20:26 인계, 차무록은 20:17 이전 대여를 주장해 사건 시 착용자가 충돌합니다.

**P00 | 나여백 [S_D24_0042]**

따라서 옷깃은 **옷의 사슬**을 증명하고, 사람의 사건 시 착용 여부는 인계 시각과 독립 알리바이로 갈라야 합니다.

- Author state: **K24 acquired.**

### B_D24_retry
**P00 | 나여백 [S_D24_0081]**

`나중 소유자=사건 착용자`와 `실루엣 색 식별`을 지우고, 옷의 물리 연결과 상반된 인계 주장만 남기겠습니다.

### Current revisit
**P00 | 나여백 [S_D24_0091]**

붉은 외투의 사건 전후 보유 사슬 결론 뒤에도 `차무록이 계속 입었다`와 `탁두철에게 일찍 빌려줬다` 두 설명이 남습니다.

---

## C_H_D24 — D24 힌트

### Context
- Place: L01 / reasoning help
- Cast: P00 guidance
- Entry: D24 available or interrupted
- Exit: state-selected return
- State keys: missing E44/E46/E47/E10 / all-held / later-holder error / silhouette-color error / interrupted / K24-complete

#### Deterministic selector (normative)
- Return **one Korean utterance only**. Priority: `K24 complete` → `missing source` → `recent named error (H3/H4 only)` → `requested all-held level`.
- `K24 complete`, any H0–H4 → `S_H_D24_0091`.
- If any of E44/E46/E47/E10 is missing, any H0–H4 → `S_H_D24_0002`.
- With all held and recent `later_holder_is_event_wearer`, H3/H4 → `S_H_D24_0032`; recent `silhouette_color`, H3/H4 → `S_H_D24_0033`.
- With all held: H0 `S_H_D24_0003`; H1 `S_H_D24_0011`; H2 `S_H_D24_0021`; H3 `S_H_D24_0031`; H4 `S_H_D24_0041`.


### H_D24_0
**P00 | 나여백 [S_H_D24_0001]**

현장 조각-비옷 대조, 양쪽 인계 진술, 젖은 파란 작업복 기록, 행사 사진을 모두 확인하세요.

#### State — missing source
**P00 | 나여백 [S_H_D24_0002]**

빠진 자료만 먼저 확인합니다. 회수·봉인된 옷깃 조각은 비옷과의 물리 연결을 맡고, 진술은 누가 언제 입었는지를 따로 다룹니다.

#### State — all held
**P00 | 나여백 [S_H_D24_0003]**

자료가 모두 있습니다. `옷 자체의 연결 / 사건 전 착용 사진 / 사건 뒤 두 사람의 상반된 인계 주장`을 세 칸으로 나누세요.

### H_D24_1
**P00 | 나여백 [S_H_D24_0011]**

옷깃 조각이 가장 강하게 말하는 건 `이 조각이 이 붉은 비옷에서 떨어졌다`는 사실입니다. 착용자 이름은 다음 문제입니다.

### H_D24_2
**P00 | 나여백 [S_H_D24_0021]**

행사 사진은 사건 전 차무록 착용, 외투 인계 진술은 서로 다른 인계 시각, 젖은 작업복 기록은 두철이 비옷을 필요로 하게 된 뒤쪽 맥락을 줍니다.

### H_D24_3
**P00 | 나여백 [S_H_D24_0031]**

나중 보유자를 사건 착용자로 만들지 말고, 해금 씨가 보지 못한 붉은색을 실루엣 진술에 넣지도 마세요.

#### State — recent later-holder error
**P00 | 나여백 [S_H_D24_0032]**

방금은 나중에 비옷을 가진 두철 씨를 곧 사건 착용자로 만들었습니다. 옷 이동 시각이 다투어진다는 점을 남기세요.

#### State — recent color error
**P00 | 나여백 [S_H_D24_0033]**

방금은 반투명 창에서 보이지 않은 색을 새로 넣었습니다. 옷의 색은 사진·물리 증거에서만 사용하세요.

### H_D24_4
**P00 | 나여백 [S_H_D24_0041]**

저라면 `현장 조각은 붉은 비옷과 물리적으로 이어지고, 20:16 무렵 사진에는 차무록이 그 옷을 입고 있다. 하지만 두철은 20:26쯤 받았다고 하고 차무록은 20:17 전 빌려줬다고 하므로, 조각은 옷을 증명할 뿐 사건 시 착용자는 아직 갈린다`고 정리하겠습니다.

#### State — interrupted
**P00 | 나여백 [S_H_D24_0042]**

중단했다면 물리 연결과 두 인계 진술 중 아직 대조하지 않은 쪽부터 이어 갑니다.

#### State — complete
**P00 | 나여백 [S_H_D24_0091]**

붉은 비옷의 물리 사슬과 상반된 인계 주장은 정리됐습니다. 다음은 그 두 설명을 어떤 원본이 가르는지입니다.

## C_D25 — 남은 두 설명은 무엇으로 갈라질까?

### Context
- Place: L02
- Cast: P00, P07
- Entry: K20/K22/K23/K24 + E27/E30
- Exit: K25; actual conservation-return event may open CH06
- Repeat/resume: preserve both actor/coat hypotheses; E30 remains unreadable until the next-day physical return

### Script

**P00 | 나여백 [S_D25_0001]**

밀침과 사건 범위, 옷의 사슬까지 확보했습니다. 이제 남은 강한 두 설명을 무엇이 가를지 정하겠습니다.

> **D25:** `남은 두 설명은 무엇으로 갈라질까?`

### B_D25_incomplete
**P00 | 나여백 [S_D25_0011]**

대출·담보·전용 책임 분리 결론/관찰된 동작이 밀침과 가장 맞는다는 결론/사건이 20시 17분에서 21분 사이였다는 결론/붉은 외투의 사건 전후 보유 사슬 결론과 인계 확인서 공개용 사본/젖어 붙은 인계 원본이 필요합니다. 젖어 붙은 인계 원본은 아직 읽히지 않는 상태여도 됩니다.

### B_D25_err_disputed_copy_already_identifies_actor
**P00 | 나여백 [S_D25_0021]**

인계 확인서 공개용 사본에 탁두철 씨 인계가 20:07–20:17로 적혀 있으니 그는 사건 시간에 자유로웠고, 따라서 붉은 비옷을 입고 밀친 사람은 탁두철 씨입니다.

**P07 | 진새벽 [S_D25_0022]**

인계 확인서 공개용 사본은 공개용 사본 하나이고 그 시각의 근원을 아직 인증하지 않았습니다. 그 사본을 이용해 사람을 먼저 고른 뒤 사본을 믿는 순환이 됩니다.

> 여유 `-2`.

### B_D25_success
**P00 | 나여백 [S_D25_0031]**

현재 두 설명은 남습니다. 하나는 20:16까지 붉은 비옷을 입은 차무록이 사건 때도 입고 있었다는 설명. 다른 하나는 차무록 주장처럼 20:17 전에 탁두철에게 빌려줬고, 인계 확인서 공개용 사본의 20:07–20:17 인계가 맞아 탁두철에게 사건 기회가 있었다는 설명입니다.

**P00 | 나여백 [S_D25_0032]**

이 둘을 가르는 핵심은 새 무기가 아니라 **인계 실제 시간과 공개용 사본의 보관·복사 경로**입니다. 젖어 붙은 인계 원본은 그 인계의 제본 원본으로 확보돼 있고 현재 건조 중입니다. 실제로 펼칠 수 있다는 연락이 온 뒤 인계 확인서 공개용 사본과 비교하겠습니다.

- Author state: **K25 acquired. CH06 date transition becomes eligible when the actual conservation return message occurs.**

### B_D25_retry
**P00 | 나여백 [S_D25_0081]**

논쟁 중인 인계 확인서 공개용 사본을 먼저 사실로 고정하지 않고, `차무록 계속 착용 / 탁두철 조기 대여` 두 가설을 유지한 채 원본 비교를 요청하겠습니다.

### Current revisit
**P00 | 나여백 [S_D25_0091]**

다음 단계는 오늘 더 기다리는 일이 아닙니다. 10월 23일 백로 씨가 실제로 펼침 가능하다고 연락하면, 같은 제본 원본을 보관소에서 다시 확인하겠습니다.

---

## C_H_D25 — D25 힌트

### Context
- Place: L02 / reasoning help
- Cast: P00 guidance
- Entry: D25 available or interrupted
- Exit: state-selected return
- State keys: missing K / missing E27/E30 / all-held / disputed-copy error / interrupted / K25-complete

#### Deterministic selector (normative)
- Return **one Korean utterance only**. Priority: `K25 complete` → `missing prior conclusion` → `missing E27/E30 secured-original state` → `recent disputed-copy error (H3/H4 only)` → `requested all-held level`.
- `K25 complete`, any H0–H4 → `S_H_D25_0091`.
- If any required earlier conclusion for motive/action/time/coat chain is missing, any H0–H4 → `S_H_D25_0002`.
- Else if E27 or the secured-but-still-unread E30 original is missing, any H0–H4 → `S_H_D25_0003`. The selector must not reveal E30's later readable times.
- With all prerequisites and recent `disputed_copy_as_fact`, H3/H4 → `S_H_D25_0032`.
- Otherwise: H0 `S_H_D25_0004`; H1 `S_H_D25_0011`; H2 `S_H_D25_0021`; H3 `S_H_D25_0031`; H4 `S_H_D25_0041`.


### H_D25_0
**P00 | 나여백 [S_H_D25_0001]**

재정 책임, 밀침 행동, 20:17–20:21 범위, 비옷 사슬 결론과 공개 사본/젖은 제본 원본이 모두 있는지 확인합니다.

#### State — missing prior K
**P00 | 나여백 [S_H_D25_0002]**

아직 행동·시간·옷 사슬 중 하나가 비어 있습니다. 그 결론을 먼저 끝내야 두 사람 가설을 공정하게 비교할 수 있습니다.

#### State — missing E27/E30
**P00 | 나여백 [S_H_D25_0003]**

공개 인계 사본과 같은 인계의 젖은 제본 원본이 모두 필요합니다. 원본은 아직 읽히지 않아도 `보존 중인 같은 물건`으로 확보돼 있어야 합니다.

#### State — all held
**P00 | 나여백 [S_H_D25_0004]**

두 가설은 `차무록 계속 착용`과 `20:17 전 조기 대여로 두철이 사건 때 착용`입니다. 둘을 가르는 건 공개 사본 숫자를 믿는 게 아니라 실제 인계 구간과 그 사본의 생성·보관 경로입니다.

### H_D25_1
**P00 | 나여백 [S_H_D25_0011]**

핵심은 사건 구간 20:17–20:21 동안 두철 씨가 실제로 자리를 비울 수 있었는지입니다.

### H_D25_2
**P00 | 나여백 [S_H_D25_0021]**

공개 사본의 20:07–20:17은 한 파생본의 숫자이고, 젖은 제본 원본은 아직 붙어 있어 값을 읽지 못합니다. 둘을 독립 출처처럼 세지 마세요.

### H_D25_3
**P00 | 나여백 [S_H_D25_0031]**

논쟁 중인 공개 사본을 먼저 참이라고 가정해 사람을 고르면 순환합니다. 보존된 원본의 실제 시간과 이후 복사 경로를 확인해야 합니다.

#### State — recent disputed-copy error
**P00 | 나여백 [S_H_D25_0032]**

방금은 20:07–20:17을 확정 사실로 놓고 두철 씨를 골랐습니다. 지금 단계에서는 두 가설을 모두 보존하고 원본 비교를 요청하세요.

### H_D25_4
**P00 | 나여백 [S_H_D25_0041]**

저라면 `차무록 계속 착용설과 조기 대여/두철 행위설을 가르는 핵심은 20:17–20:21 동안의 실제 인계·부재 가능성이다. 공개 사본은 파생본 하나이므로 확정하지 않고, 이미 보존 중인 제본 원본이 펼쳐지면 같은 인계의 실제 시간과 복사 경로를 대조한다`고 정리하겠습니다.

#### State — interrupted
**P00 | 나여백 [S_H_D25_0042]**

중단했다면 두 가설을 그대로 둔 채, 아직 확인하지 못한 `원본 시간 / 복사 경로` 쪽을 다음 날 약속으로 남기면 됩니다.

#### State — complete
**P00 | 나여백 [S_H_D25_0091]**

최종 병목은 보존된 원본과 공개 사본의 관계로 정리됐습니다. 실제 펼침 가능 연락이 올 때까지 새 결론을 만들지 않습니다.

## C_CH05_08 — 오늘은 여기서 잠그기

### Context
- Place: L02 → town guesthouse
- Cast: P00, P01, P07; P09 communicates by documented message only
- Entry: K25; all Oct22 mandatory reasoning closed
- Exit: P00/P01 leave the investigated hotel together for their prearranged town guesthouse; Oct23 return appointment awaits actual P09 conservation message
- World effects: sleep/time transition creates no clue and does not choose between the two coat hypotheses
- Repeat/resume: if resumed before departure, continue packing/exit; if saved after departure, next chapter begins from the guesthouse return contact, not from inside the hotel

### Script

*휴게실 시계가 늦은 저녁을 가리킨다. 새벽은 여백의 카드 묶음 위에 `원본 펼침 연락 대기` 한 장만 남긴다.*

**P07 | 진새벽 [S_CH05_08_0001]**

오늘 확인할 수 있는 필수 자료는 여기까지입니다. 젖어 붙은 제본 원본은 백로 씨가 보존 상태를 확인하고 연락하기 전에는 펼치지 않습니다.

*새벽이 휴대전화 화면을 보여 준다. 백로가 남긴 짧은 메시지다: `오늘은 더 손대지 않음. 내일 아침 펼침 가능 여부 확인 후 연락.` 시각·내용은 보존 약속일 뿐 새 증거가 아니다.*

**P01 | 나모눈 [S_CH05_08_0002]**

자고 일어나면 종이가 정답 말해?

**P00 | 나여백 [S_CH05_08_0003]**

아니. 내일 연락이 와도 같은 제본 원본인지부터 확인하고, 공개 사본과 다른 부분을 우리가 직접 비교해야 해.

**P07 | 진새벽 [S_CH05_08_0004]**

그 전까지 `무록 씨가 계속 비옷을 입었다`와 `두철 씨가 일찍 빌려 입었다` 두 설명은 둘 다 남깁니다. 밤이 지났다고 하나가 없어지진 않습니다.

**P01 | 나모눈 [S_CH05_08_0005]**

그럼 분실물 창구 닫자. 우리 숙소 가야지.

**P00 | 나여백 [S_CH05_08_0010]**

응. 오늘도 원래 잡아 둔 읍내 게스트하우스로 돌아가자. 현장에 자고 남는 건 조사도 아니고 약속도 아니니까.

*여백은 만실에게 모눈 감독이 끝났음을 확인받고, 모눈의 배낭과 자기 문서 가방을 챙긴다. 두 사람은 통제 구역 반대쪽 현관으로 함께 나간다. 새벽은 다음 날 연락을 받기 전 임의로 돌아오지 말라고 다시 확인한다.*

**P07 | 진새벽 [S_CH05_08_0011]**

백로 씨에게는 펼칠 수 있는 상태가 되면 {playerName} 씨에게 직접 연락해 달라고 남겨 두겠습니다. 연락을 받으면 모눈이와 함께 여울관으로 오세요.

*읍내 게스트하우스. 모눈은 신발을 벗자마자 침대 끝에 앉고, 여백은 사건 카드를 펼치지 않은 채 가방 안에 넣는다. 날짜가 넘어가도 새 E/K는 생기지 않는다.*

## C_CH05_O1 — 남겨진 사람도 기록에 있다

### Context
- Place: L02
- Cast: P00, P01
- Entry: after adult site return
- Exit: companion boundary/real contribution closure; no E/K
- Repeat: once per chapter

### Script

**P01 | 나모눈 [S_CH05_O1_0001]**

나는 오늘 중요한 장면에 하나도 못 갔어.

**P00 | 나여백 [S_CH05_O1_0002]**

네가 못 간 장소가 있었고, 대신 네가 실제로 있던 공개 자리의 신호와 내가 어디로 갔는지 아는 것도 기록이야. 하지만 위험한 곳에 데려가서 `도움 됐다`고 만들진 않을 거야.

**P01 | 나모눈 [S_CH05_O1_0003]**

그럼 다음에는 내가 안전해서 빠진 것도 써 줘.

**P00 | 나여백 [S_CH05_O1_0004]**

응. 빠진 이유도 사건 기록의 경계니까.

---

## C_CH05_O2 — 장비 말고 사람에게

### Context
- Place: L03
- Cast: P00, P05, P04
- Entry: after gate/action comparison
- Exit: negligence apology without criminal admission or relationship reconciliation
- Repeat: once per chapter

### Script

*연회장. 탁두철은 게이트 점검 공구함을 내려놓고 소해금을 본다.*

**P04 | 탁두철 [S_CH05_O2_0001]**

게이트 열어 둔 거 미안해. 네가 본 일까지 네가 책임질 건 아니야.

**P05 | 소해금 [S_CH05_O2_0002]**

나도 처음에 본 걸 숨긴 건 내 책임이야. 그런데 이 말이 우리 사이를 다시 시작하자는 말은 아니야.

**P04 | 탁두철 [S_CH05_O2_0003]**

알아. 이번엔 공구함한테 먼저 물어보지 않을게.

**P05 | 소해금 [S_CH05_O2_0004]**

그 정도면 오늘은 됐어.

*범죄 책임이나 관계 화해가 자동으로 바뀌지 않는다.*

---

## C_CH05_O3 — 비어 있는 받은편지함

### Context
- Place: L02
- Cast: P00, P02
- Entry: after required CH05 work
- Exit: victim-memory beat only; no clue
- Repeat: once per chapter

### Script

*휴게실 탁자에서 여백이 북쪽 창 회수 사진을 다시 넘기다 멈춘다. 사진의 중심은 재킷이지만, 창가 높은 의자도 함께 찍혀 있다. 봉만실이 화면을 보다가 서류 한 장을 내려놓는다.*

**P02 | 봉만실 [S_CH05_O3_0001]**

사진 속 저 의자요. 그 양반은 거기다 `임시 수신함`이라고 종이 세워 놓고, 발 아프다고 투덜대면서도 끝까지 안 앉았어요.

**P00 | 나여백 [S_CH05_O3_0002]**

처음 만났을 때 그 창가에서 저도 앉으라고 했습니다. 안 앉더군요.

**P02 | 봉만실 [S_CH05_O3_0003]**

사람이 죽었다고 모든 버릇이 좋은 기억으로 바뀌진 않아요. 그래도 사진에 저 자리가 남아 있는 건... 이상하게 다행이네요.

**P00 | 나여백 [S_CH05_O3_0004]**

사진은 그대로 두죠. 오늘은 그걸로 충분합니다.

---

## CH05 r03 focused revision state

- Authored: C_CH05_01..08, O1..O3, D21..D25, Q05, H_D21..H_D25, H_Q05, H_V05.
- D22 and D23 explicitly support either order after Q05/E45.
- Next: CH06 focused pass after the explicit Oct23 conservation-return transition.
